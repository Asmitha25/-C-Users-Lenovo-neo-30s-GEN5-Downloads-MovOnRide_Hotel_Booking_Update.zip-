# MovOnRide Hotel Booking – setup

This update adds a Hotels tab and a database-backed hotel reservation module. Existing bus pages and bus booking endpoints are left unchanged.

## Frontend

From the `frontend` directory:

```powershell
npm install
npm run dev
```

Open `http://localhost:3000/hotels` or use the Hotels tab in the navbar.

## Backend

From the `frontend/backend` directory, activate your existing Python virtual environment and install the existing requirements if needed:

```powershell
pip install -r requirements.txt
```

Make sure your backend `.env` file has the correct MySQL database name, username and password, and that the database itself has been created in MySQL. This uploaded project did not contain initial migrations for its Django apps, so generate them once on the new system. Then run:

```powershell
python manage.py makemigrations users buses routes bookings payments hotels
python manage.py migrate
python manage.py seed_demo_hotels
python manage.py runserver
```

The hotel APIs are under `/api/hotels/`:

- `GET /api/hotels/?city=Hyderabad&check_in=YYYY-MM-DD&check_out=YYYY-MM-DD` – search active hotels and show room availability for the dates.
- `GET /api/hotels/<id>/` – hotel details.
- `POST /api/hotels/bookings/create/` – authenticated reservation, using `PAY_AT_HOTEL`.
- `GET /api/hotels/bookings/mine/` – authenticated user's hotel reservations.

## Manage hotel inventory

Hotel staff can manage hotels and room types through Django admin at `/django-admin/`. Create a superuser if one does not already exist:

```powershell
python manage.py createsuperuser
```

Then add a Hotel and its Room Types. Set `total_rooms` to the actual number of rooms in that room category and set the nightly price. The sample seed command adds illustrative demo properties for Hyderabad, Chennai and Bengaluru. They are sample listings, not verified partner inventory.

## Booking and payment scope

The first release confirms reservations with **Pay at Hotel**; it does not collect online payment. Room availability is checked on the server for overlapping dates inside a database transaction. Before taking real customer bookings, configure verified property inventory, cancellation policies, taxes/fees, guest terms, and a production payment flow. External hotel-provider inventory is not connected in this release.
