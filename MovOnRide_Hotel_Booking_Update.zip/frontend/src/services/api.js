import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
})

// Attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Handle token refresh
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      try {
        const refresh = localStorage.getItem('refresh_token')
        const res = await axios.post(`${BASE_URL}/users/token/refresh/`, { refresh })
        localStorage.setItem('access_token', res.data.access)
        original.headers.Authorization = `Bearer ${res.data.access}`
        return api(original)
      } catch {
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export default api

// ── Bus API helpers ─────────────────────────────────────────
export const busAPI = {
  search: (params) => api.get('/buses/search/', { params }),
  getDetails: (id) => api.get(`/buses/${id}/`),
  getSeats: (scheduleId) => api.get(`/buses/schedules/${scheduleId}/seats/`),
  getOperators: () => api.get('/buses/operators/'),
}

// ── Booking API helpers ──────────────────────────────────────
export const bookingAPI = {
  create: (data) => api.post('/bookings/create/', data),
  getAll: () => api.get('/bookings/'),
  getById: (id) => api.get(`/bookings/${id}/`),
  cancel: (id) => api.post(`/bookings/${id}/cancel/`),
  holdSeats: (data) => api.post('/bookings/hold-seats/', data),
}

// ── Payment API helpers ──────────────────────────────────────
export const paymentAPI = {
  createOrder: (data) => api.post('/payments/create-order/', data),
  verify: (data) => api.post('/payments/verify/', data),
  mockPay: (data) => api.post('/payments/mock-pay/', data),
}

// ── User API helpers ─────────────────────────────────────────
export const userAPI = {
  getProfile: () => api.get('/users/profile/'),
  updateProfile: (data) => api.put('/users/profile/', data),
  changePassword: (data) => api.post('/users/change-password/', data),
}

// ── Admin API helpers ────────────────────────────────────────
export const adminAPI = {
  getDashboard: () => api.get('/admin/dashboard/'),
  getBuses: (params) => api.get('/admin/buses/', { params }),
  createBus: (data) => api.post('/admin/buses/', data),
  updateBus: (id, data) => api.put(`/admin/buses/${id}/`, data),
  deleteBus: (id) => api.delete(`/admin/buses/${id}/`),
  getRoutes: (params) => api.get('/admin/routes/', { params }),
  createRoute: (data) => api.post('/admin/routes/', data),
  updateRoute: (id, data) => api.put(`/admin/routes/${id}/`, data),
  deleteRoute: (id) => api.delete(`/admin/routes/${id}/`),
  getSchedules: (params) => api.get('/admin/schedules/', { params }),
  createSchedule: (data) => api.post('/admin/schedules/', data),
  updateSchedule: (id, data) => api.put(`/admin/schedules/${id}/`, data),
  deleteSchedule: (id) => api.delete(`/admin/schedules/${id}/`),
  getBookings: (params) => api.get('/admin/bookings/', { params }),
  updateBooking: (id, data) => api.put(`/admin/bookings/${id}/`, data),
  getUsers: (params) => api.get('/admin/users/', { params }),
  getOperators: (params) => api.get('/admin/operators/', { params }),
  createOperator: (data) => api.post('/admin/operators/', data),
  updateOperator: (id, data) => api.put(`/admin/operators/${id}/`, data),
}


// ── Hotel API helpers ───────────────────────────────────────
export const hotelAPI = {
  search: (params) => api.get('/hotels/', { params }),
  getDetails: (id, params) => api.get(`/hotels/${id}/`, { params }),
  createBooking: (data) => api.post('/hotels/bookings/create/', data),
  getMyBookings: () => api.get('/hotels/bookings/mine/'),
}
