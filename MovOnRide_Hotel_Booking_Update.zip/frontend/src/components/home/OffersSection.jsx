import React from 'react'
import { Tag, Copy, Check } from 'lucide-react'
import { useState } from 'react'
import styles from './OffersSection.module.css'

const offers = [
  { code: 'FIRST50', title: 'First Booking Offer', desc: 'Get 50% off on your first bus ticket booking', discount: '50% OFF', color: '#e53935', bg: 'linear-gradient(135deg, #fff5f5, #ffe0e0)', expires: 'Valid till Dec 31' },
  { code: 'WEEKEND20', title: 'Weekend Special', desc: '20% discount on all weekend travel bookings', discount: '20% OFF', color: '#7c3aed', bg: 'linear-gradient(135deg, #f5f3ff, #ede9fe)', expires: 'Every Sat & Sun' },
  { code: 'FLEXI15', title: 'Flexible Fare', desc: 'Save 15% on non-AC sleeper tickets for long routes', discount: '15% OFF', color: '#0891b2', bg: 'linear-gradient(135deg, #f0f9ff, #e0f2fe)', expires: 'Limited time' },
]

export default function OffersSection() {
  const [copied, setCopied] = useState(null)

  const copy = (code) => {
    navigator.clipboard.writeText(code)
    setCopied(code)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <span className={styles.tag}><Tag size={13} /> Exclusive Offers</span>
          <h2 className={styles.title}>Save on Your Next Trip</h2>
        </div>
        <div className={styles.grid}>
          {offers.map((o) => (
            <div key={o.code} className={styles.card} style={{ background: o.bg }}>
              <div className={styles.discount} style={{ color: o.color }}>{o.discount}</div>
              <h3 className={styles.offerTitle}>{o.title}</h3>
              <p className={styles.offerDesc}>{o.desc}</p>
              <div className={styles.coupon}>
                <span className={styles.code} style={{ borderColor: o.color, color: o.color }}>{o.code}</span>
                <button className={styles.copyBtn} style={{ background: o.color }} onClick={() => copy(o.code)}>
                  {copied === o.code ? <Check size={14} /> : <Copy size={14} />}
                  {copied === o.code ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <span className={styles.expires}>{o.expires}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
