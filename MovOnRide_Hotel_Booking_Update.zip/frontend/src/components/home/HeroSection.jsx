import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapPin, Calendar, ArrowRight, ArrowLeftRight } from 'lucide-react'
import { CITIES } from '../../utils/helpers'
import styles from './HeroSection.module.css'

export default function HeroSection() {
  const navigate = useNavigate()
  const today = new Date().toISOString().split('T')[0]
  const [form, setForm] = useState({ from: '', to: '', date: today, returnDate: '' })
  const [isRoundTrip, setIsRoundTrip] = useState(false)
  const [errors, setErrors] = useState({})

  const handleSwap = () => setForm(f => ({ ...f, from: f.to, to: f.from }))

  const validate = () => {
    const e = {}
    if (!form.from) e.from = 'Select departure city'
    if (!form.to) e.to = 'Select destination city'
    if (form.from === form.to && form.from) e.to = 'Destination must differ from origin'
    if (!form.date) e.date = 'Select journey date'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSearch = (e) => {
    e.preventDefault()
    if (!validate()) return
    const params = new URLSearchParams({ from: form.from, to: form.to, date: form.date })
    navigate(`/search?${params}`)
  }

  return (
    <section className={styles.hero}>
      {/* Background */}
      <div className={styles.heroBg}>
        <div className={styles.heroBgOverlay} />
        <div className={styles.heroBgPattern} />
      </div>

      <div className="container" style={{ position: 'relative', zIndex: 2 }}>
        <div className={styles.heroContent}>
          <div className={styles.heroText}>
            <span className={styles.badge}>🚌 India's Trusted Bus Network</span>
            <h1 className={styles.heading}>
              Your Journey<br />
              <span className={styles.headingAccent}>Starts Here</span>
            </h1>
            <p className={styles.subheading}>
              Book bus tickets to 500+ cities. Comfortable rides, transparent pricing, and instant confirmation.
            </p>
            <div className={styles.stats}>
              <div className={styles.stat}><strong>500+</strong><span>Cities</span></div>
              <div className={styles.statDivider} />
              <div className={styles.stat}><strong>2M+</strong><span>Happy Travelers</span></div>
              <div className={styles.statDivider} />
              <div className={styles.stat}><strong>100+</strong><span>Bus Operators</span></div>
            </div>
          </div>

          {/* Search card */}
          <div className={styles.searchCard}>
            <div className={styles.tripToggle}>
              <button
                className={`${styles.tripBtn} ${!isRoundTrip ? styles.tripBtnActive : ''}`}
                onClick={() => setIsRoundTrip(false)}
              >One Way</button>
              <button
                className={`${styles.tripBtn} ${isRoundTrip ? styles.tripBtnActive : ''}`}
                onClick={() => setIsRoundTrip(true)}
              >Round Trip</button>
            </div>

            <form onSubmit={handleSearch} className={styles.form} noValidate>
              <div className={styles.routeRow}>
                <div className={styles.routeField}>
                  <label className={styles.fieldLabel}>
                    <MapPin size={14} style={{ color: '#e53935' }} /> From
                  </label>
                  <select
                    className={`form-control ${errors.from ? 'error' : ''}`}
                    value={form.from}
                    onChange={e => setForm({ ...form, from: e.target.value })}
                  >
                    <option value="">Select city</option>
                    {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {errors.from && <span className="form-error">{errors.from}</span>}
                </div>

                <button type="button" className={styles.swapBtn} onClick={handleSwap} aria-label="Swap cities">
                  <ArrowLeftRight size={18} />
                </button>

                <div className={styles.routeField}>
                  <label className={styles.fieldLabel}>
                    <MapPin size={14} style={{ color: '#16a34a' }} /> To
                  </label>
                  <select
                    className={`form-control ${errors.to ? 'error' : ''}`}
                    value={form.to}
                    onChange={e => setForm({ ...form, to: e.target.value })}
                  >
                    <option value="">Select city</option>
                    {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {errors.to && <span className="form-error">{errors.to}</span>}
                </div>
              </div>

              <div className={styles.dateRow}>
                <div className="form-group" style={{ flex: 1 }}>
                  <label className={styles.fieldLabel}>
                    <Calendar size={14} /> Departure Date
                  </label>
                  <input
                    type="date"
                    className={`form-control ${errors.date ? 'error' : ''}`}
                    min={today}
                    value={form.date}
                    onChange={e => setForm({ ...form, date: e.target.value })}
                  />
                  {errors.date && <span className="form-error">{errors.date}</span>}
                </div>
                {isRoundTrip && (
                  <div className="form-group" style={{ flex: 1 }}>
                    <label className={styles.fieldLabel}>
                      <Calendar size={14} /> Return Date
                    </label>
                    <input
                      type="date"
                      className="form-control"
                      min={form.date || today}
                      value={form.returnDate}
                      onChange={e => setForm({ ...form, returnDate: e.target.value })}
                    />
                  </div>
                )}
              </div>

              <button type="submit" className={`btn btn-primary btn-lg ${styles.searchBtn}`}>
                Search Buses <ArrowRight size={18} />
              </button>
            </form>

            <p className={styles.demoBadge}>⚠ Demo platform – sample data only</p>
          </div>
        </div>
      </div>
    </section>
  )
}
