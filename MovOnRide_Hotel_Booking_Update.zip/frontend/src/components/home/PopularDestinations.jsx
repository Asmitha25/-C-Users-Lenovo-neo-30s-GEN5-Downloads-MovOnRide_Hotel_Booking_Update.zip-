import React from 'react'
import { Link } from 'react-router-dom'
import styles from './PopularDestinations.module.css'

const destinations = [
  { city: 'Hyderabad', state: 'Telangana', buses: 120, emoji: '🕌', color: '#fbbf24' },
  { city: 'Bengaluru', state: 'Karnataka', buses: 145, emoji: '🌆', color: '#60a5fa' },
  { city: 'Chennai', state: 'Tamil Nadu', buses: 98, emoji: '🏖️', color: '#34d399' },
  { city: 'Vijayawada', state: 'Andhra Pradesh', buses: 85, emoji: '🌉', color: '#f87171' },
  { city: 'Visakhapatnam', state: 'Andhra Pradesh', buses: 72, emoji: '⛵', color: '#a78bfa' },
  { city: 'Tirupati', state: 'Andhra Pradesh', buses: 60, emoji: '🛕', color: '#fb923c' },
  { city: 'Mumbai', state: 'Maharashtra', buses: 110, emoji: '🏙️', color: '#38bdf8' },
  { city: 'Pune', state: 'Maharashtra', buses: 88, emoji: '🏛️', color: '#4ade80' },
]

const today = new Date().toISOString().split('T')[0]

export default function PopularDestinations() {
  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <h2 className={styles.title}>Popular Destinations</h2>
          <p className={styles.subtitle}>Top cities people are traveling to right now</p>
        </div>
        <div className={styles.grid}>
          {destinations.map((d) => (
            <Link
              key={d.city}
              to={`/search?to=${d.city}&date=${today}`}
              className={styles.card}
              style={{ '--accent': d.color }}
            >
              <div className={styles.emoji}>{d.emoji}</div>
              <div className={styles.info}>
                <strong className={styles.city}>{d.city}</strong>
                <span className={styles.state}>{d.state}</span>
              </div>
              <span className={styles.count}>{d.buses} buses</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
