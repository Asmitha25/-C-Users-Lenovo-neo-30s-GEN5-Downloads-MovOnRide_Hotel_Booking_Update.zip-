import React from 'react'
import { Star } from 'lucide-react'
import styles from './Testimonials.module.css'

const testimonials = [
  { name: 'Priya Sharma', city: 'Hyderabad', rating: 5, text: 'MovonRide made booking super simple! Got my Hyderabad to Bengaluru ticket in minutes. The AC sleeper was so comfortable.', avatar: 'PS' },
  { name: 'Rahul Verma', city: 'Mumbai', rating: 5, text: 'Excellent service! The real-time tracking feature is fantastic. I always know exactly where my bus is. Highly recommend!', avatar: 'RV' },
  { name: 'Anjali Reddy', city: 'Bengaluru', rating: 5, text: 'Love the seat selection interface. It shows exactly which seats are available. Booked my favorite window seat without any hassle.', avatar: 'AR' },
  { name: 'Siddharth Nair', city: 'Chennai', rating: 4, text: 'Great prices and the buses are always on time. Customer support helped me quickly when I needed to reschedule. Very satisfied.', avatar: 'SN' },
  { name: 'Meena Iyer', city: 'Visakhapatnam', rating: 5, text: 'Best bus booking platform in India! The interface is clean and easy to use. My family travels with MovonRide every time.', avatar: 'MI' },
  { name: 'Kiran Patel', city: 'Pune', rating: 5, text: 'Smooth booking experience from start to finish. The confirmation came instantly and the ticket was easy to download.', avatar: 'KP' },
]

export default function Testimonials() {
  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <span className={styles.tag}>⭐ Customer Reviews</span>
          <h2 className={styles.title}>What Travelers Say</h2>
          <p className={styles.subtitle}>Real reviews from real passengers</p>
        </div>
        <div className={styles.grid}>
          {testimonials.map((t, i) => (
            <div key={i} className={styles.card}>
              <div className={styles.stars}>
                {[...Array(5)].map((_, j) => (
                  <Star key={j} size={14} fill={j < t.rating ? '#f59e0b' : 'none'} color={j < t.rating ? '#f59e0b' : '#d1d5db'} />
                ))}
              </div>
              <p className={styles.text}>"{t.text}"</p>
              <div className={styles.author}>
                <div className={styles.avatar}>{t.avatar}</div>
                <div>
                  <strong className={styles.name}>{t.name}</strong>
                  <span className={styles.city}>{t.city}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
