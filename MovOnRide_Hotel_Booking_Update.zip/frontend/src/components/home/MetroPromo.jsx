import React from 'react'
import { Link } from 'react-router-dom'
import { Train, ArrowRight, MapPin, Clock } from 'lucide-react'
import styles from './MetroPromo.module.css'

const QUICK_ROUTES = [
  { from: 'Miyapur',    to: 'LB Nagar',   time: '~55 min', fare: '₹60', line: 1, color: '#e53935' },
  { from: 'Nagole',     to: 'Raidurg',     time: '~48 min', fare: '₹60', line: 2, color: '#1d4ed8' },
  { from: 'Ameerpet',   to: 'Hitec City',  time: '~18 min', fare: '₹25', line: 2, color: '#1d4ed8' },
  { from: 'Kukatpally', to: 'Ameerpet',    time: '~14 min', fare: '₹20', line: 1, color: '#e53935' },
  { from: 'Uppal',      to: 'Ameerpet',    time: '~22 min', fare: '₹35', line: 2, color: '#1d4ed8' },
  { from: 'JBS Parade', to: 'MG Bus Stand', time: '~20 min', fare: '₹35', line: 3, color: '#16a34a' },
]

export default function MetroPromo() {
  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.inner}>
          {/* Left info panel */}
          <div className={styles.info}>
            <span className={styles.badge}>🚇 Now on MovonRide</span>
            <h2 className={styles.title}>Hyderabad Metro Rail</h2>
            <p className={styles.desc}>
              Plan your metro journey, check fares, and book tokens across all three HMRL corridors — Red, Blue & Green lines.
            </p>
            <div className={styles.pills}>
              <span className={styles.pill} style={{ '--c': '#e53935' }}>🔴 Red Line</span>
              <span className={styles.pill} style={{ '--c': '#1d4ed8' }}>🔵 Blue Line</span>
              <span className={styles.pill} style={{ '--c': '#16a34a' }}>🟢 Green Line</span>
            </div>
            <div className={styles.metaStats}>
              <div className={styles.metaStat}><strong>57</strong><span>Stations</span></div>
              <div className={styles.metaStatDiv} />
              <div className={styles.metaStat}><strong>69 km</strong><span>Network</span></div>
              <div className={styles.metaStatDiv} />
              <div className={styles.metaStat}><strong>₹10–₹60</strong><span>Fares</span></div>
            </div>
            <Link to="/metro" className={`btn btn-primary btn-lg ${styles.cta}`}>
              <Train size={18} /> Plan Metro Journey <ArrowRight size={16} />
            </Link>
          </div>

          {/* Right quick routes */}
          <div className={styles.routes}>
            <div className={styles.routesTitle}>Popular Metro Routes</div>
            <div className={styles.routesList}>
              {QUICK_ROUTES.map((r, i) => (
                <Link
                  key={i}
                  to={`/metro`}
                  className={styles.routeCard}
                  style={{ '--line': r.color }}
                >
                  <div className={styles.routeLeft}>
                    <div className={styles.routeDot} style={{ background: r.color }} />
                    <div>
                      <div className={styles.routeStations}>{r.from} → {r.to}</div>
                      <div className={styles.routeMeta}>
                        <Clock size={11} /> {r.time}
                        <MapPin size={11} /> {r.fare}
                      </div>
                    </div>
                  </div>
                  <ArrowRight size={14} color={r.color} />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
