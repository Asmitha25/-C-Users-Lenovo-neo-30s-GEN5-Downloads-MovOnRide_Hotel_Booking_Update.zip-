import React from 'react'
import { Shield, Clock, CreditCard, Star, Headphones, MapPin } from 'lucide-react'
import styles from './WhyChooseUs.module.css'

const features = [
  { icon: Shield, title: 'Safe & Verified Buses', desc: 'All operators verified with strict safety standards and GPS tracking on every route.', color: '#3b82f6' },
  { icon: Clock, title: 'Live Tracking', desc: 'Track your bus in real-time and get instant notifications about departure and arrival.', color: '#8b5cf6' },
  { icon: CreditCard, title: 'Secure Payments', desc: 'Multiple secure payment options. Your financial data is always protected.', color: '#16a34a' },
  { icon: Star, title: 'Top-Rated Operators', desc: 'Book only from highly-rated operators with verified customer reviews.', color: '#f59e0b' },
  { icon: Headphones, title: '24/7 Support', desc: 'Round-the-clock customer service via phone, email, and live chat.', color: '#e53935' },
  { icon: MapPin, title: '500+ Cities', desc: 'Extensive network connecting major cities and small towns across India.', color: '#0891b2' },
]

export default function WhyChooseUs() {
  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <span className={styles.tag}>Why MovonRide</span>
          <h2 className={styles.title}>Travel Smarter, Travel Safer</h2>
          <p className={styles.subtitle}>Join millions of travelers who trust MovonRide for their journeys</p>
        </div>
        <div className={styles.grid}>
          {features.map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className={styles.card}>
              <div className={styles.iconWrap} style={{ background: `${color}15` }}>
                <Icon size={24} color={color} />
              </div>
              <h3 className={styles.cardTitle}>{title}</h3>
              <p className={styles.cardDesc}>{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
