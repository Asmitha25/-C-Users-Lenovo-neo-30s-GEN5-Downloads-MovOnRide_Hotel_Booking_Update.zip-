import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Clock, IndianRupee } from 'lucide-react'
import styles from './PopularRoutes.module.css'

const routes = [
  { from: 'Hyderabad', to: 'Bengaluru', duration: '11h', price: 799, buses: 32 },
  { from: 'Chennai', to: 'Bengaluru', duration: '6h', price: 449, buses: 28 },
  { from: 'Hyderabad', to: 'Vijayawada', duration: '4h', price: 299, buses: 45 },
  { from: 'Mumbai', to: 'Pune', duration: '3h', price: 249, buses: 60 },
  { from: 'Bengaluru', to: 'Chennai', duration: '6h', price: 449, buses: 26 },
  { from: 'Hyderabad', to: 'Tirupati', duration: '8h', price: 599, buses: 20 },
  { from: 'Visakhapatnam', to: 'Hyderabad', duration: '12h', price: 899, buses: 18 },
  { from: 'Bengaluru', to: 'Hyderabad', duration: '11h', price: 799, buses: 30 },
]

const today = new Date().toISOString().split('T')[0]

export default function PopularRoutes() {
  return (
    <section className={styles.section}>
      <div className="container">
        <div className={styles.header}>
          <div>
            <h2 className={styles.title}>Popular Routes</h2>
            <p className={styles.subtitle}>Most booked bus routes across India</p>
          </div>
        </div>
        <div className={styles.grid}>
          {routes.map((r, i) => (
            <Link
              key={i}
              to={`/search?from=${r.from}&to=${r.to}&date=${today}`}
              className={styles.card}
            >
              <div className={styles.cardRoute}>
                <div className={styles.city}>{r.from}</div>
                <div className={styles.arrow}>
                  <div className={styles.line} />
                  <ArrowRight size={16} />
                </div>
                <div className={styles.city}>{r.to}</div>
              </div>
              <div className={styles.cardMeta}>
                <span><Clock size={12} /> {r.duration}</span>
                <span className={styles.buses}>{r.buses} buses</span>
                <span className={styles.price}>from ₹{r.price}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
