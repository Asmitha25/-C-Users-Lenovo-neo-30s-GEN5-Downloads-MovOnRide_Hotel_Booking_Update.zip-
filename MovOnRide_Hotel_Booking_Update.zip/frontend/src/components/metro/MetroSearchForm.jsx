import React, { useState, useMemo } from 'react'
import { ArrowLeftRight, Search, Train } from 'lucide-react'
import { ALL_STATIONS } from '../../utils/metroData'
import styles from './MetroSearchForm.module.css'

export default function MetroSearchForm({ onSearch }) {
  const [from, setFrom] = useState('')
  const [to, setTo]     = useState('')
  const [passengers, setPassengers] = useState(1)
  const [errors, setErrors] = useState({})

  const stationNames = useMemo(() => [...new Set(ALL_STATIONS.map(s => s.name))].sort(), [])

  const swap = () => { setFrom(to); setTo(from) }

  const handleSubmit = (e) => {
    e.preventDefault()
    const err = {}
    if (!from) err.from = 'Select origin'
    if (!to)   err.to   = 'Select destination'
    if (from && to && from === to) err.to = 'Must be a different station'
    setErrors(err)
    if (Object.keys(err).length) return
    onSearch(from, to, passengers)
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form} noValidate>
      <h3 className={styles.formTitle}><Train size={18} color="#1d4ed8" /> Plan Your Journey</h3>

      <div className={styles.stationRow}>
        <div className={styles.stationField}>
          <label className={styles.label}>
            <span className={styles.dot} style={{ background: '#16a34a' }} /> From Station
          </label>
          <select
            className={`form-control ${errors.from ? 'error' : ''}`}
            value={from}
            onChange={e => setFrom(e.target.value)}
          >
            <option value="">Select station</option>
            {stationNames.map(n => <option key={n} value={n}>{n}</option>)}
          </select>
          {errors.from && <span className="form-error">{errors.from}</span>}
        </div>

        <button type="button" className={styles.swapBtn} onClick={swap} aria-label="Swap stations">
          <ArrowLeftRight size={16} />
        </button>

        <div className={styles.stationField}>
          <label className={styles.label}>
            <span className={styles.dot} style={{ background: '#e53935' }} /> To Station
          </label>
          <select
            className={`form-control ${errors.to ? 'error' : ''}`}
            value={to}
            onChange={e => setTo(e.target.value)}
          >
            <option value="">Select station</option>
            {stationNames.map(n => <option key={n} value={n}>{n}</option>)}
          </select>
          {errors.to && <span className="form-error">{errors.to}</span>}
        </div>
      </div>

      <div className={styles.passRow}>
        <label className={styles.label}>Passengers</label>
        <div className={styles.counter}>
          <button type="button" onClick={() => setPassengers(p => Math.max(1, p - 1))} className={styles.cntBtn}>−</button>
          <span className={styles.cntVal}>{passengers}</span>
          <button type="button" onClick={() => setPassengers(p => Math.min(8, p + 1))} className={styles.cntBtn}>+</button>
        </div>
      </div>

      <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', borderRadius: 12 }}>
        <Search size={16} /> Search Route
      </button>
    </form>
  )
}
