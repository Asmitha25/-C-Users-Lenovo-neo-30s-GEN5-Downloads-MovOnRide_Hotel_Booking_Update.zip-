import React, { useState } from 'react'
import { METRO_LINES, getLineStations } from '../../utils/metroData'
import styles from './MetroRouteMap.module.css'

export default function MetroRouteMap({ onStationClick }) {
  const [activeLine, setActiveLine] = useState(1)
  const [hoveredStation, setHoveredStation] = useState(null)

  const stations = getLineStations(activeLine)
  const line = METRO_LINES.find(l => l.id === activeLine)

  return (
    <div className={styles.wrap}>
      {/* Line tabs */}
      <div className={styles.lineTabs}>
        {METRO_LINES.map(l => (
          <button
            key={l.id}
            className={`${styles.lineTab} ${activeLine === l.id ? styles.lineTabActive : ''}`}
            style={activeLine === l.id ? { background: l.color, borderColor: l.color } : { borderColor: l.color, color: l.color }}
            onClick={() => setActiveLine(l.id)}
          >
            <span className={styles.lineTabDot} style={{ background: l.color }} />
            {l.name}
          </button>
        ))}
      </div>

      {/* Map area */}
      <div className={styles.mapArea}>
        <div className={styles.lineLabel} style={{ color: line.color }}>
          {line.name} — {line.from} ↔ {line.to}
        </div>

        {/* Horizontal station strip */}
        <div className={styles.stationStrip}>
          {/* The track line */}
          <div className={styles.track} style={{ background: line.color }} />

          {/* Stations */}
          {stations.map((station, idx) => {
            const isFirst    = idx === 0
            const isLast     = idx === stations.length - 1
            const isInterch  = !!station.interchange
            const isHovered  = hoveredStation?.id === station.id
            const isTop      = idx % 2 === 0

            return (
              <div
                key={station.id}
                className={`${styles.stationWrap} ${isTop ? styles.stationTop : styles.stationBottom}`}
                style={{ '--idx': idx, '--total': stations.length }}
                onClick={() => { onStationClick?.(station) }}
                onMouseEnter={() => setHoveredStation(station)}
                onMouseLeave={() => setHoveredStation(null)}
              >
                {/* Connector tick */}
                <div className={styles.tick} style={{ background: line.color }} />

                {/* Dot */}
                <div
                  className={`${styles.dot} ${isInterch ? styles.dotInterchange : ''} ${isFirst || isLast ? styles.dotTerminal : ''}`}
                  style={{ borderColor: line.color, background: isFirst || isLast || isInterch ? line.color : '#fff' }}
                />

                {/* Name */}
                <div className={`${styles.stationName} ${isFirst || isLast ? styles.stationNameBold : ''}`}>
                  {station.name}
                  {isInterch && <span className={styles.interchangePill}>⇄</span>}
                </div>

                {/* Hover tooltip */}
                {isHovered && (
                  <div className={styles.tooltip}>
                    <strong>{station.name}</strong>
                    <span>Station {station.seq} of {stations.length}</span>
                    <span>{station.km} km from {line.from}</span>
                    {isInterch && <span className={styles.tooltipInterch}>Interchange station</span>}
                  </div>
                )}
              </div>
            )
          })}
        </div>

        <div className={styles.mapLegend}>
          <span><span className={styles.legendDot} style={{ background: line.color }} />  Terminal</span>
          <span><span className={styles.legendDotInterch} />  Interchange</span>
          <span><span className={styles.legendDotReg} style={{ borderColor: line.color }} />  Station</span>
        </div>
      </div>
    </div>
  )
}
