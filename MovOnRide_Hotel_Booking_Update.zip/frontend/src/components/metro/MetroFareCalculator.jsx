import React from 'react'
import { Train, Clock, MapPin, IndianRupee, ArrowRight, Ticket } from 'lucide-react'
import { getLineColor, getLineById } from '../../utils/metroData'
import styles from './MetroFareCalculator.module.css'

export default function MetroFareCalculator({ journey, onBook }) {
  const { from, to, path, distKm, fare, stops, travelMin } = journey
  const fromLine = getLineById(from.line)
  const toLine   = getLineById(to.line)
  const hasInterchange = from.line !== to.line

  return (
    <div className={styles.card}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerIcon}><Train size={22} color="#1d4ed8" /></div>
        <div>
          <h3 className={styles.headerTitle}>Journey Found</h3>
          <p className={styles.headerSub}>{from.name} → {to.name}</p>
        </div>
        <div className={styles.fareTag}>₹{fare}</div>
      </div>

      {/* Stats row */}
      <div className={styles.stats}>
        <div className={styles.stat}>
          <Clock size={15} color="#6b7280" />
          <div>
            <strong>~{travelMin} min</strong>
            <span>Travel time</span>
          </div>
        </div>
        <div className={styles.statDiv} />
        <div className={styles.stat}>
          <MapPin size={15} color="#6b7280" />
          <div>
            <strong>{stops} stops</strong>
            <span>Intermediate</span>
          </div>
        </div>
        <div className={styles.statDiv} />
        <div className={styles.stat}>
          <IndianRupee size={15} color="#6b7280" />
          <div>
            <strong>{distKm} km</strong>
            <span>Distance</span>
          </div>
        </div>
        {hasInterchange && (
          <>
            <div className={styles.statDiv} />
            <div className={styles.stat}>
              <Train size={15} color="#f59e0b" />
              <div>
                <strong>1 interchange</strong>
                <span>Change train</span>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Route path */}
      <div className={styles.pathWrap}>
        <div className={styles.pathTitle}>Route</div>
        <div className={styles.path}>
          {path.map((station, idx) => {
            const lineColor = getLineColor(station.line)
            const isFirst = idx === 0
            const isLast  = idx === path.length - 1
            const isInterchange = station.interchange && idx > 0 && idx < path.length - 1
            const prevLine = idx > 0 ? path[idx - 1].line : null
            const isLineChange = prevLine && prevLine !== station.line

            return (
              <div key={station.id} className={styles.pathItem}>
                {idx > 0 && (
                  <div
                    className={`${styles.pathLine} ${isLineChange ? styles.pathLineDashed : ''}`}
                    style={{ background: lineColor }}
                  />
                )}
                <div className={styles.pathStation}>
                  <div
                    className={`${styles.pathDot} ${isFirst || isLast ? styles.pathDotLarge : ''} ${isInterchange ? styles.pathDotInterchange : ''}`}
                    style={{ borderColor: lineColor, background: isFirst || isLast ? lineColor : '#fff' }}
                  />
                  <span className={`${styles.pathName} ${isFirst || isLast ? styles.pathNameBold : ''}`}>
                    {station.name}
                    {isInterchange && <span className={styles.interchangeTag}>interchange</span>}
                    {isLineChange && <span className={styles.lineChangeTag} style={{ background: lineColor }}>Line {station.line}</span>}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Book button */}
      <div className={styles.footer}>
        <div className={styles.fareSummary}>
          <span>Token fare per passenger</span>
          <strong className={styles.fareAmt}>₹{fare}</strong>
        </div>
        <button className={`btn btn-primary ${styles.bookBtn}`} onClick={onBook}>
          <Ticket size={16} /> Book Token
        </button>
      </div>
    </div>
  )
}
