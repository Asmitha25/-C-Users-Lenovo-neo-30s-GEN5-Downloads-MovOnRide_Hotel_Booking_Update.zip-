import React, { useState } from 'react'
import { X, Train, CheckCircle2, Ticket, Printer } from 'lucide-react'
import { generatePNR } from '../../utils/helpers'
import { getLineById } from '../../utils/metroData'
import styles from './MetroTicketModal.module.css'

export default function MetroTicketModal({ journey, onClose }) {
  const [step, setStep] = useState('details') // details | confirm | ticket
  const [passengers, setPassengers] = useState(1)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [errors, setErrors] = useState({})
  const [pnr] = useState(generatePNR())

  const line = getLineById(journey.from.line)
  const total = journey.fare * passengers

  const validate = () => {
    const e = {}
    if (!name.trim()) e.name = 'Name required'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = 'Valid email required'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleBook = () => {
    if (!validate()) return
    setStep('ticket')
  }

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className={styles.header} style={{ background: line?.color }}>
          <div className={styles.headerLeft}>
            <Train size={22} color="#fff" />
            <div>
              <div className={styles.headerTitle}>Metro Token Booking</div>
              <div className={styles.headerSub}>{journey.from.name} → {journey.to.name}</div>
            </div>
          </div>
          <button className={styles.closeBtn} onClick={onClose}><X size={20} /></button>
        </div>

        {step !== 'ticket' ? (
          <div className={styles.body}>
            {/* Journey summary */}
            <div className={styles.summary}>
              <div className={styles.summaryRow}>
                <span>Route</span>
                <strong>{journey.from.name} → {journey.to.name}</strong>
              </div>
              <div className={styles.summaryRow}>
                <span>Distance</span>
                <strong>{journey.distKm} km</strong>
              </div>
              <div className={styles.summaryRow}>
                <span>Travel time</span>
                <strong>~{journey.travelMin} min</strong>
              </div>
              <div className={styles.summaryRow}>
                <span>Fare per token</span>
                <strong style={{ color: '#1d4ed8' }}>₹{journey.fare}</strong>
              </div>
            </div>

            {/* Passengers */}
            <div className={styles.field}>
              <label className="form-label">Number of Passengers</label>
              <div className={styles.counter}>
                <button type="button" onClick={() => setPassengers(p => Math.max(1, p - 1))} className={styles.cntBtn}>−</button>
                <span className={styles.cntVal}>{passengers}</span>
                <button type="button" onClick={() => setPassengers(p => Math.min(8, p + 1))} className={styles.cntBtn}>+</button>
              </div>
            </div>

            {/* Contact */}
            <div className={styles.field}>
              <label className="form-label">Name *</label>
              <input className={`form-control ${errors.name ? 'error' : ''}`} placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
              {errors.name && <span className="form-error">{errors.name}</span>}
            </div>
            <div className={styles.field}>
              <label className="form-label">Email *</label>
              <input type="email" className={`form-control ${errors.email ? 'error' : ''}`} placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>

            {/* Total */}
            <div className={styles.totalRow}>
              <span>{passengers} token{passengers > 1 ? 's' : ''} × ₹{journey.fare}</span>
              <strong className={styles.totalAmt}>₹{total}</strong>
            </div>

            <p className={styles.demoNote}>⚠ Demo — no real payment processed</p>

            <button className={`btn btn-primary btn-lg ${styles.bookBtn}`} onClick={handleBook}>
              <Ticket size={16} /> Confirm & Book Token
            </button>
          </div>
        ) : (
          /* Ticket view */
          <div className={styles.ticketView}>
            <div className={styles.successIcon}>
              <CheckCircle2 size={48} color="#16a34a" />
            </div>
            <h3 className={styles.successTitle}>Token Booked!</h3>
            <p className={styles.successSub}>Your metro token is confirmed. Show this at the entry gate.</p>

            {/* Ticket card */}
            <div className={styles.ticket} style={{ '--line-color': line?.color }}>
              <div className={styles.ticketTop}>
                <div className={styles.ticketBrand}>🚇 Hyderabad Metro</div>
                <span className={styles.ticketPNR}>{pnr}</span>
              </div>
              <div className={styles.ticketRoute}>
                <div className={styles.ticketStation}>
                  <strong>{journey.from.name}</strong>
                  <span>Origin</span>
                </div>
                <div className={styles.ticketArrow}>→</div>
                <div className={styles.ticketStation}>
                  <strong>{journey.to.name}</strong>
                  <span>Destination</span>
                </div>
              </div>
              <div className={styles.ticketDetails}>
                <div><span>Passengers</span><strong>{passengers}</strong></div>
                <div><span>Line</span><strong style={{ color: line?.color }}>{line?.name}</strong></div>
                <div><span>Distance</span><strong>{journey.distKm} km</strong></div>
                <div><span>Amount</span><strong style={{ color: '#16a34a' }}>₹{total}</strong></div>
              </div>
              <div className={styles.ticketName}>{name}</div>
              <div className={styles.ticketNote}>Valid for single journey only. Non-transferable.</div>
            </div>

            <div className={styles.ticketActions}>
              <button className="btn btn-ghost" onClick={() => window.print()}><Printer size={15} /> Print</button>
              <button className="btn btn-primary" onClick={onClose}>Done</button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
