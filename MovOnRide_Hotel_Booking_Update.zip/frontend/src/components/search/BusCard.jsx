import React, { useState } from 'react'
import { Star, Clock, MapPin, Wifi, Zap, Droplets, Wind, ChevronDown, ChevronUp } from 'lucide-react'
import { formatTime, calcDuration, formatCurrency, getBusTypeLabel } from '../../utils/helpers'
import styles from './BusCard.module.css'

const AmenityIcon = ({ name }) => {
  const icons = { wifi: <Wifi size={12} />, charging: <Zap size={12} />, water: <Droplets size={12} />, blanket: '🛏', pillow: '🪫', snacks: '🍿' }
  return <span className={styles.amenity}>{icons[name] || name}</span>
}

export default function BusCard({ bus, onSelectSeats }) {
  const [expanded, setExpanded] = useState(false)
  const duration = calcDuration(bus.departureTime, bus.arrivalTime)
  const typeLabel = getBusTypeLabel(bus.busType)
  const isAC = bus.busType.startsWith('AC')
  const isSleeper = bus.busType.includes('SLEEPER')
  const isLow = bus.availableSeats <= 5

  return (
    <div className={styles.card}>
      <div className={styles.main}>
        {/* Operator info */}
        <div className={styles.operator}>
          <div className={styles.operatorLogo}>{bus.operator?.[0]}</div>
          <div>
            <div className={styles.operatorName}>{bus.operator}</div>
            <div className={styles.busName}>{bus.busName}</div>
          </div>
        </div>

        {/* Type badges */}
        <div className={styles.badges}>
          <span className={`${styles.badge} ${isAC ? styles.badgeAC : styles.badgeNonAC}`}>{isAC ? 'AC' : 'Non-AC'}</span>
          <span className={`${styles.badge} ${isSleeper ? styles.badgeSleeper : styles.badgeSeater}`}>{isSleeper ? 'Sleeper' : 'Seater'}</span>
        </div>

        {/* Times */}
        <div className={styles.times}>
          <div className={styles.time}>
            <span className={styles.timeVal}>{formatTime(bus.departureTime)}</span>
            <span className={styles.timeLabel}>Departure</span>
          </div>
          <div className={styles.duration}>
            <div className={styles.durationLine} />
            <span>{duration}</span>
            <div className={styles.durationLine} />
          </div>
          <div className={styles.time}>
            <span className={styles.timeVal}>{formatTime(bus.arrivalTime)}</span>
            <span className={styles.timeLabel}>Arrival</span>
          </div>
        </div>

        {/* Rating */}
        <div className={styles.rating}>
          <div className={styles.ratingScore}>
            <Star size={12} fill="#f59e0b" color="#f59e0b" />
            <strong>{bus.rating?.toFixed(1)}</strong>
          </div>
          <span className={styles.ratingCount}>{bus.reviews} reviews</span>
        </div>

        {/* Seats */}
        <div className={styles.seats}>
          <span className={`${styles.seatsCount} ${isLow ? styles.seatsLow : ''}`}>
            {bus.availableSeats} seats left
          </span>
        </div>

        {/* Fare & CTA */}
        <div className={styles.fare}>
          <div className={styles.fareAmount}>{formatCurrency(bus.fare)}</div>
          <div className={styles.fareLabel}>per seat</div>
          <button className="btn btn-primary btn-sm" onClick={onSelectSeats} style={{ marginTop: '0.5rem', width: '100%' }}>
            Select Seats
          </button>
        </div>
      </div>

      {/* Expandable details */}
      <div className={styles.footer}>
        <button className={styles.expandBtn} onClick={() => setExpanded(!expanded)}>
          {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          {expanded ? 'Hide Details' : 'View Details'}
        </button>
        {bus.amenities?.length > 0 && (
          <div className={styles.amenities}>
            {bus.amenities.map(a => <AmenityIcon key={a} name={a} />)}
          </div>
        )}
      </div>

      {expanded && (
        <div className={styles.details}>
          <div className={styles.detailsGrid}>
            <div className={styles.detailItem}>
              <MapPin size={14} color="#e53935" />
              <div>
                <span className={styles.detailLabel}>Boarding Point</span>
                <span className={styles.detailVal}>{bus.boardingPoint}</span>
              </div>
            </div>
            <div className={styles.detailItem}>
              <MapPin size={14} color="#16a34a" />
              <div>
                <span className={styles.detailLabel}>Dropping Point</span>
                <span className={styles.detailVal}>{bus.droppingPoint}</span>
              </div>
            </div>
            <div className={styles.detailItem}>
              <Clock size={14} color="#6b7280" />
              <div>
                <span className={styles.detailLabel}>Bus Number</span>
                <span className={styles.detailVal}>{bus.busNumber}</span>
              </div>
            </div>
            <div className={styles.detailItem}>
              <span style={{ fontSize: '14px' }}>🚌</span>
              <div>
                <span className={styles.detailLabel}>Bus Type</span>
                <span className={styles.detailVal}>{typeLabel}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
