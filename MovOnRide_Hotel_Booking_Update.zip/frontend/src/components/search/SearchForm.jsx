import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapPin, Calendar, ArrowLeftRight, Search } from 'lucide-react'
import { CITIES } from '../../utils/helpers'
import styles from './SearchForm.module.css'

export default function SearchForm({ compact, initialFrom = '', initialTo = '', initialDate = '' }) {
  const navigate = useNavigate()
  const today = new Date().toISOString().split('T')[0]
  const [form, setForm] = useState({ from: initialFrom, to: initialTo, date: initialDate || today })
  const [errors, setErrors] = useState({})

  const handleSwap = () => setForm(f => ({ ...f, from: f.to, to: f.from }))

  const validate = () => {
    const e = {}
    if (!form.from) e.from = 'Required'
    if (!form.to) e.to = 'Required'
    if (form.from === form.to && form.from) e.to = 'Must differ'
    if (!form.date) e.date = 'Required'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSearch = (e) => {
    e.preventDefault()
    if (!validate()) return
    navigate(`/search?from=${form.from}&to=${form.to}&date=${form.date}`)
  }

  return (
    <form onSubmit={handleSearch} className={`${styles.form} ${compact ? styles.compact : ''}`} noValidate>
      <div className={styles.field}>
        <MapPin size={15} className={styles.icon} />
        <select value={form.from} onChange={e => setForm({ ...form, from: e.target.value })} className={`form-control ${errors.from ? 'error' : ''} ${styles.select}`}>
          <option value="">From</option>
          {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <button type="button" className={styles.swap} onClick={handleSwap} aria-label="Swap"><ArrowLeftRight size={16} /></button>

      <div className={styles.field}>
        <MapPin size={15} className={styles.icon} style={{ color: '#16a34a' }} />
        <select value={form.to} onChange={e => setForm({ ...form, to: e.target.value })} className={`form-control ${errors.to ? 'error' : ''} ${styles.select}`}>
          <option value="">To</option>
          {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div className={styles.field}>
        <Calendar size={15} className={styles.icon} />
        <input type="date" min={today} value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className={`form-control ${errors.date ? 'error' : ''} ${styles.dateInput}`} />
      </div>

      <button type="submit" className={`btn btn-primary ${styles.searchBtn}`}>
        <Search size={16} /> Search
      </button>
    </form>
  )
}
