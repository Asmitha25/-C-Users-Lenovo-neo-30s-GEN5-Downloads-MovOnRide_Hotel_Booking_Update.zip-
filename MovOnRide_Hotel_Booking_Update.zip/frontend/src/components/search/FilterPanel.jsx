import React from 'react'
import styles from './FilterPanel.module.css'

const BUS_TYPES = [
  { value: 'AC_SLEEPER', label: 'AC Sleeper' },
  { value: 'NON_AC_SLEEPER', label: 'Non-AC Sleeper' },
  { value: 'AC_SEATER', label: 'AC Seater' },
  { value: 'NON_AC_SEATER', label: 'Non-AC Seater' },
]

const DEPARTURE_SLOTS = [
  { value: 'morning', label: '06:00 – 12:00', emoji: '🌤️' },
  { value: 'afternoon', label: '12:00 – 18:00', emoji: '☀️' },
  { value: 'evening', label: '18:00 – 22:00', emoji: '🌆' },
  { value: 'night', label: '22:00 – 06:00', emoji: '🌙' },
]

export default function FilterPanel({ filters, onChange }) {
  const toggleType = (val) => {
    const types = filters.types.includes(val)
      ? filters.types.filter(t => t !== val)
      : [...filters.types, val]
    onChange({ ...filters, types })
  }

  const toggleDeparture = (val) => {
    const departure = filters.departure.includes(val)
      ? filters.departure.filter(d => d !== val)
      : [...filters.departure, val]
    onChange({ ...filters, departure })
  }

  return (
    <div className={styles.panel}>
      {/* Bus type */}
      <div className={styles.section}>
        <h4 className={styles.sectionTitle}>Bus Type</h4>
        {BUS_TYPES.map(t => (
          <label key={t.value} className={styles.checkLabel}>
            <input
              type="checkbox"
              checked={filters.types.includes(t.value)}
              onChange={() => toggleType(t.value)}
            />
            <span>{t.label}</span>
          </label>
        ))}
      </div>

      {/* Departure time */}
      <div className={styles.section}>
        <h4 className={styles.sectionTitle}>Departure Time</h4>
        {DEPARTURE_SLOTS.map(s => (
          <label key={s.value} className={styles.checkLabel}>
            <input
              type="checkbox"
              checked={filters.departure.includes(s.value)}
              onChange={() => toggleDeparture(s.value)}
            />
            <span>{s.emoji} {s.label}</span>
          </label>
        ))}
      </div>

      {/* Price range */}
      <div className={styles.section}>
        <h4 className={styles.sectionTitle}>Price Range</h4>
        <div className={styles.priceRange}>
          <span>₹{filters.minFare}</span>
          <span>₹{filters.maxFare}</span>
        </div>
        <input
          type="range"
          min={0}
          max={5000}
          step={50}
          value={filters.maxFare}
          onChange={e => onChange({ ...filters, maxFare: Number(e.target.value) })}
          className={styles.slider}
        />
      </div>

      {/* Rating */}
      <div className={styles.section}>
        <h4 className={styles.sectionTitle}>Minimum Rating</h4>
        {[0, 3, 3.5, 4, 4.5].map(r => (
          <label key={r} className={styles.radioLabel}>
            <input
              type="radio"
              checked={filters.minRating === r}
              onChange={() => onChange({ ...filters, minRating: r })}
            />
            <span>{r === 0 ? 'All' : `${r}+ ⭐`}</span>
          </label>
        ))}
      </div>
    </div>
  )
}
