import React from 'react'
import { Link } from 'react-router-dom'
import { Bus, Phone, Mail, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react'
import styles from './Footer.module.css'

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.grid}>
          {/* Brand */}
          <div className={styles.brand}>
            <Link to="/" className={styles.logo}>
              <Bus size={22} color="#e53935" />
              <span>Movon<span style={{ color: '#e53935' }}>Ride</span></span>
            </Link>
            <p className={styles.tagline}>
              Your trusted partner for comfortable and affordable bus travel across India.
            </p>
            <div className={styles.socials}>
              <a href="#" aria-label="Facebook"><Facebook size={18} /></a>
              <a href="#" aria-label="Twitter"><Twitter size={18} /></a>
              <a href="#" aria-label="Instagram"><Instagram size={18} /></a>
              <a href="#" aria-label="Youtube"><Youtube size={18} /></a>
            </div>
          </div>

          {/* Quick links */}
          <div className={styles.col}>
            <h4>Quick Links</h4>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/search">Search Buses</Link></li>
              <li><Link to="/my-bookings">My Bookings</Link></li>
              <li><Link to="/register">Sign Up</Link></li>
              <li><Link to="/login">Log In</Link></li>
            </ul>
          </div>

          {/* Popular routes */}
          <div className={styles.col}>
            <h4>Popular Routes</h4>
            <ul>
              <li><Link to="/search?from=Hyderabad&to=Bengaluru">Hyderabad → Bengaluru</Link></li>
              <li><Link to="/search?from=Chennai&to=Bengaluru">Chennai → Bengaluru</Link></li>
              <li><Link to="/search?from=Hyderabad&to=Vijayawada">Hyderabad → Vijayawada</Link></li>
              <li><Link to="/search?from=Mumbai&to=Pune">Mumbai → Pune</Link></li>
              <li><Link to="/search?from=Bengaluru&to=Chennai">Bengaluru → Chennai</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div className={styles.col}>
            <h4>Contact Us</h4>
            <ul>
              <li><Phone size={14} /> <span>1800-123-4567 (Toll Free)</span></li>
              <li><Mail size={14} /> <span>support@movonride.com</span></li>
              <li><MapPin size={14} /> <span>Hyderabad, Telangana, India</span></li>
            </ul>
            <p className={styles.hours}>Mon–Sat: 9 AM – 9 PM</p>
          </div>
        </div>

        <div className={styles.bottom}>
          <p>© {new Date().getFullYear()} MovonRide. All rights reserved.</p>
          <div className={styles.bottomLinks}>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Refund Policy</a>
          </div>
          <p className={styles.demo}>⚠ This is a demo platform. No real transactions are processed.</p>
        </div>
      </div>
    </footer>
  )
}
