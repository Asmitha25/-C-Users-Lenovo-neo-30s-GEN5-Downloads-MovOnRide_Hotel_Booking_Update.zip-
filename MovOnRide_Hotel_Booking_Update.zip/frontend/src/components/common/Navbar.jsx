import React, { useState, useEffect, useRef } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Menu, X, ChevronDown, User, BookOpen, LogOut, Settings, Bus, Train, Hotel } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'
import styles from './Navbar.module.css'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const userMenuRef = useRef(null)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handler = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setUserMenuOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const handleLogout = () => {
    logout()
    setUserMenuOpen(false)
    navigate('/')
  }

  return (
    <header className={`${styles.navbar} ${scrolled ? styles.scrolled : ''}`}>
      <div className="container">
        <div className={styles.inner}>
          {/* Logo */}
          <Link to="/" className={styles.logo}>
            <div className={styles.logoIcon}>
              <Bus size={20} color="#e53935" />
            </div>
            <span>Movon<span className={styles.logoAccent}>Ride</span></span>
          </Link>

          {/* Nav links */}
          <nav className={`${styles.links} ${mobileOpen ? styles.linksOpen : ''}`}>
            <NavLink to="/" end className={({ isActive }) => isActive ? styles.activeLink : styles.link}>Home</NavLink>
            <NavLink to="/search" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>Search Buses</NavLink>
            <NavLink to="/hotels" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              <Hotel size={14} style={{ marginRight: 4, verticalAlign: 'middle' }} />
              Hotels
            </NavLink>
            <NavLink to="/metro" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>
              <Train size={14} style={{ marginRight: 4, verticalAlign: 'middle' }} />
              Hyd Metro
            </NavLink>
            {user && <NavLink to="/my-bookings" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>My Bookings</NavLink>}
            {(user?.is_staff || user?.is_admin) && (
              <NavLink to="/admin" className={({ isActive }) => isActive ? styles.activeLink : styles.link}>Admin</NavLink>
            )}
          </nav>

          {/* Auth area */}
          <div className={styles.authArea}>
            {user ? (
              <div className={styles.userMenu} ref={userMenuRef}>
                <button className={styles.userBtn} onClick={() => setUserMenuOpen(!userMenuOpen)}>
                  <div className={styles.avatar}>{user.first_name?.[0] || user.email?.[0] || 'U'}</div>
                  <span className="hide-mobile">{user.first_name || 'Account'}</span>
                  <ChevronDown size={14} />
                </button>
                {userMenuOpen && (
                  <div className={styles.dropdown}>
                    <div className={styles.dropdownHeader}>
                      <strong>{user.first_name} {user.last_name}</strong>
                      <small>{user.email}</small>
                    </div>
                    <hr className={styles.dropdownDivider} />
                    <Link to="/profile" className={styles.dropdownItem} onClick={() => setUserMenuOpen(false)}>
                      <User size={15} /> My Profile
                    </Link>
                    <Link to="/my-bookings" className={styles.dropdownItem} onClick={() => setUserMenuOpen(false)}>
                      <BookOpen size={15} /> My Bookings
                    </Link>
                    {(user.is_staff || user.is_admin) && (
                      <Link to="/admin" className={styles.dropdownItem} onClick={() => setUserMenuOpen(false)}>
                        <Settings size={15} /> Admin Panel
                      </Link>
                    )}
                    <hr className={styles.dropdownDivider} />
                    <button className={`${styles.dropdownItem} ${styles.logoutItem}`} onClick={handleLogout}>
                      <LogOut size={15} /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className={styles.authButtons}>
                <Link to="/login" className="btn btn-ghost btn-sm">Log In</Link>
                <Link to="/register" className="btn btn-primary btn-sm">Sign Up</Link>
              </div>
            )}
            <button className={styles.mobileToggle} onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">
              {mobileOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
