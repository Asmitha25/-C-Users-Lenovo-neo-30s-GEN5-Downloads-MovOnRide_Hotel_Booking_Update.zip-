import React, { createContext, useContext, useState, useEffect } from 'react'
import api from '../services/api'

const AuthContext = createContext(null)

// ── Local user store (used when backend is not available) ──────────────────
const LOCAL_USERS_KEY = 'movonride_local_users'
const LOCAL_SESSION_KEY = 'movonride_local_user'

const getLocalUsers = () => {
  try { return JSON.parse(localStorage.getItem(LOCAL_USERS_KEY) || '[]') } catch { return [] }
}
const saveLocalUsers = (users) => localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users))

const mockToken = () => 'local_' + Math.random().toString(36).slice(2)

// ──────────────────────────────────────────────────────────────────────────

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Seed demo user on first run
    const users = getLocalUsers()
    if (!users.find(u => u.email === 'demo@movonride.com')) {
      saveLocalUsers([...users, {
        id: 1,
        email: 'demo@movonride.com',
        first_name: 'Demo',
        last_name: 'User',
        mobile: '9876543210',
        password: 'demo123456',
        is_staff: false,
        is_admin: false,
      }])
    }

    // Try to restore session from local store first (no backend needed)
    const localSession = localStorage.getItem(LOCAL_SESSION_KEY)
    if (localSession) {
      try {
        setUser(JSON.parse(localSession))
        setLoading(false)
        return
      } catch {}
    }

    // Try real backend
    const token = localStorage.getItem('access_token')
    if (token && !token.startsWith('local_')) {
      api.get('/users/profile/')
        .then(res => setUser(res.data))
        .catch(() => {
          localStorage.removeItem('access_token')
          localStorage.removeItem('refresh_token')
        })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  // ── Register ────────────────────────────────────────────────────────────
  const register = async (data) => {
    // 1. Try real backend
    try {
      const res = await api.post('/users/register/', data)
      localStorage.setItem('access_token', res.data.access)
      localStorage.setItem('refresh_token', res.data.refresh)
      localStorage.removeItem(LOCAL_SESSION_KEY)
      setUser(res.data.user)
      return res.data
    } catch (backendErr) {
      // If backend is unreachable (network error / 5xx), fall back to local
      const isNetworkError = !backendErr.response
      const isServerError = backendErr.response?.status >= 500
      if (!isNetworkError && !isServerError) {
        // Real validation error from backend (e.g. email already taken) — re-throw
        throw backendErr
      }
    }

    // 2. Backend unavailable — register locally
    const users = getLocalUsers()
    if (users.find(u => u.email === data.email)) {
      const err = new Error('Email already registered')
      err.response = { data: { email: ['An account with this email already exists.'] } }
      throw err
    }

    const newUser = {
      id: Date.now(),
      email: data.email,
      first_name: data.first_name || '',
      last_name: data.last_name || '',
      mobile: data.mobile || '',
      password: data.password, // stored only locally in demo mode
      is_staff: false,
      is_admin: false,
    }
    saveLocalUsers([...users, newUser])

    const { password: _p, ...safeUser } = newUser
    const fakeToken = mockToken()
    localStorage.setItem('access_token', fakeToken)
    localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(safeUser))
    setUser(safeUser)
    return { user: safeUser, access: fakeToken, refresh: fakeToken }
  }

  // ── Login ───────────────────────────────────────────────────────────────
  const login = async (email, password) => {
    // 1. Try real backend
    try {
      const res = await api.post('/users/login/', { email, password })
      localStorage.setItem('access_token', res.data.access)
      localStorage.setItem('refresh_token', res.data.refresh)
      localStorage.removeItem(LOCAL_SESSION_KEY)
      setUser(res.data.user)
      return res.data
    } catch (backendErr) {
      const isNetworkError = !backendErr.response
      const isServerError = backendErr.response?.status >= 500
      if (!isNetworkError && !isServerError) {
        throw backendErr
      }
    }

    // 2. Backend unavailable — check local store
    const users = getLocalUsers()
    const found = users.find(u => u.email === email && u.password === password)
    if (!found) {
      const err = new Error('Invalid credentials')
      err.response = { data: { detail: 'Invalid email or password.' } }
      throw err
    }

    const { password: _p, ...safeUser } = found
    const fakeToken = mockToken()
    localStorage.setItem('access_token', fakeToken)
    localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(safeUser))
    setUser(safeUser)
    return { user: safeUser, access: fakeToken, refresh: fakeToken }
  }

  // ── Logout ──────────────────────────────────────────────────────────────
  const logout = () => {
    localStorage.removeItem('access_token')
    localStorage.removeItem('refresh_token')
    localStorage.removeItem(LOCAL_SESSION_KEY)
    setUser(null)
  }

  const updateUser = (userData) => {
    setUser(userData)
    // Keep local session in sync
    if (localStorage.getItem(LOCAL_SESSION_KEY)) {
      localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(userData))
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
