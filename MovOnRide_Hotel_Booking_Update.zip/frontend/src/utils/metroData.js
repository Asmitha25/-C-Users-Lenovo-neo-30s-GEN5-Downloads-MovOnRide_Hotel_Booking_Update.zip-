/**
 * Hyderabad Metro Rail (HMRL) – Station & Line Data
 * Source: HMRL official network (L1, L2, L3 corridors)
 * ⚠ This is reference/demo data for the MovonRide platform.
 */

export const METRO_LINES = [
  {
    id: 1,
    name: 'Red Line',
    color: '#e53935',
    from: 'Miyapur',
    to: 'LB Nagar',
    length: 29.2,
    stations: 27,
    keyStations: ['Miyapur', 'JNTU', 'Kukatpally', 'SR Nagar', 'Ameerpet', 'Punjagutta', 'Lakdi-ka-Pool', 'MG Bus Station', 'Dilsukhnagar', 'LB Nagar'],
  },
  {
    id: 2,
    name: 'Blue Line',
    color: '#1d4ed8',
    from: 'Nagole',
    to: 'Raidurg',
    length: 27.5,
    stations: 23,
    keyStations: ['Nagole', 'Uppal', 'Stadium', 'Parade Ground', 'Secunderabad East', 'Ameerpet', 'Yusufguda', 'Madhapur', 'Hitec City', 'Raidurg'],
  },
  {
    id: 3,
    name: 'Green Line',
    color: '#16a34a',
    from: 'JBS Parade Ground',
    to: 'Mahatma Gandhi Bus Station',
    length: 11.2,
    stations: 9,
    keyStations: ['JBS Parade Ground', 'Secunderabad West', 'Gandhi Hospital', 'Musheerabad', 'RTC X Roads', 'Nampally', 'Assembly', 'Osmania Medical College', 'MG Bus Station'],
  },
]

// Full station list with line, sequence, and distance from origin (km)
export const ALL_STATIONS = [
  // Red Line (Line 1)
  { id: 'R01', name: 'Miyapur',           line: 1, seq: 1,  km: 0.0 },
  { id: 'R02', name: 'JNTU College',      line: 1, seq: 2,  km: 1.6 },
  { id: 'R03', name: 'KPHB Colony',       line: 1, seq: 3,  km: 3.2 },
  { id: 'R04', name: 'Kukatpally',        line: 1, seq: 4,  km: 4.5 },
  { id: 'R05', name: 'Balanagar',         line: 1, seq: 5,  km: 5.9 },
  { id: 'R06', name: 'Moosapet',          line: 1, seq: 6,  km: 7.1 },
  { id: 'R07', name: 'Bharat Nagar',      line: 1, seq: 7,  km: 8.3 },
  { id: 'R08', name: 'Erragadda',         line: 1, seq: 8,  km: 9.4 },
  { id: 'R09', name: 'ESI Hospital',      line: 1, seq: 9,  km: 10.5 },
  { id: 'R10', name: 'SR Nagar',          line: 1, seq: 10, km: 11.6 },
  { id: 'R11', name: 'Ameerpet',          line: 1, seq: 11, km: 12.7, interchange: 2 },
  { id: 'R12', name: 'Punjagutta',        line: 1, seq: 12, km: 13.8 },
  { id: 'R13', name: 'Irrum Manzil',      line: 1, seq: 13, km: 14.9 },
  { id: 'R14', name: 'Khairatabad',       line: 1, seq: 14, km: 16.0 },
  { id: 'R15', name: 'Lakdi-ka-Pool',     line: 1, seq: 15, km: 17.0 },
  { id: 'R16', name: 'Assembly',          line: 1, seq: 16, km: 18.0, interchange: 3 },
  { id: 'R17', name: 'Nampally',          line: 1, seq: 17, km: 19.0 },
  { id: 'R18', name: 'Gandhi Bhavan',     line: 1, seq: 18, km: 19.9 },
  { id: 'R19', name: 'Osmania Med. College', line: 1, seq: 19, km: 20.8 },
  { id: 'R20', name: 'MG Bus Station',    line: 1, seq: 20, km: 21.7, interchange: 3 },
  { id: 'R21', name: 'Malakpet',          line: 1, seq: 21, km: 22.7 },
  { id: 'R22', name: 'New Market',        line: 1, seq: 22, km: 23.5 },
  { id: 'R23', name: 'Musarambagh',       line: 1, seq: 23, km: 24.4 },
  { id: 'R24', name: 'Dilsukhnagar',      line: 1, seq: 24, km: 25.3 },
  { id: 'R25', name: 'Chaitanyapuri',     line: 1, seq: 25, km: 26.3 },
  { id: 'R26', name: 'Victoria Memorial', line: 1, seq: 26, km: 27.4 },
  { id: 'R27', name: 'LB Nagar',          line: 1, seq: 27, km: 29.2 },

  // Blue Line (Line 2)
  { id: 'B01', name: 'Nagole',            line: 2, seq: 1,  km: 0.0 },
  { id: 'B02', name: 'Uppal',             line: 2, seq: 2,  km: 1.8 },
  { id: 'B03', name: 'Victory Colony',    line: 2, seq: 3,  km: 3.0 },
  { id: 'B04', name: 'Ngri Airport',      line: 2, seq: 4,  km: 4.2 },
  { id: 'B05', name: 'Stadium',           line: 2, seq: 5,  km: 5.5 },
  { id: 'B06', name: 'Secunderabad East', line: 2, seq: 6,  km: 7.0 },
  { id: 'B07', name: 'Parade Ground',     line: 2, seq: 7,  km: 8.1, interchange: 3 },
  { id: 'B08', name: 'Secunderabad West', line: 2, seq: 8,  km: 9.2 },
  { id: 'B09', name: 'Gandhi Hospital',   line: 2, seq: 9,  km: 10.2 },
  { id: 'B10', name: 'Musheerabad',       line: 2, seq: 10, km: 11.2 },
  { id: 'B11', name: 'RTC X Roads',       line: 2, seq: 11, km: 12.2 },
  { id: 'B12', name: 'Chikkadpally',      line: 2, seq: 12, km: 13.1 },
  { id: 'B13', name: 'Narayanguda',       line: 2, seq: 13, km: 14.0 },
  { id: 'B14', name: 'Sultan Bazaar',     line: 2, seq: 14, km: 14.9 },
  { id: 'B15', name: 'MG Bus Station',    line: 2, seq: 15, km: 15.9, interchange: 1 },
  { id: 'B16', name: 'Ameerpet',          line: 2, seq: 16, km: 17.5, interchange: 1 },
  { id: 'B17', name: 'Yusufguda',         line: 2, seq: 17, km: 18.6 },
  { id: 'B18', name: 'Madhura Nagar',     line: 2, seq: 18, km: 19.6 },
  { id: 'B19', name: 'Bharat Heavy Elec.', line: 2, seq: 19, km: 20.6 },
  { id: 'B20', name: 'Jubilee Hills',     line: 2, seq: 20, km: 21.6 },
  { id: 'B21', name: 'Peddamma Temple',   line: 2, seq: 21, km: 22.7 },
  { id: 'B22', name: 'Madhapur',          line: 2, seq: 22, km: 23.7 },
  { id: 'B23', name: 'Durgam Cheruvu',    line: 2, seq: 23, km: 24.7 },
  { id: 'B24', name: 'Hitec City',        line: 2, seq: 24, km: 25.7 },
  { id: 'B25', name: 'Raidurg',           line: 2, seq: 25, km: 27.5 },

  // Green Line (Line 3)
  { id: 'G01', name: 'JBS Parade Ground', line: 3, seq: 1,  km: 0.0, interchange: 2 },
  { id: 'G02', name: 'Secunderabad West', line: 3, seq: 2,  km: 1.1 },
  { id: 'G03', name: 'Gandhi Hospital',   line: 3, seq: 3,  km: 2.3 },
  { id: 'G04', name: 'Musheerabad',       line: 3, seq: 4,  km: 3.4 },
  { id: 'G05', name: 'RTC X Roads',       line: 3, seq: 5,  km: 4.4 },
  { id: 'G06', name: 'Nampally',          line: 3, seq: 6,  km: 5.5 },
  { id: 'G07', name: 'Assembly',          line: 3, seq: 7,  km: 6.6, interchange: 1 },
  { id: 'G08', name: 'Osm. Medical College', line: 3, seq: 8, km: 7.9 },
  { id: 'G09', name: 'MG Bus Station',    line: 3, seq: 9,  km: 11.2, interchange: 1 },
]

// Distance-based fare slab (HMRL)
const FARE_SLABS = [
  { maxKm: 2,  fare: 10 },
  { maxKm: 4,  fare: 15 },
  { maxKm: 6,  fare: 20 },
  { maxKm: 9,  fare: 25 },
  { maxKm: 12, fare: 30 },
  { maxKm: 15, fare: 35 },
  { maxKm: 20, fare: 40 },
  { maxKm: 25, fare: 50 },
  { maxKm: Infinity, fare: 60 },
]

export const calcFare = (distKm) => {
  const slab = FARE_SLABS.find(s => distKm <= s.maxKm)
  return slab ? slab.fare : 60
}

// Find shortest journey between two stations (handles interchange)
export const getJourney = (fromName, toName) => {
  const from = ALL_STATIONS.find(s => s.name === fromName)
  const to   = ALL_STATIONS.find(s => s.name === toName)
  if (!from || !to) return null

  let path = []
  let distKm = 0

  if (from.line === to.line) {
    // Same line — direct
    const line = METRO_LINES.find(l => l.id === from.line)
    const stationsOnLine = ALL_STATIONS.filter(s => s.line === from.line)
      .sort((a, b) => a.seq - b.seq)
    const fromIdx = stationsOnLine.findIndex(s => s.id === from.id)
    const toIdx   = stationsOnLine.findIndex(s => s.id === to.id)
    const [start, end] = fromIdx < toIdx ? [fromIdx, toIdx] : [toIdx, fromIdx]
    path = stationsOnLine.slice(start, end + 1)
    distKm = Math.abs(to.km - from.km)
  } else {
    // Different lines — find interchange station
    const fromLineStations = ALL_STATIONS.filter(s => s.line === from.line)
    const toLineStations   = ALL_STATIONS.filter(s => s.line === to.line)
    const interchange = fromLineStations.find(s => s.interchange && toLineStations.find(t => t.name === s.name))
      || toLineStations.find(s => s.interchange && fromLineStations.find(t => t.name === s.name))

    if (interchange) {
      const interOnFromLine = fromLineStations.find(s => s.name === interchange.name)
      const interOnToLine   = toLineStations.find(s => s.name === interchange.name)

      const seg1 = fromLineStations.sort((a,b) => a.seq - b.seq)
      const seg2 = toLineStations.sort((a,b) => a.seq - b.seq)

      const f1 = seg1.findIndex(s => s.id === from.id)
      const i1 = seg1.findIndex(s => s.name === interchange.name)
      const i2 = seg2.findIndex(s => s.name === interchange.name)
      const t2 = seg2.findIndex(s => s.id === to.id)

      const [s1, e1] = f1 < i1 ? [f1, i1] : [i1, f1]
      const [s2, e2] = i2 < t2 ? [i2, t2] : [t2, i2]

      path = [...seg1.slice(s1, e1 + 1), ...seg2.slice(s2 + 1, e2 + 1)]
      distKm = Math.abs(interOnFromLine.km - from.km) + Math.abs(to.km - interOnToLine.km)
    } else {
      // Fallback – approximate
      path = [from, to]
      distKm = 10
    }
  }

  const fare     = calcFare(distKm)
  const stops    = path.length - 1
  const travelMin = Math.round(stops * 2 + 3) // ~2 min per stop + 3 buffer

  return { from, to, path, distKm: distKm.toFixed(1), fare, stops, travelMin }
}

export const getLineById   = (id)   => METRO_LINES.find(l => l.id === id)
export const getLineColor  = (lineId) => METRO_LINES.find(l => l.id === lineId)?.color || '#6b7280'
export const getLineStations = (lineId) => ALL_STATIONS.filter(s => s.line === lineId).sort((a,b) => a.seq - b.seq)
