import { format, parseISO, differenceInMinutes } from 'date-fns'

export const formatDate = (dateStr) => {
  try { return format(parseISO(dateStr), 'dd MMM yyyy') } catch { return dateStr }
}

export const formatTime = (timeStr) => {
  if (!timeStr) return ''
  const [h, m] = timeStr.split(':')
  const hour = parseInt(h)
  const ampm = hour >= 12 ? 'PM' : 'AM'
  const h12 = hour % 12 || 12
  return `${h12}:${m} ${ampm}`
}

export const formatDuration = (minutes) => {
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  return `${h}h ${m > 0 ? m + 'm' : ''}`.trim()
}

export const calcDuration = (dep, arr) => {
  const [dh, dm] = dep.split(':').map(Number)
  const [ah, am] = arr.split(':').map(Number)
  let mins = (ah * 60 + am) - (dh * 60 + dm)
  if (mins < 0) mins += 24 * 60
  return formatDuration(mins)
}

export const formatCurrency = (amount) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount)

export const generatePNR = () =>
  'MR' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase()

export const getBusTypeLabel = (type) => {
  const map = {
    AC_SEATER: 'AC Seater',
    NON_AC_SEATER: 'Non-AC Seater',
    AC_SLEEPER: 'AC Sleeper',
    NON_AC_SLEEPER: 'Non-AC Sleeper',
  }
  return map[type] || type
}

export const getStatusColor = (status) => {
  const map = {
    CONFIRMED: 'badge-success',
    PENDING: 'badge-warning',
    CANCELLED: 'badge-error',
    COMPLETED: 'badge-info',
    FAILED: 'badge-error',
  }
  return map[status] || 'badge-gray'
}

export const CITIES = [
  'Hyderabad', 'Bengaluru', 'Chennai', 'Vijayawada', 'Visakhapatnam',
  'Tirupati', 'Mumbai', 'Pune', 'Delhi', 'Kolkata', 'Ahmedabad',
  'Jaipur', 'Kochi', 'Coimbatore', 'Nagpur',
]
