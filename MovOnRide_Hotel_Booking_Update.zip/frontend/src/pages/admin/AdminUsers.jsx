import React, { useState, useEffect } from 'react'
import { Search, Shield } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { formatDate } from '../../utils/helpers'
import styles from './Admin.module.css'

const DEMO = [
  { id: 1, name: 'Priya Sharma', email: 'priya@example.com', mobile: '9876543210', isAdmin: false, isActive: true, joinedDate: '2026-03-15', bookingsCount: 8 },
  { id: 2, name: 'Rahul Verma', email: 'rahul@example.com', mobile: '9876543211', isAdmin: false, isActive: true, joinedDate: '2026-04-20', bookingsCount: 5 },
  { id: 3, name: 'Admin User', email: 'admin@movonride.com', mobile: '9000000000', isAdmin: true, isActive: true, joinedDate: '2026-01-01', bookingsCount: 0 },
  { id: 4, name: 'Anjali Reddy', email: 'anjali@example.com', mobile: '9876543212', isAdmin: false, isActive: true, joinedDate: '2026-05-10', bookingsCount: 12 },
  { id: 5, name: 'Demo User', email: 'demo@movonride.com', mobile: '9876543213', isAdmin: false, isActive: true, joinedDate: '2026-01-01', bookingsCount: 3 },
]

export default function AdminUsers() {
  const [users, setUsers] = useState(DEMO)
  const [q, setQ] = useState('')

  useEffect(() => {
    adminAPI.getUsers()
      .then(res => setUsers(res.data.results || res.data || DEMO))
      .catch(() => {})
  }, [])

  const filtered = users.filter(u => `${u.name} ${u.email}`.toLowerCase().includes(q.toLowerCase()))

  return (
    <div>
      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Manage Users</h1><p className={styles.pageSubtitle}>{users.length} registered users</p></div>
      </div>
      <div className={styles.tableCard}>
        <div className={styles.tableHeader}><div className={styles.searchBar}><Search size={15} color="#9ca3af" /><input placeholder="Search users..." value={q} onChange={e => setQ(e.target.value)} /></div></div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>Name</th><th>Email</th><th>Mobile</th><th>Joined</th><th>Bookings</th><th>Role</th><th>Status</th></tr></thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id}>
                  <td><strong>{u.name}</strong></td>
                  <td>{u.email}</td>
                  <td>{u.mobile}</td>
                  <td>{formatDate(u.joinedDate)}</td>
                  <td>{u.bookingsCount}</td>
                  <td><span className={`badge ${u.isAdmin ? 'badge-info' : 'badge-gray'}`}>{u.isAdmin ? <><Shield size={10} /> Admin</> : 'User'}</span></td>
                  <td><span className={`badge ${u.isActive ? 'badge-success' : 'badge-error'}`}>{u.isActive ? 'Active' : 'Suspended'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
