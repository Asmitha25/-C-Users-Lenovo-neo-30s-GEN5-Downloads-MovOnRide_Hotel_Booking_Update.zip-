import React, { useState, useEffect } from 'react'
import { Users, BookOpen, Bus, TrendingUp, IndianRupee, Building2 } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts'
import styles from './Admin.module.css'

const DEMO_STATS = {
  totalBookings: 1284, totalRevenue: 1847250, totalUsers: 3421, totalBuses: 87, activeOperators: 24, cancelledBookings: 143
}
const DEMO_MONTHLY = [
  { month: 'Jun', bookings: 95, revenue: 134500 },
  { month: 'Jul', bookings: 142, revenue: 198700 },
  { month: 'Aug', bookings: 189, revenue: 265300 },
  { month: 'Sep', bookings: 223, revenue: 312800 },
  { month: 'Oct', bookings: 178, revenue: 248900 },
  { month: 'Nov', bookings: 256, revenue: 358400 },
]
const DEMO_RECENT = [
  { id: 'MR1001', pnr: 'MRABC001', user: 'Priya S.', route: 'Hyderabad → Bengaluru', amount: 1698, status: 'CONFIRMED', date: '2026-11-04' },
  { id: 'MR1002', pnr: 'MRDEF002', user: 'Rahul V.', route: 'Chennai → Bengaluru', amount: 498, status: 'CONFIRMED', date: '2026-11-04' },
  { id: 'MR1003', pnr: 'MRGHI003', user: 'Anjali R.', route: 'Mumbai → Pune', amount: 298, status: 'COMPLETED', date: '2026-11-03' },
  { id: 'MR1004', pnr: 'MRJKL004', user: 'Siddharth N.', route: 'Hyderabad → Vijayawada', amount: 348, status: 'CANCELLED', date: '2026-11-03' },
  { id: 'MR1005', pnr: 'MRMNO005', user: 'Meena I.', route: 'Bengaluru → Tirupati', amount: 648, status: 'CONFIRMED', date: '2026-11-02' },
]

const StatCard = ({ icon: Icon, label, value, color, sub }) => (
  <div className={styles.statCard} style={{ borderLeftColor: color }}>
    <div className={styles.statIcon} style={{ background: `${color}18` }}><Icon size={22} color={color} /></div>
    <div>
      <div className={styles.statValue}>{value}</div>
      <div className={styles.statLabel}>{label}</div>
      {sub && <div className={styles.statSub}>{sub}</div>}
    </div>
  </div>
)

export default function AdminDashboard() {
  const [stats, setStats] = useState(DEMO_STATS)
  const [monthly, setMonthly] = useState(DEMO_MONTHLY)
  const [recentBookings, setRecentBookings] = useState(DEMO_RECENT)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    adminAPI.getDashboard()
      .then(res => {
        setStats(res.data.stats || DEMO_STATS)
        setMonthly(res.data.monthly || DEMO_MONTHLY)
        setRecentBookings(res.data.recent_bookings || DEMO_RECENT)
      })
      .catch(() => {}) // Use demo data
  }, [])

  const fmt = (n) => n >= 1000000 ? `${(n / 1000000).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(0)}K` : n

  return (
    <div>
      <div className={styles.pageHeader}>
        <div>
          <h1 className={styles.pageTitle}>Dashboard Overview</h1>
          <p className={styles.pageSubtitle}>Demo data shown below — connect backend to see live data</p>
        </div>
      </div>

      {/* Stats */}
      <div className={styles.statsGrid}>
        <StatCard icon={BookOpen} label="Total Bookings" value={fmt(stats.totalBookings)} color="#e53935" sub={`${stats.cancelledBookings} cancelled`} />
        <StatCard icon={IndianRupee} label="Total Revenue" value={`₹${fmt(stats.totalRevenue)}`} color="#16a34a" />
        <StatCard icon={Users} label="Total Users" value={fmt(stats.totalUsers)} color="#2563eb" />
        <StatCard icon={Bus} label="Total Buses" value={stats.totalBuses} color="#7c3aed" />
        <StatCard icon={Building2} label="Active Operators" value={stats.activeOperators} color="#d97706" />
        <StatCard icon={TrendingUp} label="Monthly Growth" value="+14.3%" color="#0891b2" sub="vs last month" />
      </div>

      {/* Charts */}
      <div className={styles.chartsGrid}>
        <div className={styles.chartCard}>
          <h3 className={styles.chartTitle}>Monthly Bookings</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="bookings" fill="#e53935" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className={styles.chartCard}>
          <h3 className={styles.chartTitle}>Revenue Trend (₹)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => [`₹${v.toLocaleString()}`, 'Revenue']} />
              <Line type="monotone" dataKey="revenue" stroke="#16a34a" strokeWidth={2} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent bookings */}
      <div className={styles.tableCard}>
        <div className={styles.tableHeader}>
          <h3 className={styles.tableTitle}>Recent Bookings</h3>
        </div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>PNR</th><th>User</th><th>Route</th><th>Date</th><th>Amount</th><th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentBookings.map(b => (
                <tr key={b.id}>
                  <td><code className={styles.pnrCode}>{b.pnr}</code></td>
                  <td>{b.user}</td>
                  <td className={styles.route}>{b.route}</td>
                  <td>{b.date}</td>
                  <td><strong>₹{b.amount.toLocaleString()}</strong></td>
                  <td><span className={`badge ${b.status === 'CONFIRMED' ? 'badge-success' : b.status === 'COMPLETED' ? 'badge-info' : 'badge-error'}`}>{b.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
