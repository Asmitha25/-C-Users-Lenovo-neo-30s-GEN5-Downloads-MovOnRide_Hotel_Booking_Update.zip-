import React, { useState, useEffect } from 'react'
import { Plus, Search, Edit2, Trash2, X } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { CITIES } from '../../utils/helpers'
import toast from 'react-hot-toast'
import styles from './Admin.module.css'

const DEMO_ROUTES = [
  { id: 1, from: 'Hyderabad', to: 'Bengaluru', distance: 570, duration: 660, isActive: true },
  { id: 2, from: 'Chennai', to: 'Bengaluru', distance: 346, duration: 360, isActive: true },
  { id: 3, from: 'Hyderabad', to: 'Vijayawada', distance: 275, duration: 240, isActive: true },
  { id: 4, from: 'Mumbai', to: 'Pune', distance: 150, duration: 180, isActive: true },
  { id: 5, from: 'Hyderabad', to: 'Tirupati', distance: 560, duration: 480, isActive: true },
  { id: 6, from: 'Visakhapatnam', to: 'Hyderabad', distance: 620, duration: 720, isActive: true },
]

const emptyForm = { from: '', to: '', distance: '', duration: '' }

export default function AdminRoutes() {
  const [routes, setRoutes] = useState(DEMO_ROUTES)
  const [q, setQ] = useState('')
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    adminAPI.getRoutes()
      .then(res => setRoutes(res.data.results || res.data || DEMO_ROUTES))
      .catch(() => {})
  }, [])

  const filtered = routes.filter(r => `${r.from} ${r.to}`.toLowerCase().includes(q.toLowerCase()))
  const openCreate = () => { setForm(emptyForm); setEditing(null); setModal(true) }
  const openEdit = (r) => { setForm({ from: r.from, to: r.to, distance: r.distance, duration: r.duration }); setEditing(r.id); setModal(true) }

  const handleSave = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (editing) { await adminAPI.updateRoute(editing, form); setRoutes(prev => prev.map(r => r.id === editing ? { ...r, ...form } : r)) }
      else { setRoutes(prev => [...prev, { id: Date.now(), ...form, isActive: true }]) }
      toast.success(editing ? 'Route updated' : 'Route created')
    } catch {
      toast.error('Action failed')
    } finally { setLoading(false); setModal(false) }
  }

  const handleDelete = (id) => {
    if (!window.confirm('Delete this route?')) return
    setRoutes(prev => prev.filter(r => r.id !== id))
    toast.success('Route deleted')
  }

  return (
    <div>
      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Manage Routes</h1><p className={styles.pageSubtitle}>{routes.length} routes</p></div>
        <button className="btn btn-primary" onClick={openCreate}><Plus size={16} /> Add Route</button>
      </div>
      <div className={styles.tableCard}>
        <div className={styles.tableHeader}>
          <div className={styles.searchBar}><Search size={15} color="#9ca3af" /><input placeholder="Search routes..." value={q} onChange={e => setQ(e.target.value)} /></div>
        </div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>#</th><th>From</th><th>To</th><th>Distance (km)</th><th>Duration (min)</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {filtered.map((r, i) => (
                <tr key={r.id}>
                  <td>{i + 1}</td>
                  <td><strong>{r.from}</strong></td>
                  <td><strong>{r.to}</strong></td>
                  <td>{r.distance} km</td>
                  <td>{Math.floor(r.duration / 60)}h {r.duration % 60}m</td>
                  <td><span className={`badge ${r.isActive ? 'badge-success' : 'badge-gray'}`}>{r.isActive ? 'Active' : 'Inactive'}</span></td>
                  <td><div className={styles.actionBtns}><button className={styles.btnEdit} onClick={() => openEdit(r)}><Edit2 size={12} /></button><button className={styles.btnDelete} onClick={() => handleDelete(r.id)}><Trash2 size={12} /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className={styles.modalOverlay} onClick={() => setModal(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <div className={styles.modalHeader}><h3 className={styles.modalTitle}>{editing ? 'Edit Route' : 'Add Route'}</h3><button className={styles.modalClose} onClick={() => setModal(false)}><X size={18} /></button></div>
            <form onSubmit={handleSave}>
              <div className={styles.formGrid2}>
                <div className="form-group"><label className="form-label">From City *</label><select className="form-control" value={form.from} onChange={e => setForm({ ...form, from: e.target.value })} required><option value="">Select</option>{CITIES.map(c => <option key={c}>{c}</option>)}</select></div>
                <div className="form-group"><label className="form-label">To City *</label><select className="form-control" value={form.to} onChange={e => setForm({ ...form, to: e.target.value })} required><option value="">Select</option>{CITIES.map(c => <option key={c}>{c}</option>)}</select></div>
                <div className="form-group"><label className="form-label">Distance (km) *</label><input type="number" className="form-control" value={form.distance} onChange={e => setForm({ ...form, distance: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Duration (minutes) *</label><input type="number" className="form-control" value={form.duration} onChange={e => setForm({ ...form, duration: e.target.value })} required /></div>
              </div>
              <div className={styles.modalFooter}><button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button><button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Save Route'}</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
