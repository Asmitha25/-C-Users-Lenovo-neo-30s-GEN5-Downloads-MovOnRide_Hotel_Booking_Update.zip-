import React, { useState, useEffect } from 'react'
import { Search, Eye } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { formatDate, formatCurrency, getStatusColor } from '../../utils/helpers'
import styles from './Admin.module.css'

const DEMO = [
  { id: 'MR1001', pnr: 'MRABC001', user: 'Priya Sharma', route: 'Hyderabad → Bengaluru', journeyDate: '2026-12-15', seats: 'L4, L5', amount: 1698, status: 'CONFIRMED', paymentStatus: 'PAID' },
  { id: 'MR1002', pnr: 'MRDEF002', user: 'Rahul Verma', route: 'Chennai → Bengaluru', journeyDate: '2026-12-10', seats: '15', amount: 498, status: 'CONFIRMED', paymentStatus: 'PAID' },
  { id: 'MR1003', pnr: 'MRGHI003', user: 'Anjali Reddy', route: 'Mumbai → Pune', journeyDate: '2026-11-20', seats: 'U2', amount: 298, status: 'COMPLETED', paymentStatus: 'PAID' },
  { id: 'MR1004', pnr: 'MRJKL004', user: 'Siddharth Nair', route: 'Hyderabad → Vijayawada', journeyDate: '2026-11-15', seats: '8, 9', amount: 647, status: 'CANCELLED', paymentStatus: 'REFUNDED' },
  { id: 'MR1005', pnr: 'MRMNO005', user: 'Meena Iyer', route: 'Bengaluru → Tirupati', journeyDate: '2026-11-28', seats: 'L10', amount: 648, status: 'CONFIRMED', paymentStatus: 'PAID' },
]

export default function AdminBookings() {
  const [bookings, setBookings] = useState(DEMO)
  const [q, setQ] = useState('')
  const [statusFilter, setStatusFilter] = useState('')

  useEffect(() => {
    adminAPI.getBookings()
      .then(res => setBookings(res.data.results || res.data || DEMO))
      .catch(() => {})
  }, [])

  const filtered = bookings.filter(b =>
    (`${b.pnr} ${b.user} ${b.route}`.toLowerCase().includes(q.toLowerCase())) &&
    (statusFilter ? b.status === statusFilter : true)
  )

  return (
    <div>
      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Manage Bookings</h1><p className={styles.pageSubtitle}>{bookings.length} total bookings</p></div>
      </div>
      <div className={styles.tableCard}>
        <div className={styles.tableHeader} style={{ gap: '0.75rem', flexWrap: 'wrap' }}>
          <div className={styles.searchBar}><Search size={15} color="#9ca3af" /><input placeholder="Search by PNR, user, route..." value={q} onChange={e => setQ(e.target.value)} /></div>
          <select className="form-control" style={{ width: 160 }} value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="">All Statuses</option>
            <option>CONFIRMED</option><option>COMPLETED</option><option>CANCELLED</option>
          </select>
        </div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>PNR</th><th>User</th><th>Route</th><th>Journey Date</th><th>Seats</th><th>Amount</th><th>Status</th><th>Payment</th></tr></thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id}>
                  <td><code className={styles.pnrCode}>{b.pnr}</code></td>
                  <td>{b.user}</td>
                  <td>{b.route}</td>
                  <td>{formatDate(b.journeyDate)}</td>
                  <td>{b.seats}</td>
                  <td><strong>{formatCurrency(b.amount)}</strong></td>
                  <td><span className={`badge ${getStatusColor(b.status)}`}>{b.status}</span></td>
                  <td><span className={`badge ${b.paymentStatus === 'PAID' ? 'badge-success' : 'badge-warning'}`}>{b.paymentStatus}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
