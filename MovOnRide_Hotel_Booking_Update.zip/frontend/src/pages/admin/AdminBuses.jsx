import React, { useState, useEffect } from 'react'
import { Plus, Search, Edit2, Trash2, X } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { getBusTypeLabel } from '../../utils/helpers'
import toast from 'react-hot-toast'
import styles from './Admin.module.css'

const DEMO_BUSES = [
  { id: 1, name: 'KPN Diamond', busNumber: 'TS09AB1234', busType: 'AC_SLEEPER', totalSeats: 40, operator: 'KPN Travels', isActive: true },
  { id: 2, name: 'Orange Express', busNumber: 'AP28CD5678', busType: 'NON_AC_SLEEPER', totalSeats: 40, operator: 'Orange Travels', isActive: true },
  { id: 3, name: 'Parveen Volvo', busNumber: 'TN07EF9012', busType: 'AC_SEATER', totalSeats: 44, operator: 'Parveen Travels', isActive: true },
  { id: 4, name: 'Garuda', busNumber: 'TS01GH3456', busType: 'NON_AC_SEATER', totalSeats: 52, operator: 'TSRTC', isActive: true },
  { id: 5, name: 'VRL Super Luxury', busNumber: 'KA03IJ7890', busType: 'AC_SLEEPER', totalSeats: 36, operator: 'VRL Travels', isActive: false },
]

const BUS_TYPES = ['AC_SLEEPER', 'NON_AC_SLEEPER', 'AC_SEATER', 'NON_AC_SEATER']
const emptyForm = { name: '', busNumber: '', busType: 'AC_SLEEPER', totalSeats: 40, operator: '' }

export default function AdminBuses() {
  const [buses, setBuses] = useState(DEMO_BUSES)
  const [q, setQ] = useState('')
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [editing, setEditing] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    adminAPI.getBuses()
      .then(res => setBuses(res.data.results || res.data || DEMO_BUSES))
      .catch(() => {})
  }, [])

  const filtered = buses.filter(b =>
    b.name?.toLowerCase().includes(q.toLowerCase()) ||
    b.busNumber?.toLowerCase().includes(q.toLowerCase()) ||
    b.operator?.toLowerCase().includes(q.toLowerCase())
  )

  const openCreate = () => { setForm(emptyForm); setEditing(null); setModal(true) }
  const openEdit = (bus) => { setForm({ name: bus.name, busNumber: bus.busNumber, busType: bus.busType, totalSeats: bus.totalSeats, operator: bus.operator }); setEditing(bus.id); setModal(true) }

  const handleSave = async (e) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (editing) {
        await adminAPI.updateBus(editing, form)
        setBuses(prev => prev.map(b => b.id === editing ? { ...b, ...form } : b))
        toast.success('Bus updated')
      } else {
        const res = await adminAPI.createBus(form)
        setBuses(prev => [...prev, res.data])
        toast.success('Bus created')
      }
    } catch {
      // Demo mode
      if (editing) setBuses(prev => prev.map(b => b.id === editing ? { ...b, ...form } : b))
      else setBuses(prev => [...prev, { id: Date.now(), ...form, isActive: true }])
      toast.success(editing ? 'Bus updated (demo)' : 'Bus created (demo)')
    } finally {
      setLoading(false)
      setModal(false)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this bus?')) return
    try { await adminAPI.deleteBus(id) } catch {}
    setBuses(prev => prev.filter(b => b.id !== id))
    toast.success('Bus deleted')
  }

  return (
    <div>
      <div className={styles.pageHeader}>
        <div>
          <h1 className={styles.pageTitle}>Manage Buses</h1>
          <p className={styles.pageSubtitle}>{buses.length} buses registered</p>
        </div>
        <button className="btn btn-primary" onClick={openCreate}><Plus size={16} /> Add Bus</button>
      </div>

      <div className={styles.tableCard}>
        <div className={styles.tableHeader}>
          <div className={styles.searchBar}>
            <Search size={15} color="#9ca3af" />
            <input placeholder="Search buses..." value={q} onChange={e => setQ(e.target.value)} />
          </div>
        </div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>Bus Name</th><th>Bus No.</th><th>Operator</th><th>Type</th><th>Seats</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id}>
                  <td><strong>{b.name}</strong></td>
                  <td><code className={styles.pnrCode}>{b.busNumber}</code></td>
                  <td>{b.operator}</td>
                  <td><span className="badge badge-info">{getBusTypeLabel(b.busType)}</span></td>
                  <td>{b.totalSeats}</td>
                  <td><span className={`badge ${b.isActive ? 'badge-success' : 'badge-gray'}`}>{b.isActive ? 'Active' : 'Inactive'}</span></td>
                  <td>
                    <div className={styles.actionBtns}>
                      <button className={styles.btnEdit} onClick={() => openEdit(b)}><Edit2 size={12} /></button>
                      <button className={styles.btnDelete} onClick={() => handleDelete(b.id)}><Trash2 size={12} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className={styles.modalOverlay} onClick={() => setModal(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <h3 className={styles.modalTitle}>{editing ? 'Edit Bus' : 'Add New Bus'}</h3>
              <button className={styles.modalClose} onClick={() => setModal(false)}><X size={18} /></button>
            </div>
            <form onSubmit={handleSave}>
              <div className={styles.formGrid2}>
                <div className="form-group"><label className="form-label">Bus Name *</label><input className="form-control" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Bus Number *</label><input className="form-control" value={form.busNumber} onChange={e => setForm({ ...form, busNumber: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Operator *</label><input className="form-control" value={form.operator} onChange={e => setForm({ ...form, operator: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Total Seats *</label><input type="number" className="form-control" value={form.totalSeats} onChange={e => setForm({ ...form, totalSeats: e.target.value })} min={20} max={60} required /></div>
                <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                  <label className="form-label">Bus Type *</label>
                  <select className="form-control" value={form.busType} onChange={e => setForm({ ...form, busType: e.target.value })}>
                    {BUS_TYPES.map(t => <option key={t} value={t}>{getBusTypeLabel(t)}</option>)}
                  </select>
                </div>
              </div>
              <div className={styles.modalFooter}>
                <button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={loading}>{loading ? 'Saving...' : 'Save Bus'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
