import React, { useState, useEffect } from 'react'
import { Plus, Search, Edit2, Trash2, X } from 'lucide-react'
import { adminAPI } from '../../services/api'
import { formatTime, getBusTypeLabel } from '../../utils/helpers'
import toast from 'react-hot-toast'
import styles from './Admin.module.css'

const DEMO_SCHEDULES = [
  { id: 1, bus: 'KPN Diamond', route: 'Hyderabad → Bengaluru', departureTime: '21:00', arrivalTime: '08:00', fare: 849, isActive: true, daysOfWeek: 'Mon–Sun' },
  { id: 2, bus: 'Orange Express', route: 'Chennai → Bengaluru', departureTime: '07:00', arrivalTime: '13:00', fare: 449, isActive: true, daysOfWeek: 'Mon–Sat' },
  { id: 3, bus: 'Parveen Volvo', route: 'Hyderabad → Vijayawada', departureTime: '06:00', arrivalTime: '10:00', fare: 299, isActive: true, daysOfWeek: 'Daily' },
  { id: 4, bus: 'VRL Super Luxury', route: 'Mumbai → Pune', departureTime: '08:00', arrivalTime: '11:00', fare: 249, isActive: false, daysOfWeek: 'Wed,Sat' },
]

export default function AdminSchedules() {
  const [schedules, setSchedules] = useState(DEMO_SCHEDULES)
  const [q, setQ] = useState('')
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState({ bus: '', route: '', departureTime: '', arrivalTime: '', fare: '', daysOfWeek: 'Daily' })
  const [editing, setEditing] = useState(null)

  useEffect(() => {
    adminAPI.getSchedules()
      .then(res => setSchedules(res.data.results || res.data || DEMO_SCHEDULES))
      .catch(() => {})
  }, [])

  const filtered = schedules.filter(s => `${s.bus} ${s.route}`.toLowerCase().includes(q.toLowerCase()))

  const handleSave = (e) => {
    e.preventDefault()
    if (editing) setSchedules(prev => prev.map(s => s.id === editing ? { ...s, ...form } : s))
    else setSchedules(prev => [...prev, { id: Date.now(), ...form, isActive: true }])
    toast.success(editing ? 'Schedule updated' : 'Schedule created')
    setModal(false)
  }

  const handleDelete = (id) => {
    if (!window.confirm('Delete schedule?')) return
    setSchedules(prev => prev.filter(s => s.id !== id))
    toast.success('Schedule deleted')
  }

  return (
    <div>
      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Manage Schedules</h1><p className={styles.pageSubtitle}>{schedules.length} schedules</p></div>
        <button className="btn btn-primary" onClick={() => { setForm({ bus: '', route: '', departureTime: '', arrivalTime: '', fare: '', daysOfWeek: 'Daily' }); setEditing(null); setModal(true) }}><Plus size={16} /> Add Schedule</button>
      </div>
      <div className={styles.tableCard}>
        <div className={styles.tableHeader}><div className={styles.searchBar}><Search size={15} color="#9ca3af" /><input placeholder="Search schedules..." value={q} onChange={e => setQ(e.target.value)} /></div></div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>Bus</th><th>Route</th><th>Departure</th><th>Arrival</th><th>Fare</th><th>Days</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s.id}>
                  <td><strong>{s.bus}</strong></td>
                  <td>{s.route}</td>
                  <td>{formatTime(s.departureTime)}</td>
                  <td>{formatTime(s.arrivalTime)}</td>
                  <td><strong>₹{s.fare}</strong></td>
                  <td>{s.daysOfWeek}</td>
                  <td><span className={`badge ${s.isActive ? 'badge-success' : 'badge-gray'}`}>{s.isActive ? 'Active' : 'Inactive'}</span></td>
                  <td><div className={styles.actionBtns}><button className={styles.btnEdit} onClick={() => { setForm({ bus: s.bus, route: s.route, departureTime: s.departureTime, arrivalTime: s.arrivalTime, fare: s.fare, daysOfWeek: s.daysOfWeek }); setEditing(s.id); setModal(true) }}><Edit2 size={12} /></button><button className={styles.btnDelete} onClick={() => handleDelete(s.id)}><Trash2 size={12} /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className={styles.modalOverlay} onClick={() => setModal(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <div className={styles.modalHeader}><h3 className={styles.modalTitle}>{editing ? 'Edit Schedule' : 'Add Schedule'}</h3><button className={styles.modalClose} onClick={() => setModal(false)}><X size={18} /></button></div>
            <form onSubmit={handleSave}>
              <div className={styles.formGrid2}>
                <div className="form-group"><label className="form-label">Bus Name *</label><input className="form-control" value={form.bus} onChange={e => setForm({ ...form, bus: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Route *</label><input className="form-control" placeholder="City A → City B" value={form.route} onChange={e => setForm({ ...form, route: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Departure Time *</label><input type="time" className="form-control" value={form.departureTime} onChange={e => setForm({ ...form, departureTime: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Arrival Time *</label><input type="time" className="form-control" value={form.arrivalTime} onChange={e => setForm({ ...form, arrivalTime: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Fare (₹) *</label><input type="number" className="form-control" value={form.fare} onChange={e => setForm({ ...form, fare: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Days of Operation</label><input className="form-control" placeholder="Daily / Mon–Fri / etc." value={form.daysOfWeek} onChange={e => setForm({ ...form, daysOfWeek: e.target.value })} /></div>
              </div>
              <div className={styles.modalFooter}><button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Save</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
