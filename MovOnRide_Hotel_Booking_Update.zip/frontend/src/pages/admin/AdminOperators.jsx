import React, { useState, useEffect } from 'react'
import { Plus, Search, Edit2, Trash2, X } from 'lucide-react'
import { adminAPI } from '../../services/api'
import toast from 'react-hot-toast'
import styles from './Admin.module.css'

const DEMO = [
  { id: 1, name: 'KPN Travels', contactEmail: 'contact@kpntravels.com', contactPhone: '1800-111-0001', totalBuses: 12, rating: 4.5, isActive: true },
  { id: 2, name: 'Orange Travels', contactEmail: 'info@orangetravels.in', contactPhone: '1800-111-0002', totalBuses: 8, rating: 4.2, isActive: true },
  { id: 3, name: 'VRL Travels', contactEmail: 'support@vrltravels.com', contactPhone: '1800-111-0003', totalBuses: 15, rating: 4.8, isActive: true },
  { id: 4, name: 'Parveen Travels', contactEmail: 'info@parveentravels.com', contactPhone: '1800-111-0004', totalBuses: 10, rating: 4.7, isActive: true },
  { id: 5, name: 'TSRTC', contactEmail: 'info@tsrtc.gov.in', contactPhone: '1800-425-4567', totalBuses: 50, rating: 3.9, isActive: true },
  { id: 6, name: 'SRS Travels', contactEmail: 'info@srstravels.com', contactPhone: '1800-111-0006', totalBuses: 7, rating: 4.4, isActive: false },
]

const emptyForm = { name: '', contactEmail: '', contactPhone: '' }

export default function AdminOperators() {
  const [operators, setOperators] = useState(DEMO)
  const [q, setQ] = useState('')
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [editing, setEditing] = useState(null)

  useEffect(() => {
    adminAPI.getOperators()
      .then(res => setOperators(res.data.results || res.data || DEMO))
      .catch(() => {})
  }, [])

  const filtered = operators.filter(o => o.name.toLowerCase().includes(q.toLowerCase()))

  const handleSave = (e) => {
    e.preventDefault()
    if (editing) setOperators(prev => prev.map(o => o.id === editing ? { ...o, ...form } : o))
    else setOperators(prev => [...prev, { id: Date.now(), ...form, totalBuses: 0, rating: 4.0, isActive: true }])
    toast.success(editing ? 'Operator updated' : 'Operator added')
    setModal(false)
  }

  return (
    <div>
      <div className={styles.pageHeader}>
        <div><h1 className={styles.pageTitle}>Bus Operators</h1><p className={styles.pageSubtitle}>{operators.length} operators registered</p></div>
        <button className="btn btn-primary" onClick={() => { setForm(emptyForm); setEditing(null); setModal(true) }}><Plus size={16} /> Add Operator</button>
      </div>
      <div className={styles.tableCard}>
        <div className={styles.tableHeader}><div className={styles.searchBar}><Search size={15} color="#9ca3af" /><input placeholder="Search operators..." value={q} onChange={e => setQ(e.target.value)} /></div></div>
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>Operator Name</th><th>Email</th><th>Phone</th><th>Buses</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {filtered.map(o => (
                <tr key={o.id}>
                  <td><strong>{o.name}</strong></td>
                  <td>{o.contactEmail}</td>
                  <td>{o.contactPhone}</td>
                  <td>{o.totalBuses}</td>
                  <td>⭐ {o.rating}</td>
                  <td><span className={`badge ${o.isActive ? 'badge-success' : 'badge-gray'}`}>{o.isActive ? 'Active' : 'Inactive'}</span></td>
                  <td><div className={styles.actionBtns}><button className={styles.btnEdit} onClick={() => { setForm({ name: o.name, contactEmail: o.contactEmail, contactPhone: o.contactPhone }); setEditing(o.id); setModal(true) }}><Edit2 size={12} /></button><button className={styles.btnDelete} onClick={() => { if (!window.confirm('Remove operator?')) return; setOperators(prev => prev.filter(op => op.id !== o.id)); toast.success('Removed') }}><Trash2 size={12} /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal && (
        <div className={styles.modalOverlay} onClick={() => setModal(false)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <div className={styles.modalHeader}><h3 className={styles.modalTitle}>{editing ? 'Edit Operator' : 'Add Operator'}</h3><button className={styles.modalClose} onClick={() => setModal(false)}><X size={18} /></button></div>
            <form onSubmit={handleSave}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div className="form-group"><label className="form-label">Operator Name *</label><input className="form-control" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Contact Email *</label><input type="email" className="form-control" value={form.contactEmail} onChange={e => setForm({ ...form, contactEmail: e.target.value })} required /></div>
                <div className="form-group"><label className="form-label">Contact Phone</label><input className="form-control" value={form.contactPhone} onChange={e => setForm({ ...form, contactPhone: e.target.value })} /></div>
              </div>
              <div className={styles.modalFooter}><button type="button" className="btn btn-ghost" onClick={() => setModal(false)}>Cancel</button><button type="submit" className="btn btn-primary">Save</button></div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
