import React, { useState, useEffect, useMemo } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { Filter, SlidersHorizontal, ArrowUpDown, ChevronDown, ChevronUp, Star, Clock, MapPin, Wifi, Zap } from 'lucide-react'
import { busAPI } from '../services/api'
import { formatTime, calcDuration, formatCurrency, getBusTypeLabel } from '../utils/helpers'
import SearchForm from '../components/search/SearchForm'
import BusCard from '../components/search/BusCard'
import FilterPanel from '../components/search/FilterPanel'
import styles from './SearchResultsPage.module.css'

// Demo fallback data when backend is unavailable
const DEMO_BUSES = [
  { id: 1, scheduleId: 'sch_001', operator: 'KPN Travels', busType: 'AC_SLEEPER', busNumber: 'TS09AB1234', departureTime: '21:00', arrivalTime: '08:00', boardingPoint: 'Majestic Bus Stand', droppingPoint: 'Koti Bus Stand', fare: 849, availableSeats: 18, totalSeats: 40, rating: 4.5, reviews: 234, amenities: ['wifi', 'charging', 'water', 'blanket'], busName: 'KPN Diamond' },
  { id: 2, scheduleId: 'sch_002', operator: 'Orange Travels', busType: 'NON_AC_SLEEPER', busNumber: 'AP28CD5678', departureTime: '19:30', arrivalTime: '06:30', boardingPoint: 'MGBS Hyderabad', droppingPoint: 'Bengaluru Central', fare: 599, availableSeats: 22, totalSeats: 40, rating: 4.2, reviews: 189, amenities: ['charging', 'water'], busName: 'Orange Express' },
  { id: 3, scheduleId: 'sch_003', operator: 'Parveen Travels', busType: 'AC_SEATER', busNumber: 'TN07EF9012', departureTime: '08:00', arrivalTime: '19:00', boardingPoint: 'Hyderabad Railway Station', droppingPoint: 'Shantinagar', fare: 699, availableSeats: 12, totalSeats: 44, rating: 4.7, reviews: 312, amenities: ['wifi', 'charging', 'water', 'snacks'], busName: 'Parveen Volvo' },
  { id: 4, scheduleId: 'sch_004', operator: 'TSRTC', busType: 'NON_AC_SEATER', busNumber: 'TS01GH3456', departureTime: '06:00', arrivalTime: '17:00', boardingPoint: 'Jubilee Bus Station', droppingPoint: 'Majestic', fare: 399, availableSeats: 30, totalSeats: 52, rating: 3.9, reviews: 145, amenities: ['water'], busName: 'Garuda' },
  { id: 5, scheduleId: 'sch_005', operator: 'VRL Travels', busType: 'AC_SLEEPER', busNumber: 'KA03IJ7890', departureTime: '22:30', arrivalTime: '09:30', boardingPoint: 'MGBS Hyderabad', droppingPoint: 'Kempegowda', fare: 999, availableSeats: 8, totalSeats: 36, rating: 4.8, reviews: 428, amenities: ['wifi', 'charging', 'water', 'blanket', 'pillow'], busName: 'VRL Super Luxury' },
  { id: 6, scheduleId: 'sch_006', operator: 'SRS Travels', busType: 'AC_SEATER', busNumber: 'MH04KL2345', departureTime: '15:00', arrivalTime: '02:00', boardingPoint: 'Secunderabad', droppingPoint: 'Bengaluru KSRTC', fare: 749, availableSeats: 5, totalSeats: 44, rating: 4.4, reviews: 201, amenities: ['wifi', 'charging', 'water'], busName: 'SRS Gold' },
]

export default function SearchResultsPage() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const from = searchParams.get('from') || ''
  const to = searchParams.get('to') || ''
  const date = searchParams.get('date') || ''

  const [buses, setBuses] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [usedDemo, setUsedDemo] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({ types: [], ac: null, sleeper: null, departure: [], minFare: 0, maxFare: 5000, minRating: 0 })
  const [sortBy, setSortBy] = useState('departure')

  useEffect(() => {
    if (!from || !to) return
    setLoading(true)
    setError(null)
    busAPI.search({ from, to, date })
      .then(res => { setBuses(res.data); setUsedDemo(false) })
      .catch(() => {
        setBuses(DEMO_BUSES)
        setUsedDemo(true)
      })
      .finally(() => setLoading(false))
  }, [from, to, date])

  const filtered = useMemo(() => {
    let list = [...buses]
    if (filters.types.length) list = list.filter(b => filters.types.includes(b.busType))
    if (filters.ac !== null) {
      const isAC = (t) => t.startsWith('AC')
      list = list.filter(b => filters.ac ? isAC(b.busType) : !isAC(b.busType))
    }
    if (filters.sleeper !== null) {
      const isSleeper = (t) => t.includes('SLEEPER')
      list = list.filter(b => filters.sleeper ? isSleeper(b.busType) : !isSleeper(b.busType))
    }
    if (filters.departure.length) {
      list = list.filter(b => {
        const h = parseInt(b.departureTime.split(':')[0])
        return filters.departure.some(slot => {
          if (slot === 'morning') return h >= 6 && h < 12
          if (slot === 'afternoon') return h >= 12 && h < 18
          if (slot === 'evening') return h >= 18 && h < 22
          if (slot === 'night') return h >= 22 || h < 6
          return true
        })
      })
    }
    list = list.filter(b => b.fare >= filters.minFare && b.fare <= filters.maxFare)
    list = list.filter(b => b.rating >= filters.minRating)

    // Sort
    if (sortBy === 'price_asc') list.sort((a, b) => a.fare - b.fare)
    else if (sortBy === 'price_desc') list.sort((a, b) => b.fare - a.fare)
    else if (sortBy === 'departure') list.sort((a, b) => a.departureTime.localeCompare(b.departureTime))
    else if (sortBy === 'rating') list.sort((a, b) => b.rating - a.rating)
    else if (sortBy === 'seats') list.sort((a, b) => b.availableSeats - a.availableSeats)
    return list
  }, [buses, filters, sortBy])

  const handleSelectSeats = (bus) => {
    sessionStorage.setItem('selectedBus', JSON.stringify({ ...bus, from, to, date }))
    navigate(`/seats/${bus.scheduleId}`)
  }

  return (
    <div className={styles.page}>
      {/* Search bar */}
      <div className={styles.searchBar}>
        <div className="container">
          <SearchForm compact initialFrom={from} initialTo={to} initialDate={date} />
        </div>
      </div>

      <div className="container">
        {usedDemo && (
          <div className={styles.demoBanner}>
            ℹ️ Showing <strong>sample demo data</strong> — backend not connected. Results are for UI demonstration only.
          </div>
        )}

        <div className={styles.layout}>
          {/* Filter sidebar */}
          <aside className={`${styles.sidebar} ${showFilters ? styles.sidebarOpen : ''}`}>
            <div className={styles.sidebarHeader}>
              <h3>Filters</h3>
              <button onClick={() => setFilters({ types: [], ac: null, sleeper: null, departure: [], minFare: 0, maxFare: 5000, minRating: 0 })} className={styles.clearBtn}>Clear all</button>
            </div>
            <FilterPanel filters={filters} onChange={setFilters} />
          </aside>

          {/* Results */}
          <div className={styles.results}>
            <div className={styles.resultsHeader}>
              <div className={styles.resultCount}>
                <strong>{filtered.length}</strong> buses found
                {from && to && <span className={styles.route}> · {from} → {to}</span>}
              </div>
              <div className={styles.controls}>
                <button className={`btn btn-ghost btn-sm ${styles.filterToggle}`} onClick={() => setShowFilters(!showFilters)}>
                  <Filter size={15} /> Filters
                </button>
                <div className={styles.sortWrap}>
                  <ArrowUpDown size={14} />
                  <select value={sortBy} onChange={e => setSortBy(e.target.value)} className={styles.sortSelect}>
                    <option value="departure">Earliest Departure</option>
                    <option value="price_asc">Lowest Price</option>
                    <option value="price_desc">Highest Price</option>
                    <option value="rating">Highest Rated</option>
                    <option value="seats">Most Seats</option>
                  </select>
                </div>
              </div>
            </div>

            {loading ? (
              <div className={styles.loading}>
                <div className="spinner" style={{ width: 36, height: 36 }} />
                <p>Searching available buses...</p>
              </div>
            ) : filtered.length === 0 ? (
              <div className={styles.empty}>
                <span style={{ fontSize: '3rem' }}>🚌</span>
                <h3>No buses found</h3>
                <p>Try adjusting your filters or search for a different date.</p>
                <button className="btn btn-primary" onClick={() => setFilters({ types: [], ac: null, sleeper: null, departure: [], minFare: 0, maxFare: 5000, minRating: 0 })}>Clear Filters</button>
              </div>
            ) : (
              <div className={styles.list}>
                {filtered.map(bus => (
                  <BusCard key={bus.id} bus={bus} onSelectSeats={() => handleSelectSeats(bus)} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
