import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Bus } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'
import styles from './AuthPages.module.css'

export default function RegisterPage() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', mobile: '', password: '', confirmPassword: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)

  const validate = () => {
    const e = {}
    if (!form.firstName.trim()) e.firstName = 'First name required'
    if (!form.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required'
    if (!/^\d{10}$/.test(form.mobile)) e.mobile = '10-digit mobile required'
    if (form.password.length < 8) e.password = 'At least 8 characters'
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    try {
      await register({
        first_name: form.firstName,
        last_name: form.lastName,
        email: form.email,
        mobile: form.mobile,
        password: form.password,
      })
      toast.success('Account created successfully!')
      navigate('/')
    } catch (err) {
      const data = err.response?.data
      if (data && typeof data === 'object') {
        // Show field-level errors inline
        const newErrors = {}
        if (data.email)     newErrors.email    = Array.isArray(data.email)    ? data.email[0]    : data.email
        if (data.mobile)    newErrors.mobile   = Array.isArray(data.mobile)   ? data.mobile[0]   : data.mobile
        if (data.password)  newErrors.password = Array.isArray(data.password) ? data.password[0] : data.password
        if (Object.keys(newErrors).length) {
          setErrors(prev => ({ ...prev, ...newErrors }))
          toast.error('Please fix the highlighted fields.')
        } else {
          toast.error(data.detail || data.non_field_errors?.[0] || 'Registration failed. Please try again.')
        }
      } else {
        toast.error('Registration failed. Please try again.')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.page}>
      <div className={`${styles.card} ${styles.wideCard}`}>
        <div className={styles.brand}><Bus size={24} color="#e53935" /><span>MovonRide</span></div>
        <h1 className={styles.title}>Create your account</h1>
        <p className={styles.subtitle}>Join millions of travelers on MovonRide</p>

        <form onSubmit={handleSubmit} noValidate>
          <div className={styles.grid2}>
            <div className="form-group">
              <label className="form-label">First Name *</label>
              <input className={`form-control ${errors.firstName ? 'error' : ''}`} placeholder="John" value={form.firstName} onChange={e => setForm({ ...form, firstName: e.target.value })} />
              {errors.firstName && <span className="form-error">{errors.firstName}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Last Name</label>
              <input className="form-control" placeholder="Doe" value={form.lastName} onChange={e => setForm({ ...form, lastName: e.target.value })} />
            </div>
          </div>
          <div className={styles.grid2} style={{ marginTop: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Email *</label>
              <input type="email" className={`form-control ${errors.email ? 'error' : ''}`} placeholder="you@example.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
              {errors.email && <span className="form-error">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Mobile *</label>
              <input type="tel" className={`form-control ${errors.mobile ? 'error' : ''}`} placeholder="10-digit number" value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} />
              {errors.mobile && <span className="form-error">{errors.mobile}</span>}
            </div>
          </div>
          <div className={styles.grid2} style={{ marginTop: '1rem' }}>
            <div className="form-group">
              <label className="form-label">Password *</label>
              <div className={styles.pwdWrap}>
                <input type={showPwd ? 'text' : 'password'} className={`form-control ${errors.password ? 'error' : ''}`} placeholder="Min 8 characters" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
                <button type="button" className={styles.eyeBtn} onClick={() => setShowPwd(!showPwd)}>{showPwd ? <EyeOff size={16} /> : <Eye size={16} />}</button>
              </div>
              {errors.password && <span className="form-error">{errors.password}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Confirm Password *</label>
              <input type="password" className={`form-control ${errors.confirmPassword ? 'error' : ''}`} placeholder="Repeat password" value={form.confirmPassword} onChange={e => setForm({ ...form, confirmPassword: e.target.value })} />
              {errors.confirmPassword && <span className="form-error">{errors.confirmPassword}</span>}
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', marginTop: '1.5rem' }} disabled={loading}>
            {loading ? <><span className="spinner" style={{ borderTopColor: '#fff' }} /> Creating account...</> : 'Create Account'}
          </button>
        </form>

        <p className={styles.switchLink}>
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
