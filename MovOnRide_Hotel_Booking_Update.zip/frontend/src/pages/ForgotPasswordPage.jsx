import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Bus, Mail, ArrowLeft } from 'lucide-react'
import api from '../services/api'
import toast from 'react-hot-toast'
import styles from './AuthPages.module.css'

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!email) { setError('Email is required'); return }
    setLoading(true)
    try {
      await api.post('/users/password-reset/', { email })
      setSent(true)
    } catch {
      // Demo mode – show success anyway
      setSent(true)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.page}>
      <div className={styles.card}>
        <div className={styles.brand}><Bus size={24} color="#e53935" /><span>MovonRide</span></div>
        {sent ? (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📧</div>
            <h2 style={{ fontWeight: 800, marginBottom: '0.5rem' }}>Check your email</h2>
            <p style={{ color: '#6b7280', marginBottom: '1.5rem' }}>We've sent password reset instructions to <strong>{email}</strong></p>
            <Link to="/login" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>Back to Login</Link>
            <p style={{ marginTop: '0.875rem', fontSize: '0.8rem', color: '#9ca3af' }}>Demo: No real email sent in this demo platform.</p>
          </div>
        ) : (
          <>
            <h1 className={styles.title}>Forgot Password?</h1>
            <p className={styles.subtitle}>Enter your email and we'll send reset instructions</p>
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group" style={{ marginBottom: '1.25rem' }}>
                <label className="form-label"><Mail size={13} /> Email address</label>
                <input type="email" className={`form-control ${error ? 'error' : ''}`} placeholder="you@example.com" value={email} onChange={e => { setEmail(e.target.value); setError('') }} />
                {error && <span className="form-error">{error}</span>}
              </div>
              <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={loading}>
                {loading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </form>
            <p className={styles.switchLink}>
              <Link to="/login"><ArrowLeft size={13} /> Back to Login</Link>
            </p>
          </>
        )}
      </div>
    </div>
  )
}
