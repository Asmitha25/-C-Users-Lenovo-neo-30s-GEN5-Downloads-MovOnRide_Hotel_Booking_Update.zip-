import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, User, Phone, Mail, MapPin } from 'lucide-react'
import { formatTime, formatCurrency, getBusTypeLabel } from '../utils/helpers'
import styles from './PassengerDetailsPage.module.css'

const emptyPassenger = { fullName: '', age: '', gender: '', email: '', mobile: '' }

export default function PassengerDetailsPage() {
  const navigate = useNavigate()
  const [bus, setBus] = useState(null)
  const [seats, setSeats] = useState([])
  const [passengers, setPassengers] = useState([])
  const [contact, setContact] = useState({ email: '', mobile: '' })
  const [boarding, setBoarding] = useState('')
  const [dropping, setDropping] = useState('')
  const [errors, setErrors] = useState({})

  useEffect(() => {
    const b = sessionStorage.getItem('selectedBus')
    const s = sessionStorage.getItem('selectedSeats')
    if (!b || !s) { navigate('/search'); return }
    const busData = JSON.parse(b)
    const seatsData = JSON.parse(s)
    setBus(busData)
    setSeats(seatsData)
    setPassengers(seatsData.map(() => ({ ...emptyPassenger })))
    setBoarding(busData.boardingPoint || '')
    setDropping(busData.droppingPoint || '')
  }, [])

  const updatePassenger = (idx, field, val) => {
    setPassengers(prev => prev.map((p, i) => i === idx ? { ...p, [field]: val } : p))
  }

  const validate = () => {
    const e = {}
    passengers.forEach((p, i) => {
      if (!p.fullName.trim()) e[`name_${i}`] = 'Required'
      if (!p.age || p.age < 1 || p.age > 120) e[`age_${i}`] = 'Valid age required'
      if (!p.gender) e[`gender_${i}`] = 'Required'
    })
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email)) e.email = 'Valid email required'
    if (!/^\d{10}$/.test(contact.mobile)) e.mobile = '10-digit mobile required'
    if (!boarding.trim()) e.boarding = 'Required'
    if (!dropping.trim()) e.dropping = 'Required'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleContinue = () => {
    if (!validate()) return
    const bookingDetails = { bus, seats, passengers, contact, boarding, dropping }
    sessionStorage.setItem('bookingDetails', JSON.stringify(bookingDetails))
    navigate('/payment')
  }

  if (!bus) return null

  const totalFare = seats.length * bus.fare
  const gst = Math.round(totalFare * 0.05)
  const convenience = 49
  const grandTotal = totalFare + gst + convenience

  return (
    <div className={styles.page}>
      <div className="container">
        <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: '1.25rem' }}>
          <ArrowLeft size={16} /> Back to Seat Selection
        </button>

        <div className={styles.layout}>
          <div className={styles.formArea}>
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}><User size={18} /> Passenger Details</h2>
              {passengers.map((p, i) => (
                <div key={i} className={styles.passengerBlock}>
                  <div className={styles.passengerHeader}>
                    <span className={styles.seatBadge}>Seat {seats[i]?.seatNumber}</span>
                    <h4 className={styles.passengerNum}>Passenger {i + 1}</h4>
                  </div>
                  <div className={styles.grid2}>
                    <div className="form-group">
                      <label className="form-label">Full Name *</label>
                      <input className={`form-control ${errors[`name_${i}`] ? 'error' : ''}`} placeholder="Enter full name" value={p.fullName} onChange={e => updatePassenger(i, 'fullName', e.target.value)} />
                      {errors[`name_${i}`] && <span className="form-error">{errors[`name_${i}`]}</span>}
                    </div>
                    <div className={styles.grid2inner}>
                      <div className="form-group">
                        <label className="form-label">Age *</label>
                        <input className={`form-control ${errors[`age_${i}`] ? 'error' : ''}`} type="number" min="1" max="120" placeholder="Age" value={p.age} onChange={e => updatePassenger(i, 'age', e.target.value)} />
                        {errors[`age_${i}`] && <span className="form-error">{errors[`age_${i}`]}</span>}
                      </div>
                      <div className="form-group">
                        <label className="form-label">Gender *</label>
                        <select className={`form-control ${errors[`gender_${i}`] ? 'error' : ''}`} value={p.gender} onChange={e => updatePassenger(i, 'gender', e.target.value)}>
                          <option value="">Select</option>
                          <option value="MALE">Male</option>
                          <option value="FEMALE">Female</option>
                          <option value="OTHER">Other</option>
                        </select>
                        {errors[`gender_${i}`] && <span className="form-error">{errors[`gender_${i}`]}</span>}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Contact */}
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}><Phone size={18} /> Contact Information</h2>
              <div className={styles.grid2}>
                <div className="form-group">
                  <label className="form-label"><Mail size={13} /> Email *</label>
                  <input className={`form-control ${errors.email ? 'error' : ''}`} type="email" placeholder="your@email.com" value={contact.email} onChange={e => setContact({ ...contact, email: e.target.value })} />
                  {errors.email && <span className="form-error">{errors.email}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label"><Phone size={13} /> Mobile *</label>
                  <input className={`form-control ${errors.mobile ? 'error' : ''}`} type="tel" placeholder="10-digit number" value={contact.mobile} onChange={e => setContact({ ...contact, mobile: e.target.value })} />
                  {errors.mobile && <span className="form-error">{errors.mobile}</span>}
                </div>
              </div>
            </div>

            {/* Boarding/dropping */}
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}><MapPin size={18} /> Travel Points</h2>
              <div className={styles.grid2}>
                <div className="form-group">
                  <label className="form-label">Boarding Point *</label>
                  <input className={`form-control ${errors.boarding ? 'error' : ''}`} value={boarding} onChange={e => setBoarding(e.target.value)} placeholder="Boarding stop" />
                  {errors.boarding && <span className="form-error">{errors.boarding}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Dropping Point *</label>
                  <input className={`form-control ${errors.dropping ? 'error' : ''}`} value={dropping} onChange={e => setDropping(e.target.value)} placeholder="Dropping stop" />
                  {errors.dropping && <span className="form-error">{errors.dropping}</span>}
                </div>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className={styles.summary}>
            <div className={styles.card}>
              <h3 className={styles.summaryTitle}>Booking Summary</h3>
              <div className={styles.busInfo}>
                <div className={styles.busName}>{bus.operator}</div>
                <div className={styles.busType}>{getBusTypeLabel(bus.busType)}</div>
                <div className={styles.busTime}>{formatTime(bus.departureTime)} → {formatTime(bus.arrivalTime)}</div>
              </div>
              <hr className="divider" />
              <div className={styles.summaryRow}><span>Seats</span><span>{seats.map(s => s.seatNumber).join(', ')}</span></div>
              <div className={styles.summaryRow}><span>Base Fare ({seats.length} × {formatCurrency(bus.fare)})</span><span>{formatCurrency(totalFare)}</span></div>
              <div className={styles.summaryRow}><span>GST (5%)</span><span>{formatCurrency(gst)}</span></div>
              <div className={styles.summaryRow}><span>Convenience Fee</span><span>{formatCurrency(convenience)}</span></div>
              <hr className="divider" />
              <div className={styles.totalRow}><span>Total Payable</span><strong className={styles.totalAmt}>{formatCurrency(grandTotal)}</strong></div>
              <button className={`btn btn-primary btn-lg ${styles.proceedBtn}`} onClick={handleContinue}>
                Proceed to Payment
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
