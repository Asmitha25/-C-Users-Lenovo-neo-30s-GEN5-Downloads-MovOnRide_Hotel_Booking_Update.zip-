import React, { useState, useMemo } from 'react'
import MetroSearchForm from '../components/metro/MetroSearchForm'
import MetroRouteMap from '../components/metro/MetroRouteMap'
import MetroFareCalculator from '../components/metro/MetroFareCalculator'
import MetroTicketModal from '../components/metro/MetroTicketModal'
import { METRO_LINES, getJourney } from '../utils/metroData'
import styles from './MetroPage.module.css'
import { Train, MapPin, Clock, IndianRupee, Info } from 'lucide-react'

export default function MetroPage() {
  const [journey, setJourney] = useState(null)
  const [ticketModal, setTicketModal] = useState(false)

  const handleSearch = (from, to) => {
    const result = getJourney(from, to)
    setJourney(result)
  }

  return (
    <div className={styles.page}>
      {/* Hero */}
      <div className={styles.hero}>
        <div className="container">
          <div className={styles.heroContent}>
            <div className={styles.heroText}>
              <span className={styles.heroBadge}>🚇 Hyderabad Metro Rail</span>
              <h1 className={styles.heroTitle}>
                Hyderabad Metro<br />
                <span className={styles.heroAccent}>Fast · Clean · Reliable</span>
              </h1>
              <p className={styles.heroDesc}>
                68 stations across 3 lines. Book tokens, plan your journey, and explore the city with HMRL.
              </p>
              <div className={styles.heroStats}>
                <div className={styles.heroStat}><strong>69 km</strong><span>Network</span></div>
                <div className={styles.heroStatDiv} />
                <div className={styles.heroStat}><strong>57</strong><span>Stations</span></div>
                <div className={styles.heroStatDiv} />
                <div className={styles.heroStat}><strong>3</strong><span>Lines</span></div>
                <div className={styles.heroStatDiv} />
                <div className={styles.heroStat}><strong>5 AM – 11 PM</strong><span>Hours</span></div>
              </div>
            </div>
            <div className={styles.heroForm}>
              <MetroSearchForm onSearch={handleSearch} />
            </div>
          </div>
        </div>
      </div>

      <div className="container">
        {/* Journey result */}
        {journey && (
          <div className={styles.journeyResult}>
            <MetroFareCalculator journey={journey} onBook={() => setTicketModal(true)} />
          </div>
        )}

        {/* Line info cards */}
        <div className={styles.linesSection}>
          <h2 className={styles.sectionTitle}>Metro Lines</h2>
          <p className={styles.sectionSub}>Three corridors covering Hyderabad's key districts</p>
          <div className={styles.linesGrid}>
            {METRO_LINES.map(line => (
              <div key={line.id} className={styles.lineCard} style={{ '--line-color': line.color }}>
                <div className={styles.lineHeader}>
                  <div className={styles.lineDot} style={{ background: line.color }} />
                  <div>
                    <div className={styles.lineName}>{line.name}</div>
                    <div className={styles.lineRoute}>{line.from} ↔ {line.to}</div>
                  </div>
                  <span className={styles.lineBadge} style={{ background: line.color + '20', color: line.color }}>
                    Line {line.id}
                  </span>
                </div>
                <div className={styles.lineStats}>
                  <span><MapPin size={13} /> {line.stations} stations</span>
                  <span><Clock size={13} /> {line.length} km</span>
                  <span><IndianRupee size={13} /> ₹10 – ₹60</span>
                </div>
                <div className={styles.stationTags}>
                  {line.keyStations.map(s => (
                    <span key={s} className={styles.stationTag}>{s}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Route map */}
        <div className={styles.mapSection}>
          <h2 className={styles.sectionTitle}>Network Map</h2>
          <p className={styles.sectionSub}>Interactive station browser</p>
          <MetroRouteMap onStationClick={(s) => console.log(s)} />
        </div>

        {/* Fare table */}
        <div className={styles.fareSection}>
          <h2 className={styles.sectionTitle}>Fare Structure</h2>
          <p className={styles.sectionSub}>Distance-based fares as per HMRL</p>
          <div className={styles.fareTable}>
            {[
              { range: '0 – 2 km',  fare: '₹10' },
              { range: '2 – 4 km',  fare: '₹15' },
              { range: '4 – 6 km',  fare: '₹20' },
              { range: '6 – 9 km',  fare: '₹25' },
              { range: '9 – 12 km', fare: '₹30' },
              { range: '12 – 15 km', fare: '₹35' },
              { range: '15 – 20 km', fare: '₹40' },
              { range: '20 – 25 km', fare: '₹50' },
              { range: '25+ km',     fare: '₹60' },
            ].map(f => (
              <div key={f.range} className={styles.fareRow}>
                <span><MapPin size={13} /> {f.range}</span>
                <span className={styles.fareAmt}>{f.fare}</span>
              </div>
            ))}
          </div>
          <p className={styles.fareNote}>
            <Info size={13} /> Fares are indicative based on HMRL distance slabs. Actual fares may vary.
          </p>
        </div>

        {/* Tips */}
        <div className={styles.tipsSection}>
          <h2 className={styles.sectionTitle}>Travel Tips</h2>
          <div className={styles.tipsGrid}>
            {[
              { icon: '🕐', title: 'First & Last Train', desc: 'Metro runs 05:00 AM – 11:00 PM daily including Sundays.' },
              { icon: '🎫', title: 'Token vs Smart Card', desc: 'Smart cards give 5% discount. Available at all station counters.' },
              { icon: '♿', title: 'Accessibility', desc: 'All stations have lifts, ramps, and tactile paths for differently-abled commuters.' },
              { icon: '🚌', title: 'Last Mile', desc: 'TSRTC feeder buses and auto-rickshaws available at most stations.' },
              { icon: '🔒', title: 'Safety', desc: 'CCTV surveillance and RPF personnel present at all stations 24×7.' },
              { icon: '📱', title: 'T-Wallet', desc: 'Recharge your Hyderabad Metro Smart Card using T-Wallet mobile app.' },
            ].map(t => (
              <div key={t.title} className={styles.tipCard}>
                <span className={styles.tipIcon}>{t.icon}</span>
                <div>
                  <strong className={styles.tipTitle}>{t.title}</strong>
                  <p className={styles.tipDesc}>{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {ticketModal && journey && (
        <MetroTicketModal journey={journey} onClose={() => setTicketModal(false)} />
      )}
    </div>
  )
}
