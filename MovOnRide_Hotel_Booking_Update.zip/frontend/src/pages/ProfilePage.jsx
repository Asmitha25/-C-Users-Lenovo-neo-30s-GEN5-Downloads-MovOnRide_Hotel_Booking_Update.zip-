import React, { useState } from 'react'
import { User, Phone, Mail, Lock, Save } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { userAPI } from '../services/api'
import toast from 'react-hot-toast'
import styles from './ProfilePage.module.css'

export default function ProfilePage() {
  const { user, updateUser } = useAuth()
  const [form, setForm] = useState({ first_name: user?.first_name || '', last_name: user?.last_name || '', mobile: user?.mobile || '' })
  const [pwd, setPwd] = useState({ old: '', new: '', confirm: '' })
  const [saving, setSaving] = useState(false)
  const [savingPwd, setSavingPwd] = useState(false)

  const saveProfile = async (e) => {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await userAPI.updateProfile(form)
      updateUser(res.data)
      toast.success('Profile updated')
    } catch {
      toast.error('Failed to update profile')
    } finally {
      setSaving(false)
    }
  }

  const savePassword = async (e) => {
    e.preventDefault()
    if (pwd.new !== pwd.confirm) { toast.error('Passwords do not match'); return }
    if (pwd.new.length < 8) { toast.error('Password must be at least 8 characters'); return }
    setSavingPwd(true)
    try {
      await userAPI.changePassword({ old_password: pwd.old, new_password: pwd.new })
      toast.success('Password changed')
      setPwd({ old: '', new: '', confirm: '' })
    } catch {
      toast.error('Failed to change password')
    } finally {
      setSavingPwd(false)
    }
  }

  return (
    <div className={styles.page}>
      <div className="container">
        <h1 className={styles.pageTitle}>My Profile</h1>
        <div className={styles.layout}>
          {/* Avatar section */}
          <div className={styles.avatarCard}>
            <div className={styles.avatar}>{user?.first_name?.[0] || 'U'}</div>
            <div className={styles.userName}>{user?.first_name} {user?.last_name}</div>
            <div className={styles.userEmail}>{user?.email}</div>
            <div className={`badge ${user?.is_staff ? 'badge-info' : 'badge-gray'}`} style={{ marginTop: '0.75rem' }}>{user?.is_staff ? 'Admin' : 'Traveler'}</div>
          </div>

          <div className={styles.forms}>
            {/* Profile form */}
            <div className={styles.card}>
              <h2 className={styles.cardTitle}><User size={18} /> Personal Information</h2>
              <form onSubmit={saveProfile}>
                <div className={styles.grid2}>
                  <div className="form-group">
                    <label className="form-label">First Name</label>
                    <input className="form-control" value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Last Name</label>
                    <input className="form-control" value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} />
                  </div>
                  <div className="form-group">
                    <label className="form-label"><Mail size={13} /> Email</label>
                    <input className="form-control" value={user?.email || ''} disabled style={{ opacity: 0.6 }} />
                  </div>
                  <div className="form-group">
                    <label className="form-label"><Phone size={13} /> Mobile</label>
                    <input className="form-control" type="tel" value={form.mobile} onChange={e => setForm({ ...form, mobile: e.target.value })} />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary" style={{ marginTop: '1rem' }} disabled={saving}>
                  <Save size={15} /> {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </form>
            </div>

            {/* Password form */}
            <div className={styles.card}>
              <h2 className={styles.cardTitle}><Lock size={18} /> Change Password</h2>
              <form onSubmit={savePassword}>
                <div className={styles.grid2}>
                  <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                    <label className="form-label">Current Password</label>
                    <input type="password" className="form-control" value={pwd.old} onChange={e => setPwd({ ...pwd, old: e.target.value })} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">New Password</label>
                    <input type="password" className="form-control" value={pwd.new} onChange={e => setPwd({ ...pwd, new: e.target.value })} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Confirm New Password</label>
                    <input type="password" className="form-control" value={pwd.confirm} onChange={e => setPwd({ ...pwd, confirm: e.target.value })} />
                  </div>
                </div>
                <button type="submit" className="btn btn-outline" style={{ marginTop: '1rem' }} disabled={savingPwd}>
                  {savingPwd ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
