import React, { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { CheckCircle2, Download, Printer, Home, ArrowRight } from 'lucide-react'
import { formatTime, formatDate, formatCurrency, getBusTypeLabel } from '../utils/helpers'
import styles from './BookingConfirmationPage.module.css'

export default function BookingConfirmationPage() {
  const { bookingId } = useParams()
  const navigate = useNavigate()
  const [booking, setBooking] = useState(null)
  const ticketRef = useRef()

  useEffect(() => {
    const data = sessionStorage.getItem('confirmedBooking')
    if (data) {
      setBooking(JSON.parse(data))
    }
  }, [bookingId])

  const handlePrint = () => window.print()

  if (!booking) return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '60vh', gap: '1rem' }}>
      <span style={{ fontSize: '3rem' }}>🔍</span>
      <h3>Booking not found</h3>
      <Link to="/" className="btn btn-primary">Go Home</Link>
    </div>
  )

  const { bus, seats, passengers, contact, boarding, dropping, pnr, total, paymentStatus } = booking

  return (
    <div className={styles.page}>
      <div className="container">
        {/* Success banner */}
        <div className={styles.successBanner}>
          <CheckCircle2 size={40} color="#16a34a" />
          <div>
            <h1 className={styles.successTitle}>Booking Confirmed!</h1>
            <p className={styles.successSub}>Your ticket has been booked. A confirmation will be sent to {contact?.email}.</p>
          </div>
        </div>

        {/* Ticket */}
        <div className={styles.ticket} ref={ticketRef}>
          <div className={styles.ticketHeader}>
            <div className={styles.ticketBrand}>🚌 MovonRide</div>
            <div className={styles.ticketPNR}>
              <span className={styles.pnrLabel}>PNR / Booking ID</span>
              <span className={styles.pnrValue}>{pnr || bookingId}</span>
            </div>
            <span className={`badge badge-success ${styles.statusBadge}`}>✓ {paymentStatus || 'CONFIRMED'}</span>
          </div>

          <div className={styles.ticketBody}>
            {/* Route info */}
            <div className={styles.routeSection}>
              <div className={styles.routePoint}>
                <span className={styles.routeTime}>{formatTime(bus?.departureTime)}</span>
                <span className={styles.routeCity}>{bus?.from}</span>
                <span className={styles.routeStop}>{boarding}</span>
              </div>
              <div className={styles.routeMiddle}>
                <div className={styles.routeLine} />
                <span className={styles.routeBus}>🚌 {getBusTypeLabel(bus?.busType)}</span>
                <div className={styles.routeLine} />
              </div>
              <div className={`${styles.routePoint} ${styles.routePointRight}`}>
                <span className={styles.routeTime}>{formatTime(bus?.arrivalTime)}</span>
                <span className={styles.routeCity}>{bus?.to}</span>
                <span className={styles.routeStop}>{dropping}</span>
              </div>
            </div>

            <div className={styles.ticketDivider}>
              <div className={styles.notchLeft} />
              <div className={styles.dottedLine} />
              <div className={styles.notchRight} />
            </div>

            {/* Details grid */}
            <div className={styles.detailsGrid}>
              <div className={styles.detailItem}>
                <span className={styles.dLabel}>Operator</span>
                <span className={styles.dVal}>{bus?.operator}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.dLabel}>Journey Date</span>
                <span className={styles.dVal}>{formatDate(bus?.date || new Date().toISOString())}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.dLabel}>Seats</span>
                <span className={styles.dVal}>{seats?.map(s => s.seatNumber).join(', ')}</span>
              </div>
              <div className={styles.detailItem}>
                <span className={styles.dLabel}>Amount Paid</span>
                <span className={styles.dVal} style={{ color: '#16a34a', fontWeight: 800 }}>{formatCurrency(total)}</span>
              </div>
            </div>

            {/* Passengers */}
            <div className={styles.passengersSection}>
              <div className={styles.passengerTitle}>Passengers</div>
              <div className={styles.passengersList}>
                {passengers?.map((p, i) => (
                  <div key={i} className={styles.pRow}>
                    <span className={styles.pBadge}>{seats?.[i]?.seatNumber}</span>
                    <span className={styles.pName}>{p.fullName}</span>
                    <span className={styles.pMeta}>{p.age} yrs · {p.gender}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className={styles.ticketNote}>
              ⚠ This is a demo booking on a sample platform. No real journey is confirmed.
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className={styles.actions}>
          <button className="btn btn-ghost" onClick={handlePrint}>
            <Printer size={16} /> Print Ticket
          </button>
          <button className="btn btn-ghost" onClick={handlePrint}>
            <Download size={16} /> Download PDF
          </button>
          <Link to="/my-bookings" className="btn btn-outline">
            My Bookings
          </Link>
          <Link to="/" className="btn btn-primary">
            <Home size={16} /> Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}
