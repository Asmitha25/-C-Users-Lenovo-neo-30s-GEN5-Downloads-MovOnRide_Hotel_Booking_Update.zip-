import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Info } from 'lucide-react'
import { busAPI } from '../services/api'
import { formatTime, formatCurrency, getBusTypeLabel } from '../utils/helpers'
import styles from './SeatSelectionPage.module.css'

// Generate demo seats
const generateDemoSeats = (totalSeats, busType) => {
  const isSleeper = busType.includes('SLEEPER')
  const seats = []
  const bookedIndices = new Set([2, 5, 8, 12, 15, 18, 22, 25, 28])
  for (let i = 1; i <= totalSeats; i++) {
    const isUpper = isSleeper && i > totalSeats / 2
    seats.push({
      id: i,
      seatNumber: `${isUpper ? 'U' : 'L'}${i}`,
      isBooked: bookedIndices.has(i),
      isUpper,
      gender: null,
    })
  }
  return seats
}

export default function SeatSelectionPage() {
  const { scheduleId } = useParams()
  const navigate = useNavigate()
  const [bus, setBus] = useState(null)
  const [seats, setSeats] = useState([])
  const [selected, setSelected] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const savedBus = sessionStorage.getItem('selectedBus')
    if (savedBus) {
      const b = JSON.parse(savedBus)
      setBus(b)
      // Try to fetch real seats, fallback to demo
      busAPI.getSeats(scheduleId)
        .then(res => setSeats(res.data))
        .catch(() => setSeats(generateDemoSeats(b.totalSeats || 40, b.busType)))
        .finally(() => setLoading(false))
    } else {
      navigate('/search')
    }
  }, [scheduleId])

  const toggleSeat = (seat) => {
    if (seat.isBooked) return
    setSelected(prev =>
      prev.find(s => s.id === seat.id)
        ? prev.filter(s => s.id !== seat.id)
        : [...prev, seat]
    )
  }

  const handleContinue = () => {
    if (selected.length === 0) return
    sessionStorage.setItem('selectedSeats', JSON.stringify(selected))
    navigate('/passenger-details')
  }

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '60vh' }}>
      <div className="spinner" style={{ width: 36, height: 36 }} />
    </div>
  )

  const lowerSeats = seats.filter(s => !s.isUpper)
  const upperSeats = seats.filter(s => s.isUpper)
  const isSleeper = bus?.busType?.includes('SLEEPER')
  const totalFare = selected.length * (bus?.fare || 0)

  const renderSeat = (seat) => {
    const isSelected = selected.find(s => s.id === seat.id)
    return (
      <button
        key={seat.id}
        className={`${styles.seat} ${seat.isBooked ? styles.seatBooked : ''} ${isSelected ? styles.seatSelected : styles.seatAvailable}`}
        onClick={() => toggleSeat(seat)}
        disabled={seat.isBooked}
        title={seat.isBooked ? 'Already booked' : seat.seatNumber}
        aria-label={`Seat ${seat.seatNumber} - ${seat.isBooked ? 'Booked' : isSelected ? 'Selected' : 'Available'}`}
      >
        {isSleeper ? (
          <span className={styles.sleeperSeat} />
        ) : (
          <span className={styles.seatIcon}>💺</span>
        )}
        <span className={styles.seatNum}>{seat.seatNumber}</span>
      </button>
    )
  }

  return (
    <div className={styles.page}>
      <div className="container">
        {/* Header */}
        <div className={styles.header}>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)}>
            <ArrowLeft size={16} /> Back
          </button>
          <div>
            <h1 className={styles.title}>Select Your Seats</h1>
            <p className={styles.subtitle}>{bus?.operator} · {getBusTypeLabel(bus?.busType)} · {formatTime(bus?.departureTime)} → {formatTime(bus?.arrivalTime)}</p>
          </div>
        </div>

        <div className={styles.layout}>
          {/* Bus layout */}
          <div className={styles.busLayout}>
            <div className={styles.layoutHeader}>
              <div className={styles.busIcon}>🚌</div>
              <div className={styles.legend}>
                <span className={styles.legendItem}><span className={styles.legendAvail} /> Available</span>
                <span className={styles.legendItem}><span className={styles.legendSelected} /> Selected</span>
                <span className={styles.legendItem}><span className={styles.legendBooked} /> Booked</span>
              </div>
            </div>

            {isSleeper ? (
              <div className={styles.sleeperLayout}>
                {upperSeats.length > 0 && (
                  <div className={styles.tier}>
                    <div className={styles.tierLabel}>Upper Berth</div>
                    <div className={styles.seatsGrid}>{upperSeats.map(renderSeat)}</div>
                  </div>
                )}
                <div className={styles.tierDivider} />
                <div className={styles.tier}>
                  <div className={styles.tierLabel}>Lower Berth</div>
                  <div className={styles.seatsGrid}>{lowerSeats.map(renderSeat)}</div>
                </div>
              </div>
            ) : (
              <div>
                <div className={styles.seaterLayout}>
                  {(() => {
                    const rows = []
                    for (let i = 0; i < seats.length; i += 4) {
                      const row = seats.slice(i, i + 4)
                      rows.push(
                        <div key={i} className={styles.seatRow}>
                          <div className={styles.seatPair}>{row.slice(0, 2).map(renderSeat)}</div>
                          <div className={styles.aisle} />
                          <div className={styles.seatPair}>{row.slice(2).map(renderSeat)}</div>
                        </div>
                      )
                    }
                    return rows
                  })()}
                </div>
              </div>
            )}
          </div>

          {/* Fare summary */}
          <div className={styles.summary}>
            <h3 className={styles.summaryTitle}>Fare Summary</h3>

            <div className={styles.summarySection}>
              <div className={styles.summaryRow}>
                <span>Price per seat</span>
                <span>{formatCurrency(bus?.fare || 0)}</span>
              </div>
              <div className={styles.summaryRow}>
                <span>Seats selected</span>
                <span>{selected.length}</span>
              </div>
              {selected.length > 0 && (
                <div className={styles.selectedSeats}>
                  {selected.map(s => (
                    <span key={s.id} className={styles.seatTag}>{s.seatNumber}</span>
                  ))}
                </div>
              )}
            </div>

            <div className={styles.divider} />
            <div className={styles.totalRow}>
              <span>Total Fare</span>
              <span className={styles.total}>{formatCurrency(totalFare)}</span>
            </div>

            <button
              className={`btn btn-primary btn-lg ${styles.continueBtn}`}
              onClick={handleContinue}
              disabled={selected.length === 0}
            >
              Continue ({selected.length} seat{selected.length !== 1 ? 's' : ''})
            </button>

            <div className={styles.info}>
              <Info size={12} />
              <span>Seats are temporarily reserved for 10 minutes after selection.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
