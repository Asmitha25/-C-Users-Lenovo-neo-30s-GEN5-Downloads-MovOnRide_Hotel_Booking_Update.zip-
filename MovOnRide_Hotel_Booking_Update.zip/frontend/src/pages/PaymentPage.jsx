import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  ArrowLeft, Shield, AlertCircle, ChevronRight,
  CreditCard, Smartphone, Building2, Wallet, BadgeIndianRupee, CheckCircle2,
} from 'lucide-react'
import { paymentAPI, bookingAPI } from '../services/api'
import { formatCurrency, getBusTypeLabel, formatTime, generatePNR } from '../utils/helpers'
import toast from 'react-hot-toast'
import styles from './PaymentPage.module.css'

/* ── Payment method definitions ───────────────────────────── */
const METHODS = [
  {
    id: 'upi',
    label: 'UPI',
    icon: <BadgeIndianRupee size={20} />,
    color: '#7c3aed',
    bg: '#f5f3ff',
    desc: 'Pay instantly using any UPI app',
    apps: [
      { id: 'gpay',     label: 'Google Pay',  logo: '🟢', hint: 'yourname@okaxis' },
      { id: 'phonepe',  label: 'PhonePe',     logo: '🟣', hint: 'yourname@ybl'  },
      { id: 'paytm',    label: 'Paytm',       logo: '🔵', hint: 'yourname@paytm' },
      { id: 'bhim',     label: 'BHIM',        logo: '🟠', hint: 'yourname@upi'  },
      { id: 'other',    label: 'Other UPI',   logo: '💸', hint: 'yourname@bank'  },
    ],
  },
  {
    id: 'card',
    label: 'Credit / Debit Card',
    icon: <CreditCard size={20} />,
    color: '#0891b2',
    bg: '#f0f9ff',
    desc: 'Visa, Mastercard, RuPay, Amex',
    networks: ['VISA', 'Mastercard', 'RuPay', 'Amex'],
  },
  {
    id: 'netbanking',
    label: 'Net Banking',
    icon: <Building2 size={20} />,
    color: '#059669',
    bg: '#f0fdf4',
    desc: 'All major Indian banks supported',
    banks: [
      { id: 'sbi',    label: 'State Bank of India' },
      { id: 'hdfc',   label: 'HDFC Bank'           },
      { id: 'icici',  label: 'ICICI Bank'           },
      { id: 'axis',   label: 'Axis Bank'            },
      { id: 'kotak',  label: 'Kotak Mahindra'       },
      { id: 'pnb',    label: 'Punjab National Bank' },
      { id: 'bob',    label: 'Bank of Baroda'       },
      { id: 'idfc',   label: 'IDFC FIRST Bank'      },
      { id: 'other',  label: 'Other Bank'           },
    ],
  },
  {
    id: 'wallet',
    label: 'Wallets',
    icon: <Wallet size={20} />,
    color: '#d97706',
    bg: '#fffbeb',
    desc: 'Paytm, Amazon Pay, Mobikwik & more',
    wallets: [
      { id: 'paytm',  label: 'Paytm Wallet',  logo: '🔵' },
      { id: 'amazon', label: 'Amazon Pay',     logo: '🟡' },
      { id: 'mobikwik', label: 'MobiKwik',     logo: '🔴' },
      { id: 'freecharge', label: 'FreeCharge', logo: '🟠' },
      { id: 'airtel', label: 'Airtel Money',   logo: '🔴' },
    ],
  },
  {
    id: 'emi',
    label: 'EMI',
    icon: <CreditCard size={20} />,
    color: '#e53935',
    bg: '#fff5f5',
    desc: 'No-cost EMI on select cards',
    plans: [
      { months: 3,  rate: 0,    label: 'No-cost 3 months' },
      { months: 6,  rate: 13.5, label: '6 months @ 13.5% p.a.' },
      { months: 9,  rate: 13.5, label: '9 months @ 13.5% p.a.' },
      { months: 12, rate: 14.0, label: '12 months @ 14% p.a.' },
    ],
  },
  {
    id: 'mock',
    label: 'Test / Demo Pay',
    icon: <CheckCircle2 size={20} />,
    color: '#6b7280',
    bg: '#f9fafb',
    desc: 'Instant demo — no real money',
  },
]

/* ── Small helpers ──────────────────────────────────────────── */
function MethodHeader({ m, active, onClick }) {
  return (
    <button
      type="button"
      className={`${styles.methodTab} ${active ? styles.methodTabActive : ''}`}
      style={active ? { borderColor: m.color, background: m.bg } : {}}
      onClick={onClick}
    >
      <span className={styles.methodTabIcon} style={{ color: active ? m.color : '#6b7280' }}>
        {m.icon}
      </span>
      <div className={styles.methodTabText}>
        <strong>{m.label}</strong>
        <small>{m.desc}</small>
      </div>
      <ChevronRight size={16} className={`${styles.methodChevron} ${active ? styles.methodChevronActive : ''}`} style={{ color: m.color }} />
    </button>
  )
}

/* ── UPI form ───────────────────────────────────────────────── */
function UpiForm({ data, onChange }) {
  const m = METHODS.find(m => m.id === 'upi')
  return (
    <div className={styles.innerForm}>
      <p className={styles.innerLabel}>Select UPI App</p>
      <div className={styles.appGrid}>
        {m.apps.map(a => (
          <button
            key={a.id}
            type="button"
            className={`${styles.appBtn} ${data.upiApp === a.id ? styles.appBtnActive : ''}`}
            onClick={() => onChange({ ...data, upiApp: a.id })}
          >
            <span className={styles.appLogo}>{a.logo}</span>
            <span>{a.label}</span>
          </button>
        ))}
      </div>
      {data.upiApp && (
        <div className="form-group" style={{ marginTop: '1rem' }}>
          <label className="form-label">UPI ID</label>
          <input
            className="form-control"
            placeholder={m.apps.find(a => a.id === data.upiApp)?.hint || 'yourname@bank'}
            value={data.upiId || ''}
            onChange={e => onChange({ ...data, upiId: e.target.value })}
          />
          <span style={{ fontSize: '.75rem', color: '#9ca3af', marginTop: '.25rem', display: 'block' }}>
            You will receive a payment request on your UPI app
          </span>
        </div>
      )}
    </div>
  )
}

/* ── Card form ──────────────────────────────────────────────── */
function CardForm({ data, onChange }) {
  const fmt = (v) => v.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim()
  const fmtExp = (v) => {
    const d = v.replace(/\D/g, '').slice(0, 4)
    return d.length >= 3 ? d.slice(0, 2) + '/' + d.slice(2) : d
  }
  return (
    <div className={styles.innerForm}>
      <div className={styles.cardNetworks}>
        {['VISA', 'MC', 'RuPay', 'Amex'].map(n => (
          <span key={n} className={styles.cardNetwork}>{n}</span>
        ))}
      </div>
      <div className="form-group" style={{ marginBottom: '.875rem' }}>
        <label className="form-label">Card Number</label>
        <input
          className="form-control"
          placeholder="1234 5678 9012 3456"
          value={fmt(data.cardNumber || '')}
          onChange={e => onChange({ ...data, cardNumber: e.target.value.replace(/\s/g, '') })}
          maxLength={19}
        />
      </div>
      <div className="form-group" style={{ marginBottom: '.875rem' }}>
        <label className="form-label">Cardholder Name</label>
        <input
          className="form-control"
          placeholder="Name on card"
          value={data.cardName || ''}
          onChange={e => onChange({ ...data, cardName: e.target.value })}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '.875rem' }}>
        <div className="form-group">
          <label className="form-label">Expiry (MM/YY)</label>
          <input
            className="form-control"
            placeholder="MM/YY"
            value={fmtExp(data.cardExpiry || '')}
            onChange={e => onChange({ ...data, cardExpiry: e.target.value })}
            maxLength={5}
          />
        </div>
        <div className="form-group">
          <label className="form-label">CVV</label>
          <input
            className="form-control"
            placeholder="•••"
            type="password"
            maxLength={4}
            value={data.cardCvv || ''}
            onChange={e => onChange({ ...data, cardCvv: e.target.value.replace(/\D/g, '') })}
          />
        </div>
      </div>
      <label className={styles.saveCard}>
        <input type="checkbox" checked={!!data.saveCard} onChange={e => onChange({ ...data, saveCard: e.target.checked })} />
        Save card for future payments (securely encrypted)
      </label>
    </div>
  )
}

/* ── Net Banking form ───────────────────────────────────────── */
function NetBankingForm({ data, onChange }) {
  const m = METHODS.find(m => m.id === 'netbanking')
  return (
    <div className={styles.innerForm}>
      <p className={styles.innerLabel}>Select Your Bank</p>
      <div className={styles.bankGrid}>
        {m.banks.map(b => (
          <button
            key={b.id}
            type="button"
            className={`${styles.bankBtn} ${data.bank === b.id ? styles.bankBtnActive : ''}`}
            onClick={() => onChange({ ...data, bank: b.id })}
          >
            <span className={styles.bankLogo}>🏦</span>
            <span className={styles.bankLabel}>{b.label}</span>
          </button>
        ))}
      </div>
      {data.bank && (
        <div className={styles.bankNote}>
          You will be redirected to {m.banks.find(b => b.id === data.bank)?.label}'s secure net banking portal.
        </div>
      )}
    </div>
  )
}

/* ── Wallets form ───────────────────────────────────────────── */
function WalletForm({ data, onChange }) {
  const m = METHODS.find(m => m.id === 'wallet')
  return (
    <div className={styles.innerForm}>
      <p className={styles.innerLabel}>Select Wallet</p>
      <div className={styles.appGrid}>
        {m.wallets.map(w => (
          <button
            key={w.id}
            type="button"
            className={`${styles.appBtn} ${data.wallet === w.id ? styles.appBtnActive : ''}`}
            onClick={() => onChange({ ...data, wallet: w.id })}
          >
            <span className={styles.appLogo}>{w.logo}</span>
            <span>{w.label}</span>
          </button>
        ))}
      </div>
      {data.wallet && (
        <div className="form-group" style={{ marginTop: '1rem' }}>
          <label className="form-label">Registered Mobile Number</label>
          <input
            className="form-control"
            placeholder="10-digit mobile"
            maxLength={10}
            value={data.walletMobile || ''}
            onChange={e => onChange({ ...data, walletMobile: e.target.value.replace(/\D/g, '') })}
          />
        </div>
      )}
    </div>
  )
}

/* ── EMI form ───────────────────────────────────────────────── */
function EmiForm({ data, onChange, total }) {
  const m = METHODS.find(m => m.id === 'emi')
  return (
    <div className={styles.innerForm}>
      <p className={styles.innerLabel}>Select EMI Plan</p>
      <div className={styles.emiGrid}>
        {m.plans.map(p => {
          const monthly = p.rate === 0
            ? (total / p.months).toFixed(0)
            : (total * (1 + (p.rate / 100) * (p.months / 12)) / p.months).toFixed(0)
          return (
            <button
              key={p.months}
              type="button"
              className={`${styles.emiBtn} ${data.emiPlan === p.months ? styles.emiBtnActive : ''}`}
              onClick={() => onChange({ ...data, emiPlan: p.months })}
            >
              <div className={styles.emiMonths}>{p.months} months</div>
              <div className={styles.emiMonthly}>₹{monthly}/mo</div>
              {p.rate === 0 && <span className={styles.emiNoCost}>No-cost</span>}
            </button>
          )
        })}
      </div>
      {data.emiPlan && (
        <div className={styles.emiCardNote}>
          <AlertCircle size={13} /> EMI requires a credit card. Enter card details after selecting plan.
        </div>
      )}
    </div>
  )
}

/* ── Main component ─────────────────────────────────────────── */
export default function PaymentPage() {
  const navigate = useNavigate()
  const [booking, setBooking] = useState(null)
  const [method, setMethod] = useState('upi')
  const [formData, setFormData] = useState({})
  const [processing, setProcessing] = useState(false)
  const [step, setStep] = useState('pay') // 'pay' | 'processing' | 'done'

  useEffect(() => {
    const data = sessionStorage.getItem('bookingDetails')
    if (!data) { navigate('/search'); return }
    setBooking(JSON.parse(data))
  }, [])

  if (!booking) return null

  const { bus, seats, passengers, contact, boarding, dropping } = booking
  const baseFare = seats.length * bus.fare
  const gst      = Math.round(baseFare * 0.05)
  const convenience = 49
  const total    = baseFare + gst + convenience

  /* Validate before paying */
  const validate = () => {
    if (method === 'upi') {
      if (!formData.upiApp) { toast.error('Select a UPI app'); return false }
      if (!formData.upiId?.trim()) { toast.error('Enter your UPI ID'); return false }
    }
    if (method === 'card') {
      if (!formData.cardNumber || formData.cardNumber.length < 15) { toast.error('Enter a valid card number'); return false }
      if (!formData.cardName?.trim()) { toast.error('Enter cardholder name'); return false }
      if (!formData.cardExpiry || formData.cardExpiry.length < 4) { toast.error('Enter valid expiry'); return false }
      if (!formData.cardCvv || formData.cardCvv.length < 3) { toast.error('Enter valid CVV'); return false }
    }
    if (method === 'netbanking') {
      if (!formData.bank) { toast.error('Select your bank'); return false }
    }
    if (method === 'wallet') {
      if (!formData.wallet) { toast.error('Select a wallet'); return false }
      if (!formData.walletMobile || formData.walletMobile.length !== 10) { toast.error('Enter 10-digit mobile number'); return false }
    }
    if (method === 'emi') {
      if (!formData.emiPlan) { toast.error('Select an EMI plan'); return false }
    }
    return true
  }

  const handlePay = async () => {
    if (!validate()) return
    setProcessing(true)
    setStep('processing')

    // Simulate network delay for realism (500ms–1.5s)
    await new Promise(r => setTimeout(r, method === 'mock' ? 500 : 1500))

    try {
      const pnr = generatePNR()
      let bookingId = pnr

      // Try real API
      try {
        const res = await bookingAPI.create({
          schedule: bus.scheduleId,
          seats: seats.map(s => s.id),
          passengers,
          contact_email: contact.email,
          contact_mobile: contact.mobile,
          boarding_point: boarding,
          dropping_point: dropping,
        })
        bookingId = res.data.id || pnr
        await paymentAPI.mockPay({ booking_id: bookingId, amount: total })
      } catch {
        bookingId = pnr
      }

      const methodLabel = {
        upi:        `UPI – ${formData.upiId || ''}`,
        card:       `Card ending ****${(formData.cardNumber || '').slice(-4)}`,
        netbanking: `Net Banking – ${METHODS.find(m=>m.id==='netbanking')?.banks.find(b=>b.id===formData.bank)?.label || ''}`,
        wallet:     `${METHODS.find(m=>m.id==='wallet')?.wallets.find(w=>w.id===formData.wallet)?.label || ''} Wallet`,
        emi:        `EMI – ${formData.emiPlan} months`,
        mock:       'Demo / Test Payment',
      }[method]

      sessionStorage.setItem('confirmedBooking', JSON.stringify({
        ...booking, bookingId, pnr, total,
        paymentStatus: 'PAID',
        paymentMethod: methodLabel,
      }))
      toast.success('Payment successful! 🎉')
      navigate(`/booking-confirmation/${bookingId}`)
    } catch {
      toast.error('Payment failed. Please try again.')
      setStep('pay')
    } finally {
      setProcessing(false)
    }
  }

  const activeMethod = METHODS.find(m => m.id === method)

  return (
    <div className={styles.page}>
      <div className="container">
        <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: '1.25rem' }}>
          <ArrowLeft size={16} /> Back
        </button>

        {/* Processing overlay */}
        {step === 'processing' && (
          <div className={styles.processingOverlay}>
            <div className={styles.processingCard}>
              <div className={styles.processingSpinner} />
              <h3>Processing Payment</h3>
              <p>Please do not refresh or go back…</p>
              <span className={styles.processingMethod}>{activeMethod?.label}</span>
            </div>
          </div>
        )}

        <div className={styles.layout}>
          {/* ── Left column ── */}
          <div className={styles.left}>

            {/* Booking summary */}
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}>Booking Summary</h2>
              <div className={styles.summaryGrid}>
                <div className={styles.summaryItem}><span>Bus Operator</span><strong>{bus.operator}</strong></div>
                <div className={styles.summaryItem}><span>Bus Type</span><strong>{getBusTypeLabel(bus.busType)}</strong></div>
                <div className={styles.summaryItem}><span>Departure</span><strong>{formatTime(bus.departureTime)}</strong></div>
                <div className={styles.summaryItem}><span>Arrival</span><strong>{formatTime(bus.arrivalTime)}</strong></div>
                <div className={styles.summaryItem}><span>Seats</span><strong>{seats.map(s => s.seatNumber).join(', ')}</strong></div>
                <div className={styles.summaryItem}><span>Boarding</span><strong>{boarding}</strong></div>
              </div>
            </div>

            {/* Passengers */}
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}>Passenger Details</h2>
              <div className={styles.passengerList}>
                {passengers.map((p, i) => (
                  <div key={i} className={styles.passengerRow}>
                    <span className={styles.pSeat}>{seats[i]?.seatNumber}</span>
                    <span className={styles.pName}>{p.fullName}</span>
                    <span className={styles.pMeta}>{p.age} yrs · {p.gender}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Payment Methods ── */}
            <div className={styles.card}>
              <h2 className={styles.sectionTitle}>
                <CreditCard size={18} /> Choose Payment Method
              </h2>

              <div className={styles.methodsLayout}>
                {/* Left: method tabs */}
                <div className={styles.methodList}>
                  {METHODS.map(m => (
                    <MethodHeader
                      key={m.id}
                      m={m}
                      active={method === m.id}
                      onClick={() => { setMethod(m.id); setFormData({}) }}
                    />
                  ))}
                </div>

                {/* Right: method-specific form */}
                <div className={styles.methodPanel} style={{ borderColor: activeMethod?.color + '40' }}>
                  <div className={styles.methodPanelHeader} style={{ background: activeMethod?.bg }}>
                    <span style={{ color: activeMethod?.color }}>{activeMethod?.icon}</span>
                    <div>
                      <strong>{activeMethod?.label}</strong>
                      <small>{activeMethod?.desc}</small>
                    </div>
                  </div>

                  {method === 'upi'        && <UpiForm data={formData} onChange={setFormData} />}
                  {method === 'card'       && <CardForm data={formData} onChange={setFormData} />}
                  {method === 'netbanking' && <NetBankingForm data={formData} onChange={setFormData} />}
                  {method === 'wallet'     && <WalletForm data={formData} onChange={setFormData} />}
                  {method === 'emi'        && <EmiForm data={formData} onChange={setFormData} total={total} />}
                  {method === 'mock'       && (
                    <div className={styles.mockInner}>
                      <div className={styles.mockIcon}>🧪</div>
                      <p>This is a <strong>demo payment</strong>. Click "Pay" to simulate a successful transaction instantly.</p>
                      <p>No real money is charged.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className={styles.demoBanner}>
                <AlertCircle size={13} />
                <span>Demo platform — all payment methods are simulated. No real transactions occur.</span>
              </div>
            </div>
          </div>

          {/* ── Right column — fare summary ── */}
          <div className={styles.right}>
            <div className={styles.card}>
              <h3 className={styles.fareTitle}>Fare Breakdown</h3>

              <div className={styles.fareRow}>
                <span>Base Fare ({seats.length} seat{seats.length !== 1 ? 's' : ''})</span>
                <span>{formatCurrency(baseFare)}</span>
              </div>
              <div className={styles.fareRow}>
                <span>GST (5%)</span>
                <span>{formatCurrency(gst)}</span>
              </div>
              <div className={styles.fareRow}>
                <span>Convenience Fee</span>
                <span>{formatCurrency(convenience)}</span>
              </div>
              {method === 'emi' && formData.emiPlan && (
                <div className={`${styles.fareRow} ${styles.fareRowEmi}`}>
                  <span>EMI ({formData.emiPlan} months)</span>
                  <span>₹{(total / formData.emiPlan).toFixed(0)}/mo</span>
                </div>
              )}

              <hr className="divider" />
              <div className={styles.totalRow}>
                <strong>Total Payable</strong>
                <strong className={styles.total}>{formatCurrency(total)}</strong>
              </div>

              {/* Selected method indicator */}
              <div className={styles.selectedMethod} style={{ borderColor: activeMethod?.color + '60', background: activeMethod?.bg }}>
                <span style={{ color: activeMethod?.color }}>{activeMethod?.icon}</span>
                <span style={{ fontSize: '.85rem', fontWeight: 600, color: '#374151' }}>{activeMethod?.label}</span>
              </div>

              <button
                className={`btn btn-primary btn-lg ${styles.payBtn}`}
                onClick={handlePay}
                disabled={processing}
              >
                {processing
                  ? <><span className="spinner" style={{ borderTopColor: '#fff' }} /> Processing…</>
                  : <>🔒 Pay {formatCurrency(total)}</>
                }
              </button>

              <div className={styles.secureRow}>
                <Shield size={13} />
                <span>256-bit SSL encrypted · PCI DSS compliant</span>
              </div>

              <div className={styles.acceptedLogos}>
                {['VISA', 'MC', 'RuPay', 'UPI', 'GPay', 'PhonePe'].map(l => (
                  <span key={l} className={styles.acceptedLogo}>{l}</span>
                ))}
              </div>
            </div>

            {/* Cancel policy */}
            <div className={styles.policyCard}>
              <strong className={styles.policyTitle}>Cancellation Policy</strong>
              <ul className={styles.policyList}>
                <li>Cancel 2+ hours before departure → 90% refund</li>
                <li>Cancel 1–2 hours before → 50% refund</li>
                <li>Cancel under 1 hour → No refund</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
