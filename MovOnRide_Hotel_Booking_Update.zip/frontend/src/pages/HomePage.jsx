import React from 'react'
import HeroSection from '../components/home/HeroSection'
import PopularRoutes from '../components/home/PopularRoutes'
import PopularDestinations from '../components/home/PopularDestinations'
import WhyChooseUs from '../components/home/WhyChooseUs'
import Testimonials from '../components/home/Testimonials'
import OffersSection from '../components/home/OffersSection'
import MetroPromo from '../components/home/MetroPromo'

export default function HomePage() {
  return (
    <div className="page-enter">
      <HeroSection />
      <PopularRoutes />
      <WhyChooseUs />
      <MetroPromo />
      <PopularDestinations />
      <OffersSection />
      <Testimonials />
    </div>
  )
}
