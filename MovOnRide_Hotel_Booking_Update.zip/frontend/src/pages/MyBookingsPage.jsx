import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { BookOpen, Clock, CheckCircle2, XCircle, Eye, X } from 'lucide-react'
import { bookingAPI } from '../services/api'
import { formatDate, formatTime, formatCurrency, getBusTypeLabel, getStatusColor } from '../utils/helpers'
import toast from 'react-hot-toast'
import styles from './MyBookingsPage.module.css'

const TABS = ['UPCOMING', 'COMPLETED', 'CANCELLED']

// Demo bookings for when backend is unavailable
const DEMO_BOOKINGS = [
  { id: 'MR001', pnr: 'MRABC123', operator: 'KPN Travels', busType: 'AC_SLEEPER', from: 'Hyderabad', to: 'Bengaluru', departureTime: '21:00', arrivalTime: '08:00', journeyDate: '2026-12-15', seats: ['L4', 'L5'], amount: 1747, status: 'CONFIRMED', paymentStatus: 'PAID' },
  { id: 'MR002', pnr: 'MRDEF456', operator: 'Orange Travels', busType: 'NON_AC_SEATER', from: 'Chennai', to: 'Bengaluru', departureTime: '07:00', arrivalTime: '13:00', journeyDate: '2026-10-20', seats: ['15'], amount: 498, status: 'COMPLETED', paymentStatus: 'PAID' },
  { id: 'MR003', pnr: 'MRGHI789', operator: 'VRL Travels', busType: 'AC_SLEEPER', from: 'Hyderabad', to: 'Mumbai', departureTime: '18:00', arrivalTime: '10:00', journeyDate: '2026-09-05', seats: ['U2'], amount: 1048, status: 'CANCELLED', paymentStatus: 'REFUNDED' },
]

export default function MyBookingsPage() {
  const [tab, setTab] = useState('UPCOMING')
  const [bookings, setBookings] = useState([])
  const [loading, setLoading] = useState(true)
  const [cancelling, setCancelling] = useState(null)

  useEffect(() => {
    bookingAPI.getAll()
      .then(res => setBookings(res.data))
      .catch(() => setBookings(DEMO_BOOKINGS))
      .finally(() => setLoading(false))
  }, [])

  const handleCancel = async (id) => {
    if (!window.confirm('Are you sure you want to cancel this booking?')) return
    setCancelling(id)
    try {
      await bookingAPI.cancel(id)
      setBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'CANCELLED' } : b))
      toast.success('Booking cancelled')
    } catch {
      toast.error('Cancellation failed')
    } finally {
      setCancelling(null)
    }
  }

  const now = new Date()
  const filtered = bookings.filter(b => {
    const date = new Date(b.journeyDate)
    if (tab === 'UPCOMING') return b.status === 'CONFIRMED' && date >= now
    if (tab === 'COMPLETED') return b.status === 'COMPLETED' || (b.status === 'CONFIRMED' && date < now)
    if (tab === 'CANCELLED') return b.status === 'CANCELLED'
    return true
  })

  return (
    <div className={styles.page}>
      <div className="container">
        <h1 className={styles.pageTitle}><BookOpen size={24} /> My Bookings</h1>

        <div className={styles.tabs}>
          {TABS.map(t => (
            <button key={t} className={`${styles.tab} ${tab === t ? styles.tabActive : ''}`} onClick={() => setTab(t)}>
              {t === 'UPCOMING' && <Clock size={14} />}
              {t === 'COMPLETED' && <CheckCircle2 size={14} />}
              {t === 'CANCELLED' && <XCircle size={14} />}
              {t.charAt(0) + t.slice(1).toLowerCase()} ({bookings.filter(b => {
                const date = new Date(b.journeyDate)
                if (t === 'UPCOMING') return b.status === 'CONFIRMED' && date >= now
                if (t === 'COMPLETED') return b.status === 'COMPLETED' || (b.status === 'CONFIRMED' && date < now)
                if (t === 'CANCELLED') return b.status === 'CANCELLED'
              }).length})
            </button>
          ))}
        </div>

        {loading ? (
          <div className={styles.loading}><div className="spinner" style={{ width: 36, height: 36 }} /><p>Loading your bookings...</p></div>
        ) : filtered.length === 0 ? (
          <div className={styles.empty}>
            <span style={{ fontSize: '3rem' }}>🎫</span>
            <h3>No {tab.toLowerCase()} bookings</h3>
            <p>You don't have any {tab.toLowerCase()} bookings.</p>
            <Link to="/" className="btn btn-primary">Search Buses</Link>
          </div>
        ) : (
          <div className={styles.list}>
            {filtered.map(b => (
              <div key={b.id} className={styles.bookingCard}>
                <div className={styles.cardHeader}>
                  <div>
                    <div className={styles.pnr}>PNR: {b.pnr}</div>
                    <div className={styles.operator}>{b.operator}</div>
                  </div>
                  <span className={`badge ${getStatusColor(b.status)}`}>{b.status}</span>
                </div>

                <div className={styles.routeInfo}>
                  <div className={styles.routeCity}>
                    <strong>{formatTime(b.departureTime)}</strong>
                    <span>{b.from}</span>
                  </div>
                  <div className={styles.routeArrow}>→</div>
                  <div className={styles.routeCity}>
                    <strong>{formatTime(b.arrivalTime)}</strong>
                    <span>{b.to}</span>
                  </div>
                  <div className={styles.routeMeta}>
                    <span>📅 {formatDate(b.journeyDate)}</span>
                    <span>💺 {b.seats?.join(', ')}</span>
                    <span>{getBusTypeLabel(b.busType)}</span>
                  </div>
                </div>

                <div className={styles.cardFooter}>
                  <div className={styles.amount}>
                    <span className={styles.amtLabel}>Paid</span>
                    <strong>{formatCurrency(b.amount)}</strong>
                    <span className={`badge ${b.paymentStatus === 'REFUNDED' ? 'badge-warning' : 'badge-success'}`} style={{ fontSize: '0.72rem' }}>{b.paymentStatus}</span>
                  </div>
                  <div className={styles.actions}>
                    <Link to={`/booking-confirmation/${b.id}`} className="btn btn-ghost btn-sm">
                      <Eye size={14} /> View
                    </Link>
                    {b.status === 'CONFIRMED' && new Date(b.journeyDate) > now && (
                      <button className="btn btn-sm" style={{ background: '#fee2e2', color: '#b91c1c', border: 'none', borderRadius: 8 }} onClick={() => handleCancel(b.id)} disabled={cancelling === b.id}>
                        <X size={14} /> {cancelling === b.id ? 'Cancelling...' : 'Cancel'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
