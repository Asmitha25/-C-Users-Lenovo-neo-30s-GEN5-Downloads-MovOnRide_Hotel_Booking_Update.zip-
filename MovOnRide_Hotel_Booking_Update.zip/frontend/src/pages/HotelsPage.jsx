import React, { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CalendarDays, MapPin, Users, BedDouble, Star, Wifi, Car, Utensils, CheckCircle2, Search, ArrowRight, Hotel as HotelIcon } from 'lucide-react'
import toast from 'react-hot-toast'
import { useAuth } from '../context/AuthContext'
import api from '../services/api'
import styles from './HotelsPage.module.css'

const toDateInput = (date) => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 10)
}

const tomorrow = new Date()
tomorrow.setDate(tomorrow.getDate() + 1)
const dayAfter = new Date(tomorrow)
dayAfter.setDate(dayAfter.getDate() + 1)

export default function HotelsPage() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [filters, setFilters] = useState({ city: 'Hyderabad', check_in: toDateInput(tomorrow), check_out: toDateInput(dayAfter), guests: 2, rooms: 1 })
  const [hotels, setHotels] = useState([])
  const [loading, setLoading] = useState(false)
  const [searched, setSearched] = useState(false)
  const [expandedHotel, setExpandedHotel] = useState(null)
  const [selectedRooms, setSelectedRooms] = useState({})
  const [bookingHotel, setBookingHotel] = useState(null)
  const [bookingBusy, setBookingBusy] = useState(false)
  const [guest, setGuest] = useState({ name: '', email: '', mobile: '' })

  useEffect(() => {
    if (user) {
      setGuest({ name: [user.first_name, user.last_name].filter(Boolean).join(' '), email: user.email || '', mobile: user.mobile || '' })
    }
  }, [user])

  const nights = useMemo(() => {
    if (!filters.check_in || !filters.check_out) return 1
    return Math.max(1, Math.round((new Date(`${filters.check_out}T00:00:00`) - new Date(`${filters.check_in}T00:00:00`)) / 86400000))
  }, [filters.check_in, filters.check_out])

  const searchHotels = async (event) => {
    event.preventDefault()
    if (!filters.city.trim()) return toast.error('Enter a city or destination.')
    if (filters.check_out <= filters.check_in) return toast.error('Check-out must be after check-in.')
    if (filters.check_in < toDateInput(new Date())) return toast.error('Check-in cannot be in the past.')
    setLoading(true)
    setSearched(true)
    setExpandedHotel(null)
    try {
      const response = await api.get('/hotels/', { params: { city: filters.city, check_in: filters.check_in, check_out: filters.check_out } })
      setHotels(response.data.results || response.data)
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Unable to load hotels. Check that the Django server is running.')
      setHotels([])
    } finally {
      setLoading(false)
    }
  }

  const chooseRoom = (hotel, room) => {
    if (!user) {
      toast('Please log in to reserve a hotel room.')
      navigate('/login')
      return
    }
    setBookingHotel({ hotel, room })
  }

  const confirmBooking = async (event) => {
    event.preventDefault()
    if (!bookingHotel) return
    setBookingBusy(true)
    try {
      const response = await api.post('/hotels/bookings/create/', {
        room_type: bookingHotel.room.id,
        check_in: filters.check_in,
        check_out: filters.check_out,
        rooms: Number(filters.rooms),
        guests: Number(filters.guests),
        guest_name: guest.name,
        guest_email: guest.email,
        guest_mobile: guest.mobile,
      })
      toast.success(`Reservation confirmed! Reference: ${response.data.booking_reference}`)
      setBookingHotel(null)
      setExpandedHotel(null)
      await searchHotels({ preventDefault: () => {} })
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Could not create reservation. Please check the details and availability.')
    } finally {
      setBookingBusy(false)
    }
  }

  return (
    <div className={styles.page}>
      <section className={styles.hero}>
        <div className={styles.heroShade} />
        <div className={`container ${styles.heroInner}`}>
          <div className={styles.heroCopy}>
            <span className={styles.eyebrow}><HotelIcon size={15} /> MOVONRIDE STAYS</span>
            <h1>Find a stay that feels like <span>your place.</span></h1>
            <p>Discover comfortable hotels, compare room options and reserve your stay with confidence.</p>
            <div className={styles.trustLine}><span><CheckCircle2 size={16} /> Clear room prices</span><span><CheckCircle2 size={16} /> Easy reservations</span></div>
          </div>
          <form className={styles.searchCard} onSubmit={searchHotels}>
            <div className={styles.searchTitle}>Where would you like to stay?</div>
            <label className={styles.field}><span><MapPin size={15} /> Destination</span><input value={filters.city} onChange={e => setFilters({ ...filters, city: e.target.value })} placeholder="Enter city, e.g. Hyderabad" /></label>
            <div className={styles.dateGrid}>
              <label className={styles.field}><span><CalendarDays size={15} /> Check-in</span><input type="date" min={toDateInput(new Date())} value={filters.check_in} onChange={e => setFilters({ ...filters, check_in: e.target.value })} /></label>
              <label className={styles.field}><span><CalendarDays size={15} /> Check-out</span><input type="date" min={filters.check_in} value={filters.check_out} onChange={e => setFilters({ ...filters, check_out: e.target.value })} /></label>
            </div>
            <div className={styles.dateGrid}>
              <label className={styles.field}><span><Users size={15} /> Guests</span><select value={filters.guests} onChange={e => setFilters({ ...filters, guests: Number(e.target.value) })}>{[1,2,3,4,5,6,7,8].map(n => <option key={n} value={n}>{n} guest{n > 1 ? 's' : ''}</option>)}</select></label>
              <label className={styles.field}><span><BedDouble size={15} /> Rooms</span><select value={filters.rooms} onChange={e => setFilters({ ...filters, rooms: Number(e.target.value) })}>{[1,2,3,4,5].map(n => <option key={n} value={n}>{n} room{n > 1 ? 's' : ''}</option>)}</select></label>
            </div>
            <button className={styles.searchButton} type="submit" disabled={loading}>{loading ? 'Searching…' : <><Search size={18} /> Search hotels</>}</button>
            <div className={styles.searchFoot}>{nights} night{nights > 1 ? 's' : ''} · Prices shown per room, per night</div>
          </form>
        </div>
      </section>

      <section className={`container ${styles.resultsSection}`}>
        <div className={styles.resultsHeader}>
          <div><span className={styles.sectionEyebrow}>YOUR NEXT STAY</span><h2>{searched ? `Hotels in ${filters.city}` : 'Popular stays to explore'}</h2><p>{searched ? `${hotels.length} hotel${hotels.length === 1 ? '' : 's'} found · ${nights} night${nights > 1 ? 's' : ''}` : 'Search a destination to see available properties and room prices.'}</p></div>
        </div>
        {loading && <div className={styles.stateMessage}>Finding hotels for your trip…</div>}
        {!loading && searched && hotels.length === 0 && <div className={styles.emptyState}><HotelIcon size={34} /><h3>No hotels found for this destination</h3><p>Try another city or check the spelling. Hotel listings are managed by MovOnRide.</p></div>}
        {!loading && hotels.length > 0 && <div className={styles.hotelList}>
          {hotels.map(hotel => {
            const roomOptions = hotel.room_types || []
            const lowest = roomOptions.reduce((min, room) => Math.min(min, Number(room.price_per_night)), Infinity)
            const isExpanded = expandedHotel === hotel.id
            return <article className={styles.hotelCard} key={hotel.id}>
              <img className={styles.hotelImage} src={hotel.image_url || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=900'} alt={hotel.name} />
              <div className={styles.hotelInfo}>
                <div className={styles.hotelTopline}><span className={styles.hotelArea}>{hotel.area || hotel.city}</span><span className={styles.rating}><Star size={14} fill="currentColor" /> {hotel.guest_rating}</span></div>
                <h3>{hotel.name}</h3>
                <p className={styles.address}><MapPin size={14} /> {hotel.address}</p>
                <p className={styles.description}>{hotel.description}</p>
                <div className={styles.amenities}>{(hotel.amenities || []).slice(0, 4).map((item, i) => <span key={i}>{item}</span>)}</div>
                <div className={styles.hotelBottom}><div><span className={styles.priceCaption}>Starting from</span><strong>₹{Number.isFinite(lowest) ? lowest.toLocaleString('en-IN') : '—'}</strong><small>/ room / night</small></div><button className={styles.viewButton} onClick={() => { setExpandedHotel(isExpanded ? null : hotel.id); setBookingHotel(null) }}>{isExpanded ? 'Hide rooms' : 'View rooms'} <ArrowRight size={16} /></button></div>
              </div>
              {isExpanded && <div className={styles.roomPanel}>
                <div className={styles.roomPanelTitle}><div><h4>Choose your room</h4><p>Prices for {filters.check_in} to {filters.check_out}</p></div><span>{hotel.star_rating} star hotel</span></div>
                {roomOptions.map(room => <div className={styles.roomRow} key={room.id}>
                  <div className={styles.roomDetails}><strong>{room.name}</strong><p>{room.max_guests} guests max · {room.breakfast_included ? 'Breakfast included' : 'Room only'}</p><small>{(room.amenities || []).join(' · ')}</small></div>
                  <div className={styles.roomPrice}><strong>₹{Number(room.price_per_night).toLocaleString('en-IN')}</strong><small>per night</small><span className={room.available_rooms > 0 ? styles.available : styles.soldOut}>{room.available_rooms > 0 ? `${room.available_rooms} rooms available` : 'Sold out'}</span></div>
                  <button className={styles.selectButton} disabled={room.available_rooms < Number(filters.rooms) || filters.guests > room.max_guests * filters.rooms} onClick={() => chooseRoom(hotel, room)}>Select</button>
                </div>)}
                {roomOptions.length === 0 && <p className={styles.noRooms}>No room types have been added for this hotel yet.</p>}
              </div>}
            </article>
          })}
        </div>}
      </section>

      {bookingHotel && <div className={styles.modalBackdrop} onMouseDown={e => { if (e.target === e.currentTarget) setBookingHotel(null) }}><form className={styles.bookingModal} onSubmit={confirmBooking}>
        <button type="button" className={styles.modalClose} onClick={() => setBookingHotel(null)}>×</button>
        <span className={styles.sectionEyebrow}>FINAL STEP</span><h2>Complete your reservation</h2>
        <p className={styles.modalHotel}>{bookingHotel.hotel.name} · {bookingHotel.room.name}</p>
        <div className={styles.summaryBox}><span>{filters.check_in} → {filters.check_out}</span><span>{filters.guests} guests · {filters.rooms} room(s)</span><strong>₹{(Number(bookingHotel.room.price_per_night) * nights * Number(filters.rooms)).toLocaleString('en-IN')} total</strong><small>{nights} night(s) · Pay at hotel</small></div>
        <label className={styles.modalField}>Guest full name<input required value={guest.name} onChange={e => setGuest({ ...guest, name: e.target.value })} /></label>
        <label className={styles.modalField}>Email address<input required type="email" value={guest.email} onChange={e => setGuest({ ...guest, email: e.target.value })} /></label>
        <label className={styles.modalField}>Mobile number<input required type="tel" value={guest.mobile} onChange={e => setGuest({ ...guest, mobile: e.target.value })} /></label>
        <button className={styles.searchButton} type="submit" disabled={bookingBusy}>{bookingBusy ? 'Confirming…' : 'Confirm reservation'}</button>
        <p className={styles.paymentNote}>This reservation uses Pay at Hotel. No online payment is collected in this first release.</p>
      </form></div>}
    </div>
  )
}
