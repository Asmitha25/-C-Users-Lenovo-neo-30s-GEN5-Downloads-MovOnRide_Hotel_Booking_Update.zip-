import React, { useState } from 'react'
import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard, Bus, Route, Calendar, BookOpen,
  Users, Building2, LogOut, Menu, X, ChevronRight
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import styles from './AdminLayout.module.css'

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard, to: '/admin' },
  { label: 'Buses', icon: Bus, to: '/admin/buses' },
  { label: 'Routes', icon: Route, to: '/admin/routes' },
  { label: 'Schedules', icon: Calendar, to: '/admin/schedules' },
  { label: 'Bookings', icon: BookOpen, to: '/admin/bookings' },
  { label: 'Users', icon: Users, to: '/admin/users' },
  { label: 'Operators', icon: Building2, to: '/admin/operators' },
]

export default function AdminLayout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className={styles.wrapper}>
      {/* Sidebar */}
      <aside className={`${styles.sidebar} ${sidebarOpen ? styles.open : styles.collapsed}`}>
        <div className={styles.brand}>
          <span className={styles.logo}>
            <span style={{ color: '#e53935' }}>M</span>R
          </span>
          {sidebarOpen && <span className={styles.brandName}>MovonRide</span>}
        </div>

        <nav className={styles.nav}>
          {navItems.map(({ label, icon: Icon, to }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/admin'}
              className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
            >
              <Icon size={20} />
              {sidebarOpen && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        <button className={styles.logoutBtn} onClick={handleLogout}>
          <LogOut size={18} />
          {sidebarOpen && <span>Logout</span>}
        </button>
      </aside>

      {/* Main content */}
      <div className={styles.main}>
        <header className={styles.header}>
          <button className={styles.toggleBtn} onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <span className={styles.headerTitle}>Admin Dashboard</span>
          <div className={styles.headerUser}>
            <div className={styles.avatar}>{user?.first_name?.[0] || 'A'}</div>
            {user && <span>{user.first_name} {user.last_name}</span>}
          </div>
        </header>
        <div className={styles.content}>
          <Outlet />
        </div>
      </div>
    </div>
  )
}
