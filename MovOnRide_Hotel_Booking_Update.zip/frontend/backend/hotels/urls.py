from django.urls import path
from . import views

urlpatterns = [
    path('', views.HotelSearchView.as_view(), name='hotel-search'),
    path('<int:pk>/', views.HotelDetailView.as_view(), name='hotel-detail'),
    path('bookings/create/', views.HotelBookingCreateView.as_view(), name='hotel-booking-create'),
    path('bookings/mine/', views.MyHotelBookingsView.as_view(), name='my-hotel-bookings'),
]
