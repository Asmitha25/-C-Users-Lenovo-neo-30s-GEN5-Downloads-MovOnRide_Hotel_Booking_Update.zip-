from django.contrib import admin
from .models import Hotel, RoomType, HotelBooking


class RoomTypeInline(admin.TabularInline):
    model = RoomType
    extra = 1


@admin.register(Hotel)
class HotelAdmin(admin.ModelAdmin):
    list_display = ('name', 'city', 'area', 'star_rating', 'guest_rating', 'is_active')
    list_filter = ('city', 'star_rating', 'is_active')
    search_fields = ('name', 'city', 'area')
    inlines = [RoomTypeInline]


@admin.register(HotelBooking)
class HotelBookingAdmin(admin.ModelAdmin):
    list_display = ('booking_reference', 'hotel', 'user', 'check_in', 'check_out', 'total_amount', 'status')
    list_filter = ('status', 'check_in', 'hotel__city')
    search_fields = ('booking_reference', 'guest_name', 'guest_email', 'hotel__name')
    readonly_fields = ('booking_reference', 'created_at')
