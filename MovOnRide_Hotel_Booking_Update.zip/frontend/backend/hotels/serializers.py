from rest_framework import serializers
from django.db.models import Sum
from .models import Hotel, RoomType, HotelBooking


class RoomTypeSerializer(serializers.ModelSerializer):
    available_rooms = serializers.SerializerMethodField()

    def get_available_rooms(self, obj):
        request = self.context.get('request')
        if not request:
            return obj.total_rooms
        check_in = request.query_params.get('check_in')
        check_out = request.query_params.get('check_out')
        if not check_in or not check_out:
            return obj.total_rooms
        occupied = obj.bookings.filter(
            status='CONFIRMED', check_in__lt=check_out, check_out__gt=check_in
        ).aggregate(total=Sum('rooms'))['total'] or 0
        return max(0, obj.total_rooms - occupied)

    class Meta:
        model = RoomType
        fields = ['id', 'name', 'description', 'max_guests', 'total_rooms', 'available_rooms', 'price_per_night', 'breakfast_included', 'amenities']


class HotelSerializer(serializers.ModelSerializer):
    room_types = RoomTypeSerializer(many=True, read_only=True)

    class Meta:
        model = Hotel
        fields = ['id', 'name', 'city', 'area', 'address', 'description', 'star_rating', 'guest_rating', 'image_url', 'amenities', 'check_in_time', 'check_out_time', 'room_types']


class HotelBookingSerializer(serializers.ModelSerializer):
    hotel_name = serializers.CharField(source='hotel.name', read_only=True)
    room_name = serializers.CharField(source='room_type.name', read_only=True)
    city = serializers.CharField(source='hotel.city', read_only=True)

    def validate(self, attrs):
        required = ['guest_name', 'guest_email', 'guest_mobile']
        missing = [field for field in required if not attrs.get(field)]
        if missing:
            raise serializers.ValidationError({field: 'This field is required.' for field in missing})
        return attrs

    class Meta:
        model = HotelBooking
        fields = ['id', 'booking_reference', 'hotel', 'hotel_name', 'city', 'room_type', 'room_name', 'check_in', 'check_out', 'rooms', 'guests', 'guest_name', 'guest_email', 'guest_mobile', 'price_per_night', 'nights', 'total_amount', 'payment_method', 'status', 'created_at']
        read_only_fields = ['id', 'booking_reference', 'price_per_night', 'nights', 'total_amount', 'status', 'created_at']
