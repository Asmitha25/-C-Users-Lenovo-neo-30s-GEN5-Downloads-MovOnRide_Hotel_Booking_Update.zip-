from datetime import date
from django.db import transaction
from django.db.models import Sum
from django.utils.dateparse import parse_date
from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Hotel, RoomType, HotelBooking
from .serializers import HotelSerializer, HotelBookingSerializer


class HotelSearchView(generics.ListAPIView):
    serializer_class = HotelSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        qs = Hotel.objects.filter(is_active=True).prefetch_related('room_types')
        city = self.request.query_params.get('city', '').strip()
        if city:
            qs = qs.filter(city__icontains=city)
        return qs


class HotelDetailView(generics.RetrieveAPIView):
    queryset = Hotel.objects.filter(is_active=True).prefetch_related('room_types')
    serializer_class = HotelSerializer
    permission_classes = [AllowAny]


class HotelBookingCreateView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        data = request.data
        check_in = parse_date(str(data.get('check_in', '')))
        check_out = parse_date(str(data.get('check_out', '')))
        try:
            room_type_id = int(data.get('room_type'))
            rooms = int(data.get('rooms', 1))
            guests = int(data.get('guests', 1))
        except (TypeError, ValueError):
            return Response({'detail': 'Select a valid room and guest count.'}, status=status.HTTP_400_BAD_REQUEST)

        if not check_in or not check_out or check_in < date.today() or check_out <= check_in:
            return Response({'detail': 'Choose a valid future check-in and check-out date.'}, status=status.HTTP_400_BAD_REQUEST)
        if rooms < 1 or rooms > 10 or guests < 1:
            return Response({'detail': 'Choose between 1 and 10 rooms and at least 1 guest.'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            room_type = RoomType.objects.select_for_update().select_related('hotel').get(pk=room_type_id, is_active=True, hotel__is_active=True)
        except RoomType.DoesNotExist:
            return Response({'detail': 'The selected room is no longer available.'}, status=status.HTTP_404_NOT_FOUND)

        guest_name = str(data.get('guest_name', '')).strip()
        guest_email = str(data.get('guest_email', '')).strip()
        guest_mobile = str(data.get('guest_mobile', '')).strip()
        if not guest_name or not guest_email or not guest_mobile:
            return Response({'detail': 'Guest name, email and mobile number are required.'}, status=status.HTTP_400_BAD_REQUEST)

        if guests > room_type.max_guests * rooms:
            return Response({'detail': f'This room type allows up to {room_type.max_guests * rooms} guests for {rooms} room(s).'}, status=status.HTTP_400_BAD_REQUEST)

        occupied = HotelBooking.objects.filter(
            room_type=room_type, status='CONFIRMED', check_in__lt=check_out, check_out__gt=check_in
        ).aggregate(total=Sum('rooms'))['total'] or 0
        if occupied + rooms > room_type.total_rooms:
            return Response({'detail': 'Not enough rooms are available for these dates. Please change dates or room count.'}, status=status.HTTP_409_CONFLICT)

        nights = (check_out - check_in).days
        price = room_type.price_per_night
        booking = HotelBooking.objects.create(
            user=request.user, hotel=room_type.hotel, room_type=room_type,
            check_in=check_in, check_out=check_out, rooms=rooms, guests=guests,
            guest_name=guest_name, guest_email=guest_email, guest_mobile=guest_mobile,
            price_per_night=price, nights=nights, total_amount=price * nights * rooms,
            payment_method='PAY_AT_HOTEL', status='CONFIRMED'
        )
        return Response(HotelBookingSerializer(booking).data, status=status.HTTP_201_CREATED)


class MyHotelBookingsView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = HotelBookingSerializer

    def get_queryset(self):
        return HotelBooking.objects.filter(user=self.request.user).select_related('hotel', 'room_type')
