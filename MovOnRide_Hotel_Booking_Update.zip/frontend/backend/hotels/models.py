import uuid
from django.conf import settings
from django.db import models


class Hotel(models.Model):
    name = models.CharField(max_length=180)
    city = models.CharField(max_length=100, db_index=True)
    area = models.CharField(max_length=140, blank=True)
    address = models.TextField()
    description = models.TextField(blank=True)
    star_rating = models.PositiveSmallIntegerField(default=3)
    guest_rating = models.DecimalField(max_digits=3, decimal_places=1, default=4.0)
    image_url = models.URLField(max_length=500, blank=True)
    amenities = models.JSONField(default=list, blank=True)
    check_in_time = models.TimeField(default='12:00')
    check_out_time = models.TimeField(default='11:00')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-guest_rating', 'name']

    def __str__(self):
        return f'{self.name} - {self.city}'


class RoomType(models.Model):
    hotel = models.ForeignKey(Hotel, on_delete=models.CASCADE, related_name='room_types')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    max_guests = models.PositiveSmallIntegerField(default=2)
    total_rooms = models.PositiveSmallIntegerField(default=1)
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2)
    breakfast_included = models.BooleanField(default=False)
    amenities = models.JSONField(default=list, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['price_per_night']

    def __str__(self):
        return f'{self.hotel.name} - {self.name}'


class HotelBooking(models.Model):
    STATUS_CHOICES = [('CONFIRMED', 'Confirmed'), ('CANCELLED', 'Cancelled')]
    PAYMENT_CHOICES = [('PAY_AT_HOTEL', 'Pay at hotel')]

    booking_reference = models.CharField(max_length=14, unique=True, editable=False)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='hotel_bookings')
    hotel = models.ForeignKey(Hotel, on_delete=models.PROTECT, related_name='bookings')
    room_type = models.ForeignKey(RoomType, on_delete=models.PROTECT, related_name='bookings')
    check_in = models.DateField()
    check_out = models.DateField()
    rooms = models.PositiveSmallIntegerField(default=1)
    guests = models.PositiveSmallIntegerField(default=1)
    guest_name = models.CharField(max_length=160)
    guest_email = models.EmailField()
    guest_mobile = models.CharField(max_length=20)
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2)
    nights = models.PositiveSmallIntegerField()
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_CHOICES, default='PAY_AT_HOTEL')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='CONFIRMED')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.booking_reference:
            self.booking_reference = 'MRH' + uuid.uuid4().hex[:9].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.booking_reference
