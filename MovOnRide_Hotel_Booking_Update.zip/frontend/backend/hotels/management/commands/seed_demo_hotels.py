from django.core.management.base import BaseCommand
from hotels.models import Hotel, RoomType


class Command(BaseCommand):
    help = 'Add sample hotels and room types for local development.'

    def handle(self, *args, **options):
        samples = [
            {'name': 'The Park Hyderabad', 'city': 'Hyderabad', 'area': 'Somajiguda', 'address': '22, Raj Bhavan Road, Somajiguda, Hyderabad', 'description': 'Contemporary city hotel close to business and shopping districts.', 'stars': 5, 'rating': '4.3', 'image': 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1200', 'amenities': ['Wi-Fi', 'Pool', 'Restaurant', 'Gym'], 'rooms': [('Deluxe King', 2, 8, 5200, True), ('Executive Suite', 3, 3, 8900, True)]},
            {'name': 'Lemon Tree Premier', 'city': 'Hyderabad', 'area': 'HITEC City', 'address': 'Plot 2, Survey 64, HITEC City, Hyderabad', 'description': 'Comfortable business stay with dining and fitness facilities.', 'stars': 4, 'rating': '4.2', 'image': 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1200', 'amenities': ['Wi-Fi', 'Restaurant', 'Gym', 'Parking'], 'rooms': [('Superior Room', 2, 12, 4100, True), ('Business Suite', 3, 4, 6800, True)]},
            {'name': 'Hotel GreenPark', 'city': 'Hyderabad', 'area': 'Begumpet', 'address': 'Greenlands, Begumpet, Hyderabad', 'description': 'Well-connected hotel for leisure and corporate travellers.', 'stars': 4, 'rating': '4.1', 'image': 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1200', 'amenities': ['Wi-Fi', 'Restaurant', 'Parking'], 'rooms': [('Standard Double', 2, 10, 3200, False), ('Premium Room', 2, 6, 4700, True)]},
            {'name': 'The Residency Towers', 'city': 'Chennai', 'area': 'T Nagar', 'address': '115, Sir Thyagaraya Road, T Nagar, Chennai', 'description': 'Upscale stay in the heart of Chennai shopping district.', 'stars': 5, 'rating': '4.4', 'image': 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1200', 'amenities': ['Wi-Fi', 'Pool', 'Spa', 'Restaurant'], 'rooms': [('Deluxe Room', 2, 9, 5600, True), ('Club Suite', 3, 3, 9200, True)]},
            {'name': 'Bloom Hotel', 'city': 'Bengaluru', 'area': 'Indiranagar', 'address': 'Indiranagar, Bengaluru', 'description': 'Modern compact rooms in a lively neighbourhood.', 'stars': 3, 'rating': '4.0', 'image': 'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=1200', 'amenities': ['Wi-Fi', 'Cafe', 'Air conditioning'], 'rooms': [('Bloom Room', 2, 10, 2900, False), ('Deluxe Room', 2, 5, 3900, True)]},
        ]
        for item in samples:
            hotel, _ = Hotel.objects.update_or_create(name=item['name'], city=item['city'], defaults={
                'area': item['area'], 'address': item['address'], 'description': item['description'],
                'star_rating': item['stars'], 'guest_rating': item['rating'], 'image_url': item['image'],
                'amenities': item['amenities'], 'is_active': True,
            })
            for room_name, max_guests, total, price, breakfast in item['rooms']:
                RoomType.objects.update_or_create(hotel=hotel, name=room_name, defaults={
                    'max_guests': max_guests, 'total_rooms': total, 'price_per_night': price,
                    'breakfast_included': breakfast, 'amenities': ['Air conditioning', 'Wi-Fi'], 'is_active': True,
                })
        self.stdout.write(self.style.SUCCESS('Sample hotels and room types are ready.'))
