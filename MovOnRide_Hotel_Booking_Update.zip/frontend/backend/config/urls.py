from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('django-admin/', admin.site.urls),
    path('api/users/', include('users.urls')),
    path('api/buses/', include('buses.urls')),
    path('api/routes/', include('routes.urls')),
    path('api/bookings/', include('bookings.urls')),
    path('api/payments/', include('payments.urls')),
    path('api/hotels/', include('hotels.urls')),
    path('api/admin/', include('buses.admin_urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
