from django.urls import path
from . import admin_views

urlpatterns = [
    path('dashboard/', admin_views.DashboardView.as_view(), name='admin_dashboard'),
    path('buses/', admin_views.AdminBusListCreateView.as_view(), name='admin_buses'),
    path('buses/<int:pk>/', admin_views.AdminBusDetailView.as_view(), name='admin_bus_detail'),
    path('routes/', admin_views.AdminRouteListCreateView.as_view(), name='admin_routes'),
    path('routes/<int:pk>/', admin_views.AdminRouteDetailView.as_view(), name='admin_route_detail'),
    path('schedules/', admin_views.AdminScheduleListCreateView.as_view(), name='admin_schedules'),
    path('schedules/<int:pk>/', admin_views.AdminScheduleDetailView.as_view(), name='admin_schedule_detail'),
    path('bookings/', admin_views.AdminBookingListView.as_view(), name='admin_bookings'),
    path('bookings/<int:pk>/', admin_views.AdminBookingDetailView.as_view(), name='admin_booking_detail'),
    path('users/', admin_views.AdminUserListView.as_view(), name='admin_users'),
    path('operators/', admin_views.AdminOperatorListCreateView.as_view(), name='admin_operators'),
    path('operators/<int:pk>/', admin_views.AdminOperatorDetailView.as_view(), name='admin_operator_detail'),
]
