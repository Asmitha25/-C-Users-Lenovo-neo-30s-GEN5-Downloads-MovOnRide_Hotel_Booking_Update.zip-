from django.db import models


class BusOperator(models.Model):
    name = models.CharField(max_length=100)
    contact_email = models.EmailField()
    contact_phone = models.CharField(max_length=20)
    rating = models.DecimalField(max_digits=3, decimal_places=1, default=4.0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'bus_operators'

    def __str__(self):
        return self.name


class Bus(models.Model):
    BUS_TYPES = [
        ('AC_SLEEPER', 'AC Sleeper'),
        ('NON_AC_SLEEPER', 'Non-AC Sleeper'),
        ('AC_SEATER', 'AC Seater'),
        ('NON_AC_SEATER', 'Non-AC Seater'),
    ]

    operator = models.ForeignKey(BusOperator, on_delete=models.CASCADE, related_name='buses')
    name = models.CharField(max_length=100)
    bus_number = models.CharField(max_length=20, unique=True)
    bus_type = models.CharField(max_length=20, choices=BUS_TYPES)
    total_seats = models.PositiveIntegerField(default=40)
    amenities = models.JSONField(default=list, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'buses'

    def __str__(self):
        return f'{self.name} ({self.bus_number})'


class BusRoute(models.Model):
    from_city = models.CharField(max_length=100)
    to_city = models.CharField(max_length=100)
    distance_km = models.PositiveIntegerField()
    duration_minutes = models.PositiveIntegerField()
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'bus_routes'
        unique_together = ['from_city', 'to_city']

    def __str__(self):
        return f'{self.from_city} → {self.to_city}'


class BusSchedule(models.Model):
    DAYS = [
        ('DAILY', 'Daily'),
        ('MON_FRI', 'Monday to Friday'),
        ('MON_SAT', 'Monday to Saturday'),
        ('WEEKENDS', 'Weekends Only'),
    ]

    bus = models.ForeignKey(Bus, on_delete=models.CASCADE, related_name='schedules')
    route = models.ForeignKey(BusRoute, on_delete=models.CASCADE, related_name='schedules')
    departure_time = models.TimeField()
    arrival_time = models.TimeField()
    fare = models.DecimalField(max_digits=8, decimal_places=2)
    boarding_point = models.CharField(max_length=200)
    dropping_point = models.CharField(max_length=200)
    days_of_week = models.CharField(max_length=20, choices=DAYS, default='DAILY')
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'bus_schedules'

    def __str__(self):
        return f'{self.bus.name} {self.route} {self.departure_time}'


class BusSeat(models.Model):
    SEAT_TYPES = [('LOWER', 'Lower'), ('UPPER', 'Upper')]

    bus = models.ForeignKey(Bus, on_delete=models.CASCADE, related_name='seats')
    seat_number = models.CharField(max_length=10)
    seat_type = models.CharField(max_length=10, choices=SEAT_TYPES, default='LOWER')
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = 'bus_seats'
        unique_together = ['bus', 'seat_number']

    def __str__(self):
        return f'{self.bus.name} - {self.seat_number}'
