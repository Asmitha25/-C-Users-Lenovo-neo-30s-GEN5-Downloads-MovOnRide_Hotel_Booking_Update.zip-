from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from django.db.models import Q
from .models import Bus, BusOperator, BusRoute, BusSchedule, BusSeat
from .serializers import BusScheduleSerializer, BusSeatSerializer, BusOperatorSerializer


class BusSearchView(APIView):
    """Search available buses between two cities on a given date."""
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request):
        from_city = request.query_params.get('from', '')
        to_city = request.query_params.get('to', '')
        date = request.query_params.get('date', '')

        if not from_city or not to_city:
            return Response({'error': 'from and to cities are required'}, status=400)

        schedules = BusSchedule.objects.filter(
            route__from_city__iexact=from_city,
            route__to_city__iexact=to_city,
            is_active=True,
            bus__is_active=True,
        ).select_related('bus', 'bus__operator', 'route')

        serializer = BusScheduleSerializer(schedules, many=True)
        return Response(serializer.data)


class BusDetailView(generics.RetrieveAPIView):
    queryset = Bus.objects.all()
    serializer_class = BusScheduleSerializer


class SeatAvailabilityView(APIView):
    """Return seats for a given schedule with availability."""
    permission_classes = [IsAuthenticatedOrReadOnly]

    def get(self, request, schedule_id):
        try:
            schedule = BusSchedule.objects.get(id=schedule_id)
        except BusSchedule.DoesNotExist:
            return Response({'error': 'Schedule not found'}, status=404)

        seats = BusSeat.objects.filter(bus=schedule.bus, is_active=True)
        serializer = BusSeatSerializer(seats, many=True, context={'schedule_id': schedule_id})
        return Response(serializer.data)


class OperatorListView(generics.ListAPIView):
    queryset = BusOperator.objects.filter(is_active=True)
    serializer_class = BusOperatorSerializer
