from django.urls import path
from . import views

urlpatterns = [
    path('search/', views.BusSearchView.as_view(), name='bus_search'),
    path('<int:pk>/', views.BusDetailView.as_view(), name='bus_detail'),
    path('schedules/<int:schedule_id>/seats/', views.SeatAvailabilityView.as_view(), name='seat_availability'),
    path('operators/', views.OperatorListView.as_view(), name='operators'),
]
