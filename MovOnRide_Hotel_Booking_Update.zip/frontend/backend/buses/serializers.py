from rest_framework import serializers
from .models import Bus, BusOperator, BusRoute, BusSchedule, BusSeat


class BusOperatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusOperator
        fields = '__all__'


class BusSerializer(serializers.ModelSerializer):
    operator_name = serializers.CharField(source='operator.name', read_only=True)

    class Meta:
        model = Bus
        fields = '__all__'


class BusRouteSerializer(serializers.ModelSerializer):
    class Meta:
        model = BusRoute
        fields = '__all__'


class BusScheduleSerializer(serializers.ModelSerializer):
    bus_name = serializers.CharField(source='bus.name', read_only=True)
    operator = serializers.CharField(source='bus.operator.name', read_only=True)
    bus_type = serializers.CharField(source='bus.bus_type', read_only=True)
    bus_number = serializers.CharField(source='bus.bus_number', read_only=True)
    total_seats = serializers.IntegerField(source='bus.total_seats', read_only=True)
    amenities = serializers.JSONField(source='bus.amenities', read_only=True)
    rating = serializers.DecimalField(source='bus.operator.rating', max_digits=3, decimal_places=1, read_only=True)
    from_city = serializers.CharField(source='route.from_city', read_only=True)
    to_city = serializers.CharField(source='route.to_city', read_only=True)
    schedule_id = serializers.CharField(source='id', read_only=True)

    class Meta:
        model = BusSchedule
        fields = [
            'id', 'schedule_id', 'bus', 'bus_name', 'operator', 'bus_type', 'bus_number',
            'total_seats', 'amenities', 'rating',
            'route', 'from_city', 'to_city',
            'departure_time', 'arrival_time', 'fare',
            'boarding_point', 'dropping_point', 'days_of_week', 'is_active',
        ]


class BusSeatSerializer(serializers.ModelSerializer):
    is_booked = serializers.SerializerMethodField()

    class Meta:
        model = BusSeat
        fields = ['id', 'seat_number', 'seat_type', 'is_booked', 'is_active']

    def get_is_booked(self, obj):
        schedule_id = self.context.get('schedule_id')
        if not schedule_id:
            return False
        # Check if seat is booked for this schedule on this date
        from bookings.models import BookingSeat
        return BookingSeat.objects.filter(
            seat=obj,
            booking__schedule_id=schedule_id,
            booking__status__in=['PENDING', 'CONFIRMED']
        ).exists()
