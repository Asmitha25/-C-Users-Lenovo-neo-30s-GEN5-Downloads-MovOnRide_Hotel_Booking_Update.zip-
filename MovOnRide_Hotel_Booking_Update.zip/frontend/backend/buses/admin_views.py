from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAdminUser
from .models import Bus, BusRoute, BusSchedule, BusOperator
from .serializers import BusSerializer, BusRouteSerializer, BusScheduleSerializer, BusOperatorSerializer
from users.models import User
from users.serializers import UserSerializer


class AdminPermission(IsAdminUser):
    def has_permission(self, request, view):
        return bool(request.user and (request.user.is_staff or request.user.is_admin))


class DashboardView(APIView):
    permission_classes = [AdminPermission]

    def get(self, request):
        from bookings.models import Booking
        from payments.models import Payment

        total_bookings = Booking.objects.count()
        total_revenue = sum(p.amount for p in Payment.objects.filter(status='PAID'))
        total_users = User.objects.filter(is_staff=False).count()
        total_buses = Bus.objects.filter(is_active=True).count()
        active_operators = BusOperator.objects.filter(is_active=True).count()
        cancelled = Booking.objects.filter(status='CANCELLED').count()

        return Response({
            'stats': {
                'totalBookings': total_bookings,
                'totalRevenue': float(total_revenue),
                'totalUsers': total_users,
                'totalBuses': total_buses,
                'activeOperators': active_operators,
                'cancelledBookings': cancelled,
            }
        })


class AdminBusListCreateView(generics.ListCreateAPIView):
    permission_classes = [AdminPermission]
    queryset = Bus.objects.all().select_related('operator')
    serializer_class = BusSerializer


class AdminBusDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [AdminPermission]
    queryset = Bus.objects.all()
    serializer_class = BusSerializer


class AdminRouteListCreateView(generics.ListCreateAPIView):
    permission_classes = [AdminPermission]
    queryset = BusRoute.objects.all()
    serializer_class = BusRouteSerializer


class AdminRouteDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [AdminPermission]
    queryset = BusRoute.objects.all()
    serializer_class = BusRouteSerializer


class AdminScheduleListCreateView(generics.ListCreateAPIView):
    permission_classes = [AdminPermission]
    queryset = BusSchedule.objects.all().select_related('bus', 'bus__operator', 'route')
    serializer_class = BusScheduleSerializer


class AdminScheduleDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [AdminPermission]
    queryset = BusSchedule.objects.all()
    serializer_class = BusScheduleSerializer


class AdminBookingListView(generics.ListAPIView):
    permission_classes = [AdminPermission]

    def get(self, request):
        from bookings.models import Booking
        from bookings.serializers import BookingSerializer
        bookings = Booking.objects.all().select_related('user', 'schedule')
        serializer = BookingSerializer(bookings, many=True)
        return Response(serializer.data)


class AdminBookingDetailView(generics.RetrieveUpdateAPIView):
    permission_classes = [AdminPermission]

    def get(self, request, pk):
        from bookings.models import Booking
        from bookings.serializers import BookingSerializer
        try:
            booking = Booking.objects.get(pk=pk)
            return Response(BookingSerializer(booking).data)
        except Booking.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

    def put(self, request, pk):
        from bookings.models import Booking
        try:
            booking = Booking.objects.get(pk=pk)
            booking.status = request.data.get('status', booking.status)
            booking.save()
            return Response({'detail': 'Updated'})
        except Booking.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)


class AdminUserListView(generics.ListAPIView):
    permission_classes = [AdminPermission]
    queryset = User.objects.all()
    serializer_class = UserSerializer


class AdminOperatorListCreateView(generics.ListCreateAPIView):
    permission_classes = [AdminPermission]
    queryset = BusOperator.objects.all()
    serializer_class = BusOperatorSerializer


class AdminOperatorDetailView(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = [AdminPermission]
    queryset = BusOperator.objects.all()
    serializer_class = BusOperatorSerializer
