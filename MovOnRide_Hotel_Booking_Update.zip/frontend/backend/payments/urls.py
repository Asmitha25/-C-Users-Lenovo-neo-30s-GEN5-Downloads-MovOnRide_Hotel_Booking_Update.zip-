from django.urls import path
from . import views

urlpatterns = [
    path('create-order/', views.CreateOrderView.as_view(), name='create_order'),
    path('verify/', views.VerifyPaymentView.as_view(), name='verify_payment'),
    path('mock-pay/', views.MockPaymentView.as_view(), name='mock_payment'),
]
