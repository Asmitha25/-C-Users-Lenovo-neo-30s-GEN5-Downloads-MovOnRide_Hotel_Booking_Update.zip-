from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.conf import settings
from django.utils import timezone
from bookings.models import Booking
from .models import Payment
import hmac, hashlib


class CreateOrderView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            import razorpay
            client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
            amount = int(request.data.get('amount', 0))  # in paise
            order = client.order.create({'amount': amount, 'currency': 'INR', 'payment_capture': 1})
            return Response({'id': order['id'], 'amount': order['amount'], 'currency': order['currency']})
        except Exception as e:
            return Response({'error': str(e), 'message': 'Razorpay unavailable — use Mock Payment'}, status=503)


class VerifyPaymentView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data
        try:
            # Verify signature
            body = f"{data['razorpay_order_id']}|{data['razorpay_payment_id']}"
            expected = hmac.new(
                settings.RAZORPAY_KEY_SECRET.encode(),
                body.encode(),
                hashlib.sha256
            ).hexdigest()
            if not hmac.compare_digest(expected, data.get('razorpay_signature', '')):
                return Response({'error': 'Invalid payment signature'}, status=400)

            # Update booking and payment
            booking_id = data.get('booking_id')
            if booking_id:
                booking = Booking.objects.get(id=booking_id, user=request.user)
                Payment.objects.update_or_create(
                    booking=booking,
                    defaults={
                        'razorpay_order_id': data['razorpay_order_id'],
                        'razorpay_payment_id': data['razorpay_payment_id'],
                        'amount': booking.total_fare,
                        'status': 'PAID',
                        'method': 'RAZORPAY',
                        'paid_at': timezone.now(),
                    }
                )
                booking.status = 'CONFIRMED'
                booking.save()

            return Response({'detail': 'Payment verified'})
        except Exception as e:
            return Response({'error': str(e)}, status=400)


class MockPaymentView(APIView):
    """
    Demo mock payment — does NOT process real transactions.
    Marks a booking as paid without any financial transaction.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        booking_id = request.data.get('booking_id')
        amount = request.data.get('amount', 0)

        if booking_id:
            try:
                booking = Booking.objects.get(id=booking_id)
                Payment.objects.update_or_create(
                    booking=booking,
                    defaults={
                        'amount': amount,
                        'status': 'PAID',
                        'method': 'MOCK',
                        'paid_at': timezone.now(),
                    }
                )
                booking.status = 'CONFIRMED'
                booking.save()
            except Booking.DoesNotExist:
                pass  # demo mode — booking may not exist

        return Response({
            'detail': 'Mock payment processed. ⚠ No real money was charged.',
            'status': 'PAID',
        })
