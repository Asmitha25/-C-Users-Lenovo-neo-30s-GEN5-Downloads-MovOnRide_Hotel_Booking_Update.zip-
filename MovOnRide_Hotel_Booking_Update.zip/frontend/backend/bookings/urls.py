from django.urls import path
from . import views

urlpatterns = [
    path('create/', views.BookingCreateView.as_view(), name='create_booking'),
    path('', views.UserBookingListView.as_view(), name='user_bookings'),
    path('<int:pk>/', views.BookingDetailView.as_view(), name='booking_detail'),
    path('<int:pk>/cancel/', views.CancelBookingView.as_view(), name='cancel_booking'),
    path('hold-seats/', views.HoldSeatsView.as_view(), name='hold_seats'),
]
