import uuid
from django.db import models
from django.conf import settings
from buses.models import BusSchedule, BusSeat


def generate_pnr():
    return 'MR' + uuid.uuid4().hex[:8].upper()


class Passenger(models.Model):
    GENDER_CHOICES = [('MALE', 'Male'), ('FEMALE', 'Female'), ('OTHER', 'Other')]

    full_name = models.CharField(max_length=100)
    age = models.PositiveSmallIntegerField()
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'passengers'

    def __str__(self):
        return self.full_name


class Booking(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('CONFIRMED', 'Confirmed'),
        ('COMPLETED', 'Completed'),
        ('CANCELLED', 'Cancelled'),
        ('FAILED', 'Failed'),
    ]

    pnr = models.CharField(max_length=20, unique=True, default=generate_pnr)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='bookings')
    schedule = models.ForeignKey(BusSchedule, on_delete=models.CASCADE, related_name='bookings')
    journey_date = models.DateField()
    boarding_point = models.CharField(max_length=200)
    dropping_point = models.CharField(max_length=200)
    contact_email = models.EmailField()
    contact_mobile = models.CharField(max_length=15)
    total_fare = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'bookings'
        ordering = ['-created_at']

    def __str__(self):
        return f'Booking {self.pnr}'


class BookingSeat(models.Model):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name='booking_seats')
    seat = models.ForeignKey(BusSeat, on_delete=models.CASCADE)
    passenger = models.ForeignKey(Passenger, on_delete=models.CASCADE)

    class Meta:
        db_table = 'booking_seats'
        unique_together = ['booking', 'seat']

    def __str__(self):
        return f'{self.booking.pnr} - {self.seat.seat_number}'


class Cancellation(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name='cancellation')
    reason = models.TextField(blank=True)
    refund_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    refund_status = models.CharField(max_length=20, default='PENDING')
    cancelled_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'cancellations'
