from rest_framework import serializers
from .models import Booking, BookingSeat, Passenger, Cancellation
from buses.models import BusSeat


class PassengerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Passenger
        fields = ['full_name', 'age', 'gender']


class BookingCreateSerializer(serializers.Serializer):
    schedule = serializers.IntegerField()
    seats = serializers.ListField(child=serializers.IntegerField())
    passengers = PassengerSerializer(many=True)
    journey_date = serializers.DateField()
    contact_email = serializers.EmailField()
    contact_mobile = serializers.CharField(max_length=15)
    boarding_point = serializers.CharField()
    dropping_point = serializers.CharField()

    def validate(self, data):
        if len(data['seats']) != len(data['passengers']):
            raise serializers.ValidationError('Number of seats and passengers must match')
        return data


class BookingSerializer(serializers.ModelSerializer):
    passengers = serializers.SerializerMethodField()
    seats = serializers.SerializerMethodField()
    operator = serializers.CharField(source='schedule.bus.operator.name', read_only=True)
    bus_type = serializers.CharField(source='schedule.bus.bus_type', read_only=True)
    departure_time = serializers.TimeField(source='schedule.departure_time', read_only=True)
    arrival_time = serializers.TimeField(source='schedule.arrival_time', read_only=True)
    from_city = serializers.CharField(source='schedule.route.from_city', read_only=True)
    to_city = serializers.CharField(source='schedule.route.to_city', read_only=True)
    payment_status = serializers.SerializerMethodField()

    class Meta:
        model = Booking
        fields = [
            'id', 'pnr', 'status', 'journey_date', 'boarding_point', 'dropping_point',
            'contact_email', 'contact_mobile', 'total_fare',
            'operator', 'bus_type', 'departure_time', 'arrival_time', 'from_city', 'to_city',
            'passengers', 'seats', 'payment_status', 'created_at',
        ]

    def get_passengers(self, obj):
        return PassengerSerializer(
            [bs.passenger for bs in obj.booking_seats.select_related('passenger')], many=True
        ).data

    def get_seats(self, obj):
        return [bs.seat.seat_number for bs in obj.booking_seats.select_related('seat')]

    def get_payment_status(self, obj):
        payment = getattr(obj, 'payment', None)
        return payment.status if payment else 'PENDING'
