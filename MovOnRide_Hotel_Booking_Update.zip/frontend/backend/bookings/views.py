from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.db import transaction
from .models import Booking, BookingSeat, Passenger, Cancellation
from .serializers import BookingSerializer, BookingCreateSerializer
from buses.models import BusSchedule, BusSeat


class BookingCreateView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request):
        serializer = BookingCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        # Get schedule
        try:
            schedule = BusSchedule.objects.get(id=data['schedule'])
        except BusSchedule.DoesNotExist:
            return Response({'error': 'Schedule not found'}, status=404)

        # Verify seats are available
        seats = BusSeat.objects.filter(id__in=data['seats'], bus=schedule.bus)
        if seats.count() != len(data['seats']):
            return Response({'error': 'Invalid seats'}, status=400)

        # Check for already-booked seats
        already_booked = BookingSeat.objects.filter(
            seat__in=seats,
            booking__schedule=schedule,
            booking__status__in=['PENDING', 'CONFIRMED']
        )
        if already_booked.exists():
            booked_nums = [bs.seat.seat_number for bs in already_booked]
            return Response({'error': f'Seats already booked: {", ".join(booked_nums)}'}, status=409)

        # Calculate fare
        per_seat = float(schedule.fare)
        gst = round(per_seat * len(seats) * 0.05, 2)
        convenience = 49
        total = per_seat * len(seats) + gst + convenience

        # Create booking
        booking = Booking.objects.create(
            user=request.user,
            schedule=schedule,
            journey_date=data['journey_date'],
            boarding_point=data['boarding_point'],
            dropping_point=data['dropping_point'],
            contact_email=data['contact_email'],
            contact_mobile=data['contact_mobile'],
            total_fare=total,
            status='PENDING',
        )

        # Create passengers and booking seats
        for seat_id, passenger_data in zip(data['seats'], data['passengers']):
            passenger = Passenger.objects.create(**passenger_data)
            seat = BusSeat.objects.get(id=seat_id)
            BookingSeat.objects.create(booking=booking, seat=seat, passenger=passenger)

        return Response(BookingSerializer(booking).data, status=status.HTTP_201_CREATED)


class UserBookingListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = BookingSerializer

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user).select_related(
            'schedule', 'schedule__bus', 'schedule__bus__operator', 'schedule__route'
        ).prefetch_related('booking_seats__seat', 'booking_seats__passenger')


class BookingDetailView(generics.RetrieveAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = BookingSerializer

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user)


class CancelBookingView(APIView):
    permission_classes = [IsAuthenticated]

    @transaction.atomic
    def post(self, request, pk):
        try:
            booking = Booking.objects.get(pk=pk, user=request.user)
        except Booking.DoesNotExist:
            return Response({'error': 'Booking not found'}, status=404)

        if booking.status == 'CANCELLED':
            return Response({'error': 'Already cancelled'}, status=400)

        # Calculate refund (simplified: 90% refund)
        refund = float(booking.total_fare) * 0.9
        booking.status = 'CANCELLED'
        booking.save()

        Cancellation.objects.create(
            booking=booking,
            reason=request.data.get('reason', ''),
            refund_amount=refund,
            refund_status='PENDING'
        )

        return Response({'detail': 'Booking cancelled', 'refund_amount': refund})


class HoldSeatsView(APIView):
    """Temporarily mark seats as held (session-level lock)."""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        # In production, implement Redis-based seat locking
        return Response({'detail': 'Seats held for 10 minutes'})
